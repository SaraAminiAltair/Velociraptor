﻿namespace Velociraptor
{
    partial class frmTerrian
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.picBoxGeneralTerrian = new System.Windows.Forms.PictureBox();
            this.picBoxCLoudDC = new System.Windows.Forms.PictureBox();
            this.picBoxFogPoint = new System.Windows.Forms.PictureBox();
            this.picBoxIoT = new System.Windows.Forms.PictureBox();
            this.picBoxBTS = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxGeneralTerrian)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxCLoudDC)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxFogPoint)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxIoT)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxBTS)).BeginInit();
            this.SuspendLayout();
            // 
            // picBoxGeneralTerrian
            // 
            this.picBoxGeneralTerrian.Image = global::Velociraptor.Properties.Resources.Untitled;
            this.picBoxGeneralTerrian.Location = new System.Drawing.Point(0, 1);
            this.picBoxGeneralTerrian.Name = "picBoxGeneralTerrian";
            this.picBoxGeneralTerrian.Size = new System.Drawing.Size(232, 148);
            this.picBoxGeneralTerrian.TabIndex = 1;
            this.picBoxGeneralTerrian.TabStop = false;
            // 
            // picBoxCLoudDC
            // 
            this.picBoxCLoudDC.Image = global::Velociraptor.Properties.Resources.Untitled;
            this.picBoxCLoudDC.Location = new System.Drawing.Point(0, 155);
            this.picBoxCLoudDC.Name = "picBoxCLoudDC";
            this.picBoxCLoudDC.Size = new System.Drawing.Size(232, 148);
            this.picBoxCLoudDC.TabIndex = 2;
            this.picBoxCLoudDC.TabStop = false;
            // 
            // picBoxFogPoint
            // 
            this.picBoxFogPoint.Image = global::Velociraptor.Properties.Resources.Untitled;
            this.picBoxFogPoint.Location = new System.Drawing.Point(238, 1);
            this.picBoxFogPoint.Name = "picBoxFogPoint";
            this.picBoxFogPoint.Size = new System.Drawing.Size(232, 148);
            this.picBoxFogPoint.TabIndex = 3;
            this.picBoxFogPoint.TabStop = false;
            // 
            // picBoxIoT
            // 
            this.picBoxIoT.Image = global::Velociraptor.Properties.Resources.Untitled;
            this.picBoxIoT.Location = new System.Drawing.Point(238, 155);
            this.picBoxIoT.Name = "picBoxIoT";
            this.picBoxIoT.Size = new System.Drawing.Size(232, 148);
            this.picBoxIoT.TabIndex = 4;
            this.picBoxIoT.TabStop = false;
            this.picBoxIoT.Click += new System.EventHandler(this.picBoxIoT_Click);
            // 
            // picBoxBTS
            // 
            this.picBoxBTS.Image = global::Velociraptor.Properties.Resources.Untitled;
            this.picBoxBTS.Location = new System.Drawing.Point(0, 309);
            this.picBoxBTS.Name = "picBoxBTS";
            this.picBoxBTS.Size = new System.Drawing.Size(232, 148);
            this.picBoxBTS.TabIndex = 5;
            this.picBoxBTS.TabStop = false;
            // 
            // frmTerrian
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(19F, 37F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.ClientSize = new System.Drawing.Size(497, 524);
            this.Controls.Add(this.picBoxBTS);
            this.Controls.Add(this.picBoxIoT);
            this.Controls.Add(this.picBoxFogPoint);
            this.Controls.Add(this.picBoxCLoudDC);
            this.Controls.Add(this.picBoxGeneralTerrian);
            this.Name = "frmTerrian";
            this.Text = "frmTerrian";
            this.Load += new System.EventHandler(this.frmTerrian_Load);
            this.Paint += new System.Windows.Forms.PaintEventHandler(this.frmTerrian_Paint);
            ((System.ComponentModel.ISupportInitialize)(this.picBoxGeneralTerrian)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxCLoudDC)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxFogPoint)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxIoT)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxBTS)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.PictureBox picBoxGeneralTerrian;
        private System.Windows.Forms.PictureBox picBoxCLoudDC;
        private System.Windows.Forms.PictureBox picBoxFogPoint;
        private System.Windows.Forms.PictureBox picBoxIoT;
        private System.Windows.Forms.PictureBox picBoxBTS;
    }
}