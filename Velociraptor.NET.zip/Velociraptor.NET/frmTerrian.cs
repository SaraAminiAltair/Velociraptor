﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Imaging;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Velociraptor
{
    public partial class frmTerrian : Form
    {
        public frmTerrian()
        {
            InitializeComponent();
            CheckForIllegalCrossThreadCalls = false;
        }

        private void frmTerrian_Paint(object sender, PaintEventArgs e)
        {

        }

        void DrawCell(Graphics g, string textOnCell,Brush textBrush, Rectangle rect, Brush brush, Font font, PointF pointToStartWritting)
        {
            g.FillRectangle(brush, rect);
            g.DrawString(textOnCell, font, textBrush, pointToStartWritting);
        }

        public void DrawAndSaveGrid(LocationProfile.GridOverlay grd, int Col, int Row, int PaddingBetweenCells,
            string nodetype // general,iot,cloud,fog,bts
            , string filename
            , int bmpWidth, int bmpHeight, int cellWidthToShow)
        {


            Font font = new Font("Times New Roman", cellWidthToShow / 2, FontStyle.Bold, GraphicsUnit.Pixel);
            Bitmap bmp = new Bitmap(bmpWidth, bmpHeight, PixelFormat.Format16bppRgb555);
            Graphics g = Graphics.FromImage(bmp);
           
            SolidBrush brush_NotReachable = new SolidBrush(Color.Black);
            SolidBrush brush_forLandNormal = new SolidBrush(Color.ForestGreen);
            SolidBrush brush_forWaterNormal = new SolidBrush(Color.LightBlue);
            SolidBrush brush_forFogPointCell = new SolidBrush(Color.Orange);
            SolidBrush brush_forCloudCell = new SolidBrush(Color.WhiteSmoke);
            SolidBrush brush_forIoTCell = new SolidBrush(Color.Yellow);
            SolidBrush brush_forBTS = new SolidBrush(Color.Brown);
            SolidBrush brush = brush_forLandNormal;
            for (int i = 0; i < Col; i++)
            {
                for (int j = 0; j < Row; j++)
                {
                    bool markx = false;
                    LocationProfile.GridCell c = grd.Cells[j, i];
                    int x = i * PaddingBetweenCells + i * cellWidthToShow;
                    int y = j * PaddingBetweenCells + j * cellWidthToShow;
                    Rectangle rect = new Rectangle(x, y, cellWidthToShow, cellWidthToShow);
                    PointF pointToStartWritting = new PointF(x, y + (cellWidthToShow / 4));
                    if ((c.CellTerrianType == LocationProfile.GridCell.TerrianTypeCodes.Land_NotPartOfMapAndNotReachable) || (c.CellTerrianType == LocationProfile.GridCell.TerrianTypeCodes.Water_NotPartOfMapAndNotReachable)) {brush = brush_NotReachable; markx = true; }
                    else
                    {
                        if (c.CellTerrianType == LocationProfile.GridCell.TerrianTypeCodes.Land_Reachable) brush = brush_forLandNormal; else brush = brush_forWaterNormal;
                    }

                    g.FillRectangle(brush, rect);
                    if (markx) {
                     //   DrawCell(g, " ✖", Brushes.Red, rect, brush_forCloudCell, font, pointToStartWritting);
                    }
                    else
                    {

                        if ((nodetype == "cloud") && (c.CurrentlyHasCloudDC)) DrawCell(g, "DC",Brushes.Black, rect, brush_forCloudCell, font, pointToStartWritting);
                        else if ((nodetype == "fog") && (c.CurrentlyHasFogpoint)) DrawCell(g, "Fog", Brushes.Black, rect, brush_forFogPointCell, font, pointToStartWritting);
                        else if ((nodetype == "iot") && (c.CurrentlyHasIoT)) DrawCell(g, "IoT", Brushes.Black, rect, brush_forIoTCell, font, pointToStartWritting);
                        else if ((nodetype == "bts") && (c.CurrentlyHasBTS)) DrawCell(g, "bts", Brushes.Black, rect, brush_forBTS, font, pointToStartWritting);
                    }
                }
            }
            g.Dispose();

            picBoxGeneralTerrian.Image = bmp;
            picBoxGeneralTerrian.Image.Save(filename, System.Drawing.Imaging.ImageFormat.Png);
            System.GC.Collect();

        }

        public void DrawGrid(SimuData simuDB)
        {
            LocationProfile.GridOverlay grd = simuDB.terrain.TerrianGrid;
            int Col = grd.GetCountOfColumns(), Row = grd.GetCountOfRows();

            for (int i = 0; i < Col; i++)
            {
                for (int j = 0; j < Row; j++)
                {
                    LocationProfile.GridCell c = grd.Cells[j, i];
                    if ((c.CellTerrianType == LocationProfile.GridCell.TerrianTypeCodes.Water_NotPartOfMapAndNotReachable) || (c.CellTerrianType == LocationProfile.GridCell.TerrianTypeCodes.Land_NotPartOfMapAndNotReachable))
                    {
                        if ((c.CurrentlyHasIoT) || (c.CurrentlyHasFogpoint) || (c.CurrentlyHasCloudDC))
                        {
                            MessageBox.Show("oh!");
                        }
                    }
                }
            }

            float scale = 1f;
            int cellWidthToShow = Math.Max(30, Convert.ToInt32(scale * grd.CellWidthInMeters));
            int paddingBetweenCells = 0;

            //  int Col = grd.GetCountOfColumns(), Row = grd.GetCountOfRows();
            int imgWidth = 0;
            int imgHeight = 0;

            long bmpoMaxSize = 2147483648;
            while (true)
            {
                cellWidthToShow = Convert.ToInt32(scale * cellWidthToShow);
                paddingBetweenCells= Convert.ToInt32(0.3 * cellWidthToShow);
                imgWidth = Col * cellWidthToShow + Col * paddingBetweenCells;
                imgHeight = Row * cellWidthToShow + Row * paddingBetweenCells;

                long bmpSize =   (long) imgWidth*(long)imgHeight * 32 ;
                if (bmpSize <= bmpoMaxSize) break;
                scale = scale - 0.05f;
            }

            System.GC.Collect();

            DrawAndSaveGrid(grd, Col, Row, paddingBetweenCells, "general", @"TerrianGeneral.png", imgWidth, imgHeight, cellWidthToShow);
            DrawAndSaveGrid(grd, Col, Row, paddingBetweenCells, "cloud", @"TerrianCloudGrid.Png", imgWidth, imgHeight, cellWidthToShow);
            DrawAndSaveGrid(grd, Col, Row, paddingBetweenCells, "fog", @"TerrianFogpointGrid.Png", imgWidth, imgHeight, cellWidthToShow);
            DrawAndSaveGrid(grd, Col, Row, paddingBetweenCells, "iot", @"TerrianIoTGrid.Png", imgWidth, imgHeight, cellWidthToShow);
            DrawAndSaveGrid(grd, Col, Row, paddingBetweenCells, "bts", @"TerrianBTSGrid.Png", imgWidth, imgHeight, cellWidthToShow);


            this.Close();
            this.Dispose();
            System.GC.Collect();

        }




        private void frmTerrian_Load(object sender, EventArgs e)
        {

        }

        private void picBoxIoT_Click(object sender, EventArgs e)
        {

        }
    }
}
