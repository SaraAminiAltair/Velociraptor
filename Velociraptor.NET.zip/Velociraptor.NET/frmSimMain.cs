﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;

using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;
using System.Xml.Serialization;
using System.Diagnostics;
using System.Data.SqlClient;

namespace Velociraptor
{
    public partial class frmSimMain : Form
    {
        Form mainFormForBack;
        SimuCore internal_sim;
        SimuCfg _simulationConfig = SimuCfg.ExperimentSettings(900000); //zz ra raa

        // SimulationConfiguration _simulationConfig = SimulationConfiguration.ExperimentTwoSpecs(600000); //zz ra raa
        // SimulationConfiguration _simulationConfig = SimulationConfiguration.ExperimentOneSpecs(600000); //zz ra raa






        SimuCore getSimObject(bool returnSimulationObjectOnlyIfSimulationIsFinished)
        {
            if (returnSimulationObjectOnlyIfSimulationIsFinished)
            {
                if ((internal_sim != null) && (!internal_sim.isSimulationRunning)) return internal_sim;
                else return null;
            }
            else
            {
                if ((internal_sim == null))
                {
                    internal_sim = new SimuCore(_simulationConfig);
                    internal_sim.InitTextboxes(txtLog, txtLogSingleActDetails);
                    return internal_sim;
                }
                //it is not null  (may be currently running or may be it has never been started)
                return internal_sim;
            }
        }

        public frmSimMain()
        {
            InitializeComponent();
        }

        Thread threadMainForSimulation;

        private void btnStartTestSim_Click(object sender, EventArgs e)
        {
        }

        private void frmSimMain_FormClosed(object sender, FormClosedEventArgs e)
        {
            try
            {
                //   mainFormForBack.Visible = true;
                Application.Exit();
            }
            catch (Exception)
            {


            }

        }





        private void frmSimMain_Load(object sender, EventArgs e)
        {
            //this.WindowState = FormWindowState.Maximized;
            //MalekiScoreMatlab mfis = new MalekiScoreMatlab();

            // double v= mfis.FIS_Call_Maleki(1, 0.7f, 1, 1, 1);



        }
        SimuCore s = null;
        private void btnStartTestSim_Click_1(object sender, EventArgs e)
        {

            btnStartTestSim.Enabled = false;
            s = getSimObject(false);
            if (s == null) return;
            CleanOlderSimulationsFromDB(s.simuDB.dal);
            s.SimulationRun(txtLogSingleActDetails, true);

        }

        void CleanOlderSimulationsFromDB(DAL dal)
        {

            System.Data.SqlClient.SqlConnection sqlConn = dal.getConnectionObject();
            if ((sqlConn == null)) return;
            if (sqlConn.State != ConnectionState.Open) sqlConn.Open();
            using (SqlCommand cmd = new SqlCommand("CleanAll", sqlConn))
            {
                cmd.CommandType = CommandType.StoredProcedure;
                DAL.ExecuteNonQuery(cmd);
            }
        }

        private void btnStopSimulation_Click_1(object sender, EventArgs e)
        {

            
        }


       
 

        private void button1_Click(object sender, EventArgs e)
        {
            s = getSimObject(true);
            if (s == null)
            {
                
                MessageBox.Show("Can not generate overlay images! The simulation is not started, or it is still running.");
                return;
            }

            foreach (ComputerNode node in s.simuDB.Nodes )
            {
                if ((node.LocationProfile.LocationHistory == null) || (node.LocationProfile.LocationHistory.Count == 0))
                {
                    int hh = 0;
                }

            }
            s.DrawAndSaveGrid();
        }

        private void btnAbout_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Velociraptor version 2.1 \n");
        }
    }
}
