﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Velociraptor
{
    public partial class Startup : Form
    {
        frmSimMain frmSimulation;
        public Startup()
        {
            InitializeComponent();
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Visible = false;
            
                frmSimulation = new frmSimMain();
            frmSimulation.Show();
        }

        private void label3_Click(object sender, EventArgs e)
        {
            
        }

        private void Startup_Load(object sender, EventArgs e)
        {

            button1_Click(this, null);
            this.Visible = false;
        }

        private void button3_Click(object sender, EventArgs e)
        {

        }

        private void calc_Click(object sender, EventArgs e)
        {
            int X1, X2, Y1, Y2;
            double Teta, Atan;
            try
            {
                X1=Convert.ToInt32( x1.Text);
                Y1=Convert.ToInt32( y1.Text);

                X2 = Convert.ToInt32(x2.Text);
                Y2 = Convert.ToInt32(y2.Text);
                double xF=0,yF = 0, VLen = 0, angleDegree = 0, angleRadian = 0;

                CoUtils cu = new CoUtils();
                cu.GeometeryCalculateDeclinationForTwoGivenPoints(X1, X2, Y1, Y2, out xF, out yF, out VLen, out angleDegree, out angleRadian);

                rad.Text = angleRadian.ToString();
                degree.Text = angleDegree.ToString();

                double vectorLength=Math.Sqrt(Math.Pow((Y2-Y1),2)+ Math.Pow((X2-X1), 2));

                xfactor.Text = xF.ToString();
                yfactor.Text = yF.ToString();

            }
            catch (Exception)
            {

            }
        }
    }
}
