﻿ namespace Velociraptor
{
    partial class frmSimMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmSimMain));
            this.txtLog = new System.Windows.Forms.TextBox();
            this.txtLogSingleActDetails = new System.Windows.Forms.TextBox();
            this.btnStartTestSim = new System.Windows.Forms.Button();
            this.bgWorker = new System.ComponentModel.BackgroundWorker();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.btnExportTerrianGridOverlays = new System.Windows.Forms.Button();
            this.btnAbout = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // txtLog
            // 
            this.txtLog.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.txtLog.ForeColor = System.Drawing.Color.White;
            this.txtLog.Location = new System.Drawing.Point(26, 584);
            this.txtLog.Margin = new System.Windows.Forms.Padding(6);
            this.txtLog.Multiline = true;
            this.txtLog.Name = "txtLog";
            this.txtLog.ReadOnly = true;
            this.txtLog.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtLog.Size = new System.Drawing.Size(938, 312);
            this.txtLog.TabIndex = 7;
            // 
            // txtLogSingleActDetails
            // 
            this.txtLogSingleActDetails.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.txtLogSingleActDetails.ForeColor = System.Drawing.Color.White;
            this.txtLogSingleActDetails.Location = new System.Drawing.Point(26, 467);
            this.txtLogSingleActDetails.Margin = new System.Windows.Forms.Padding(6);
            this.txtLogSingleActDetails.Multiline = true;
            this.txtLogSingleActDetails.Name = "txtLogSingleActDetails";
            this.txtLogSingleActDetails.ReadOnly = true;
            this.txtLogSingleActDetails.Size = new System.Drawing.Size(938, 105);
            this.txtLogSingleActDetails.TabIndex = 9;
            // 
            // btnStartTestSim
            // 
            this.btnStartTestSim.AutoSize = true;
            this.btnStartTestSim.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btnStartTestSim.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnStartTestSim.FlatAppearance.BorderSize = 0;
            this.btnStartTestSim.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnStartTestSim.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.btnStartTestSim.ForeColor = System.Drawing.Color.White;
            this.btnStartTestSim.Location = new System.Drawing.Point(26, 362);
            this.btnStartTestSim.Margin = new System.Windows.Forms.Padding(6);
            this.btnStartTestSim.Name = "btnStartTestSim";
            this.btnStartTestSim.Size = new System.Drawing.Size(196, 96);
            this.btnStartTestSim.TabIndex = 17;
            this.btnStartTestSim.Text = "Start";
            this.btnStartTestSim.UseVisualStyleBackColor = false;
            this.btnStartTestSim.Click += new System.EventHandler(this.btnStartTestSim_Click_1);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(433, 30);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(6);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(123, 123);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 25;
            this.pictureBox1.TabStop = false;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(197, 250);
            this.label2.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(626, 37);
            this.label2.TabIndex = 24;
            this.label2.Text = "Advanced IoT, Fog and Cloud Simulator";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.DimGray;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.label1.Location = new System.Drawing.Point(271, 159);
            this.label1.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(474, 91);
            this.label1.TabIndex = 23;
            this.label1.Text = "Velociraptor";
            // 
            // btnExportTerrianGridOverlays
            // 
            this.btnExportTerrianGridOverlays.AutoSize = true;
            this.btnExportTerrianGridOverlays.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btnExportTerrianGridOverlays.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnExportTerrianGridOverlays.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnExportTerrianGridOverlays.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExportTerrianGridOverlays.ForeColor = System.Drawing.Color.White;
            this.btnExportTerrianGridOverlays.Location = new System.Drawing.Point(246, 362);
            this.btnExportTerrianGridOverlays.Name = "btnExportTerrianGridOverlays";
            this.btnExportTerrianGridOverlays.Size = new System.Drawing.Size(530, 96);
            this.btnExportTerrianGridOverlays.TabIndex = 26;
            this.btnExportTerrianGridOverlays.Text = "Export Terrian Grids";
            this.btnExportTerrianGridOverlays.UseVisualStyleBackColor = false;
            this.btnExportTerrianGridOverlays.Click += new System.EventHandler(this.button1_Click);
            // 
            // btnAbout
            // 
            this.btnAbout.AutoSize = true;
            this.btnAbout.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btnAbout.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnAbout.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAbout.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAbout.ForeColor = System.Drawing.Color.White;
            this.btnAbout.Location = new System.Drawing.Point(803, 362);
            this.btnAbout.Name = "btnAbout";
            this.btnAbout.Size = new System.Drawing.Size(161, 96);
            this.btnAbout.TabIndex = 27;
            this.btnAbout.Text = "About";
            this.btnAbout.UseVisualStyleBackColor = false;
            this.btnAbout.Click += new System.EventHandler(this.btnAbout_Click);
            // 
            // frmSimMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(19F, 37F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Gray;
            this.ClientSize = new System.Drawing.Size(988, 897);
            this.Controls.Add(this.btnAbout);
            this.Controls.Add(this.btnExportTerrianGridOverlays);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtLogSingleActDetails);
            this.Controls.Add(this.txtLog);
            this.Controls.Add(this.btnStartTestSim);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Margin = new System.Windows.Forms.Padding(6);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frmSimMain";
            this.ShowIcon = false;
            this.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Hide;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Velociraptor 2.1";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.frmSimMain_FormClosed);
            this.Load += new System.EventHandler(this.frmSimMain_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.TextBox txtLog;
        private System.Windows.Forms.TextBox txtLogSingleActDetails;
        private System.ComponentModel.BackgroundWorker bgWorker;
        private System.Windows.Forms.Button btnStartTestSim;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnExportTerrianGridOverlays;
        private System.Windows.Forms.Button btnAbout;
    }
}