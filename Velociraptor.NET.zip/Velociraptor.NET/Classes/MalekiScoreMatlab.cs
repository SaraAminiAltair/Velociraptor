﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Reflection;
using System.IO;
using MathWorks.MATLAB.NET.Arrays;
using MathWorks.MATLAB.NET.Utility;

#if SHARED
[assembly: System.Reflection.AssemblyKeyFile(@"")]
#endif


class MalekiScoreMatlab
: IDisposable
{
    #region Constructors

    /// <summary internal= "true">
    /// The static constructor instantiates and initializes the MATLAB Runtime instance.
    /// </summary>
    static MalekiScoreMatlab()
    {
        if (MWMCR.MCRAppInitialized)
        {
            try
            {
                Assembly assembly = Assembly.GetExecutingAssembly();

                string ctfFilePath = assembly.Location;

                int lastDelimiter = ctfFilePath.LastIndexOf(@"\");

                ctfFilePath = ctfFilePath.Remove(lastDelimiter, (ctfFilePath.Length - lastDelimiter));

                string ctfFileName = "malekifis.ctf";

                Stream embeddedCtfStream = null;

                String[] resourceStrings = assembly.GetManifestResourceNames();

                foreach (String name in resourceStrings)
                {
                    if (name.Contains(ctfFileName))
                    {
                        embeddedCtfStream = assembly.GetManifestResourceStream(name);
                        break;
                    }
                }
                mcr = new MWMCR("",
                               ctfFilePath, embeddedCtfStream, true);
            }
            catch (Exception ex)
            {
                ex_ = new Exception("MWArray assembly failed to be initialized", ex);
            }
        }
        else
        {
            ex_ = new ApplicationException("MWArray assembly could not be initialized");
        }
    }


    /// <summary>
    /// Constructs a new instance of the Class4 class.
    /// </summary>
    public MalekiScoreMatlab()
    {
        if (ex_ != null)
        {
            throw ex_;
        }
    }


    #endregion Constructors

    #region Finalize

    /// <summary internal= "true">
    /// Class destructor called by the CLR garbage collector.
    /// </summary>
    ~MalekiScoreMatlab()
    {
        Dispose(false);
    }


    /// <summary>
    /// Frees the native resources associated with this object
    /// </summary>
    public void Dispose()
    {
        Dispose(true);

        GC.SuppressFinalize(this);
    }


    /// <summary internal= "true">
    /// Internal dispose function
    /// </summary>
    protected virtual void Dispose(bool disposing)
    {
        if (!disposed)
        {
            disposed = true;

            if (disposing)
            {
                // Free managed resources;
            }

            // Free native resources
        }
    }


    #endregion Finalize

    #region Methods

    /// <summary>
    /// Provides a single output, 0-input MWArrayinterface to the FIS_Call MATLAB
    /// function.
    /// </summary>
    /// <remarks>
    /// M-Documentation:
    /// Evaluate the FIS when the first input is 2 and the second input is 1.
    /// x=evalfis([a b c],fis);
    /// </remarks>
    /// <returns>An MWArray containing the first output argument.</returns>
    ///
    public MWArray FIS_Call()
    {
        return mcr.EvaluateFunction("FIS_Call", new MWArray[] { });
    }


    /// <summary>
    /// Provides a single output, 1-input MWArrayinterface to the FIS_Call MATLAB
    /// function.
    /// </summary>
    /// <remarks>
    /// M-Documentation:
    /// Evaluate the FIS when the first input is 2 and the second input is 1.
    /// x=evalfis([a b c],fis);
    /// </remarks>
    /// <param name="availability">Input argument #1</param>
    /// <returns>An MWArray containing the first output argument.</returns>
    ///
    public MWArray FIS_Call(MWArray availability)
    {
        return mcr.EvaluateFunction("FIS_Call", availability);
    }


    /// <summary>
    /// Provides a single output, 2-input MWArrayinterface to the FIS_Call MATLAB
    /// function.
    /// </summary>
    /// <remarks>
    /// M-Documentation:
    /// Evaluate the FIS when the first input is 2 and the second input is 1.
    /// x=evalfis([a b c],fis);
    /// </remarks>
    /// <param name="availability">Input argument #1</param>
    /// <param name="throughput">Input argument #2</param>
    /// <returns>An MWArray containing the first output argument.</returns>
    ///
    public MWArray FIS_Call(MWArray availability, MWArray throughput)
    {
        return mcr.EvaluateFunction("FIS_Call", availability, throughput);
    }


    /// <summary>
    /// Provides a single output, 3-input MWArrayinterface to the FIS_Call MATLAB
    /// function.
    /// </summary>
    /// <remarks>
    /// M-Documentation:
    /// Evaluate the FIS when the first input is 2 and the second input is 1.
    /// x=evalfis([a b c],fis);
    /// </remarks>
    /// <param name="availability">Input argument #1</param>
    /// <param name="throughput">Input argument #2</param>
    /// <param name="energyRemaining">Input argument #3</param>
    /// <returns>An MWArray containing the first output argument.</returns>
    ///
    public MWArray FIS_Call(MWArray availability, MWArray throughput, MWArray
                      energyRemaining)
    {
        return mcr.EvaluateFunction("FIS_Call", availability, throughput, energyRemaining);
    }


    /// <summary>
    /// Provides a single output, 4-input MWArrayinterface to the FIS_Call MATLAB
    /// function.
    /// </summary>
    /// <remarks>
    /// M-Documentation:
    /// Evaluate the FIS when the first input is 2 and the second input is 1.
    /// x=evalfis([a b c],fis);
    /// </remarks>
    /// <param name="availability">Input argument #1</param>
    /// <param name="throughput">Input argument #2</param>
    /// <param name="energyRemaining">Input argument #3</param>
    /// <param name="speed">Input argument #4</param>
    /// <returns>An MWArray containing the first output argument.</returns>
    ///
    public MWArray FIS_Call(MWArray availability, MWArray throughput, MWArray
                      energyRemaining, MWArray speed)
    {
        return mcr.EvaluateFunction("FIS_Call", availability, throughput, energyRemaining, speed);
    }


    /// <summary>
    /// Provides a single output, 5-input MWArrayinterface to the FIS_Call MATLAB
    /// function.
    /// </summary>
    /// <remarks>
    /// M-Documentation:
    /// Evaluate the FIS when the first input is 2 and the second input is 1.
    /// x=evalfis([a b c],fis);
    /// </remarks>
    /// <param name="availability">Input argument #1</param>
    /// <param name="throughput">Input argument #2</param>
    /// <param name="energyRemaining">Input argument #3</param>
    /// <param name="speed">Input argument #4</param>
    /// <param name="stability">Input argument #5</param>
    /// <returns>An MWArray containing the first output argument.</returns>
    ///
    public MWArray FIS_Call(MWArray availability, MWArray throughput, MWArray
                      energyRemaining, MWArray speed, MWArray stability)
    {
        return mcr.EvaluateFunction("FIS_Call", availability, throughput, energyRemaining, speed, stability);
    }


    /// <summary>
    /// Provides the standard 0-input MWArray interface to the FIS_Call MATLAB function.
    /// </summary>
    /// <remarks>
    /// M-Documentation:
    /// Evaluate the FIS when the first input is 2 and the second input is 1.
    /// x=evalfis([a b c],fis);
    /// </remarks>
    /// <param name="numArgsOut">The number of output arguments to return.</param>
    /// <returns>An Array of length "numArgsOut" containing the output
    /// arguments.</returns>
    ///
    public MWArray[] FIS_Call(int numArgsOut)
    {
        return mcr.EvaluateFunction(numArgsOut, "FIS_Call", new MWArray[] { });
    }


    /// <summary>
    /// Provides the standard 1-input MWArray interface to the FIS_Call MATLAB function.
    /// </summary>
    /// <remarks>
    /// M-Documentation:
    /// Evaluate the FIS when the first input is 2 and the second input is 1.
    /// x=evalfis([a b c],fis);
    /// </remarks>
    /// <param name="numArgsOut">The number of output arguments to return.</param>
    /// <param name="availability">Input argument #1</param>
    /// <returns>An Array of length "numArgsOut" containing the output
    /// arguments.</returns>
    ///
    public MWArray[] FIS_Call(int numArgsOut, MWArray availability)
    {
        return mcr.EvaluateFunction(numArgsOut, "FIS_Call", availability);
    }


    /// <summary>
    /// Provides the standard 2-input MWArray interface to the FIS_Call MATLAB function.
    /// </summary>
    /// <remarks>
    /// M-Documentation:
    /// Evaluate the FIS when the first input is 2 and the second input is 1.
    /// x=evalfis([a b c],fis);
    /// </remarks>
    /// <param name="numArgsOut">The number of output arguments to return.</param>
    /// <param name="availability">Input argument #1</param>
    /// <param name="throughput">Input argument #2</param>
    /// <returns>An Array of length "numArgsOut" containing the output
    /// arguments.</returns>
    ///
    public MWArray[] FIS_Call(int numArgsOut, MWArray availability, MWArray throughput)
    {
        return mcr.EvaluateFunction(numArgsOut, "FIS_Call", availability, throughput);
    }


    /// <summary>
    /// Provides the standard 3-input MWArray interface to the FIS_Call MATLAB function.
    /// </summary>
    /// <remarks>
    /// M-Documentation:
    /// Evaluate the FIS when the first input is 2 and the second input is 1.
    /// x=evalfis([a b c],fis);
    /// </remarks>
    /// <param name="numArgsOut">The number of output arguments to return.</param>
    /// <param name="availability">Input argument #1</param>
    /// <param name="throughput">Input argument #2</param>
    /// <param name="energyRemaining">Input argument #3</param>
    /// <returns>An Array of length "numArgsOut" containing the output
    /// arguments.</returns>
    ///
    public MWArray[] FIS_Call(int numArgsOut, MWArray availability, MWArray throughput,
                        MWArray energyRemaining)
    {
        return mcr.EvaluateFunction(numArgsOut, "FIS_Call", availability, throughput, energyRemaining);
    }


    /// <summary>
    /// Provides the standard 4-input MWArray interface to the FIS_Call MATLAB function.
    /// </summary>
    /// <remarks>
    /// M-Documentation:
    /// Evaluate the FIS when the first input is 2 and the second input is 1.
    /// x=evalfis([a b c],fis);
    /// </remarks>
    /// <param name="numArgsOut">The number of output arguments to return.</param>
    /// <param name="availability">Input argument #1</param>
    /// <param name="throughput">Input argument #2</param>
    /// <param name="energyRemaining">Input argument #3</param>
    /// <param name="speed">Input argument #4</param>
    /// <returns>An Array of length "numArgsOut" containing the output
    /// arguments.</returns>
    ///
    public MWArray[] FIS_Call(int numArgsOut, MWArray availability, MWArray throughput,
                        MWArray energyRemaining, MWArray speed)
    {
        return mcr.EvaluateFunction(numArgsOut, "FIS_Call", availability, throughput, energyRemaining, speed);
    }


    /// <summary>
    /// Provides the standard 5-input MWArray interface to the FIS_Call MATLAB function.
    /// </summary>
    /// <remarks>
    /// M-Documentation:
    /// Evaluate the FIS when the first input is 2 and the second input is 1.
    /// x=evalfis([a b c],fis);
    /// </remarks>
    /// <param name="numArgsOut">The number of output arguments to return.</param>
    /// <param name="availability">Input argument #1</param>
    /// <param name="throughput">Input argument #2</param>
    /// <param name="energyRemaining">Input argument #3</param>
    /// <param name="speed">Input argument #4</param>
    /// <param name="stability">Input argument #5</param>
    /// <returns>An Array of length "numArgsOut" containing the output
    /// arguments.</returns>
    ///


    public double FIS_Call_Maleki(float availability, float throughput,
                    float energyRemaining, float speed, float stability)
    {
        MWArray av = (MWArray)0.5;
        MWArray tr = (MWArray)0.5;
        MWArray en = (MWArray)0.5;
        MWArray sp = (MWArray)0.5;
        MWArray st = (MWArray)0.5;
        MWArray[] res = FIS_Call(1, av, tr, en, sp, st);
        double val = Convert.ToDouble(res[0]);
        return val
          ;
    }
    public MWArray[] FIS_Call(int numArgsOut, MWArray availability, MWArray throughput,
                        MWArray energyRemaining, MWArray speed, MWArray stability)
    {
        return mcr.EvaluateFunction(numArgsOut, "FIS_Call", availability, throughput, energyRemaining, speed, stability);
    }


    /// <summary>
    /// Provides an interface for the FIS_Call function in which the input and output
    /// arguments are specified as an array of MWArrays.
    /// </summary>
    /// <remarks>
    /// This method will allocate and return by reference the output argument
    /// array.<newpara></newpara>
    /// M-Documentation:
    /// Evaluate the FIS when the first input is 2 and the second input is 1.
    /// x=evalfis([a b c],fis);
    /// </remarks>
    /// <param name="numArgsOut">The number of output arguments to return</param>
    /// <param name= "argsOut">Array of MWArray output arguments</param>
    /// <param name= "argsIn">Array of MWArray input arguments</param>
    ///
    public void FIS_Call(int numArgsOut, ref MWArray[] argsOut, MWArray[] argsIn)
    {
        mcr.EvaluateFunction("FIS_Call", numArgsOut, ref argsOut, argsIn);
    }



    /// <summary>
    /// This method will cause a MATLAB figure window to behave as a modal dialog box.
    /// The method will not return until all the figure windows associated with this
    /// component have been closed.
    /// </summary>
    /// <remarks>
    /// An application should only call this method when required to keep the
    /// MATLAB figure window from disappearing.  Other techniques, such as calling
    /// Console.ReadLine() from the application should be considered where
    /// possible.</remarks>
    ///
    public void WaitForFiguresToDie()
    {
        mcr.WaitForFiguresToDie();
    }



    #endregion Methods

    #region Class Members

    private static MWMCR mcr = null;

    private static Exception ex_ = null;

    private bool disposed = false;

    #endregion Class Members
}

