﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


public class SimuCfg
{
    public SchedulingProfile schedulingProfile;
    public int cpuBaseLineMIPS;
    public CloudSpec cloudSpec;
    public FogSpec fogSpec;
    public IoTSpec ioTSpec;
    public TerrainSpec terrainSpec;
    public JobGenerationSpec jobGenerationProfile;
    public int simulationMaxStep;
    public NetworkProfile networkProfile;
    public bool DoLogEachStep = true;
    public bool DoLogCells = true;
    public int ClusteringAndDataTransmisionAlgorithm; //from class TransmitAlgorithms

    public class Terrain
    {
        public LocationProfile.GridOverlay TerrianGrid;
        public int SpeedMaxAllowed, SpeedMinAllowed;
        public int WaitAtLocationMax, WaitAtLocationMin;
        public Terrain(SimuCfg.TerrainSpec spec)
        {
            this.TerrianGrid = spec.TerrianGrid;
            this.SpeedMaxAllowed = spec.SpeedMaxAllowed;
            this.SpeedMinAllowed = spec.SpeedMinAllowed;
            this.WaitAtLocationMax = spec.WaitAtLocationMax;
            this.WaitAtLocationMin = spec.WaitAtLocationMin;
        }


    }
    public class NetworkProfile
    {
        public int PercentOfNodesWhichGenerateDataInEachStep;
        public int CountOfPacketsToBeGeneratedByNode;
        public int PacketSizeMin_inKB, PacketSizeMax_inKB;
        public int TTL_of_Start = 10;// in TCP/IP it usually assumed: TTL=64
        public int PriorityMin, PriorityMax;
        public NetworkFailureModel networkFailureModel = new NetworkFailureModel();
        public int DataTransferMaxLimitForScoreCalculation_inKB;//in Mega Bytes. Used for normalization in score calculation algorithm
        public int DataTransferAging_inKB;// In Kilo Bytes. Amount to decrease (aging) from data transered field of node (which is used for score calculation)
        public ClusteringWifiProfile clusteringWifiProfile = new ClusteringWifiProfile();
        public class NetworkFailureModel
        {
            //reference for these values can be obtained from 
            //      D. Baltrunas, A. Elmokashfi, A. Kvalbein and Ö. Alay, "Investigating packet loss in mobile broadband networks under mobility," 2016 IFIP Networking Conference (IFIP Networking) and Workshops, Vienna, 2016, pp. 225-233, doi: 10.1109/IFIPNetworking.2016.7497225.
            //      doi: 10.1109/IFIPNetworking.2016.7497225
            public double ProbablityOfWifiLostPacket = 0.04;
            public double ProbablityOfCellularLostPacket = 0.15;
            public double ProbablityOfBluetoothLostPacket = 0.03;

            public double ProbablityOfCellularInfrastructureLossPacket_InsideSystem;
            public double ProbablityOfNodesHasInherentNetworkMalfunction;
            public double ProbablityOfNodeWithMalfunctioningNetworkInterfaceLossesPackets;

        }

        public class ClusteringWifiProfile
        {

            public int MaximumAllowableClusterHeadMemberCount;

        }



    }

    SimuCfg(bool _DoLogEachStep, bool DoLogCells, int _SimulationMaxStep, int _TransmitAlgorithm, int _CpuBaseLineMIPS, CloudSpec _cloudSpec, FogSpec _fogSpec, IoTSpec _ioTSpec, TerrainSpec _terrainSpec, JobGenerationSpec _jobGenerationProfile, NetworkProfile _networkprofile, SchedulingProfile _schedulingProfile)
    {
        this.DoLogEachStep = _DoLogEachStep;
        this.schedulingProfile = _schedulingProfile;
        this.networkProfile = _networkprofile;
        this.cpuBaseLineMIPS = _CpuBaseLineMIPS;
        this.cloudSpec = _cloudSpec; fogSpec = _fogSpec;
        this.ioTSpec = _ioTSpec;
        this.terrainSpec = _terrainSpec;
        this.jobGenerationProfile = _jobGenerationProfile;
        this.simulationMaxStep = _SimulationMaxStep;
        this.ClusteringAndDataTransmisionAlgorithm = _TransmitAlgorithm;
        this.DoLogCells = DoLogCells;
    }


    public class TerrainSpec
    {

        public int SpeedMaxAllowed, SpeedMinAllowed;
        public int WaitAtLocationMax, WaitAtLocationMin;
        public readonly LocationProfile.GridOverlay TerrianGrid;
        public TerrainSpec(LocationProfile.GridOverlay terrianGrid, int speedMaxAllowed, int speedMinAllowed, int waitAtLocationMax, int waitAtLocationMin)
        {
            this.TerrianGrid = terrianGrid;
            this.SpeedMaxAllowed = speedMaxAllowed;
            this.SpeedMinAllowed = speedMinAllowed;
            this.WaitAtLocationMax = waitAtLocationMax;
            this.WaitAtLocationMin = waitAtLocationMin;
        }

    }

    public class JobGenerationSpec
    {
        public int MaxSimulationTimeToGenerateNewJobs;
        public int CountOfDags;
        public int CountOfTasksInDagMin, CountOfTasksInDagMax;
        public int TasksCPUNeedMin, TasksCPUNeedMax, TasksMemNeedMin, TasksMemNeedMax, TasksStorageNeedMin, TasksStorageNeedMax, MaxCountOfResourcesEachTaskMayNeed;
        public double MaxConnectivity;
        public int Deadline_PercentageOfTaskSize_Min, Deadline_PercentageOfTaskSize_Max;
        public int EdgeWeightMin, EdgeWeightMax;
        public int[] NeededResourceTypes;
        public bool AllowDynamicCountOfReForwarding = false;
    }

    public class FogSpec
    {
        public int MinCountOfFogProviders, MaxCountOfFogProviders;
        public int MinCountOfFogProviderFogPoint, MaxCountOfFogProviderFogPoint;
        public int MinCountOfNodesInFogPointCluster, MaxCountOfNodesInFogPointCluster;
        public bool isFogMobile;
    }
    public class CloudSpec
    {
        public int MinCountOfCloudProviders, MaxCountOfCloudProviders;
        public int MinCountOfCloudProvidersDataCenters, MaxCountOfCloudProvidersDataCenters;
        public int MinCountOfClustersInDataCenter, MaxCountOfClustersInDataCenter;
        public int MinCountOfNodesInDCCluster, MaxCountOfNodesInDCCluster;

    }

    public class IoTSpec
    {
        public int CountOfIoTNodes;
        public bool isIoTMobile;
    }


    public static class TransmitAlgorithms
    {
        public static int Esfandiari = 1, DFSCA = 2, SBCA = 3, WCA = 4, Cell = 5, Partovi = 6, Maleki = 7, Hajvali = 8;
    }


    public class SchedulingProfile
    {
        public static class SchedulingAlgorithms
        {
            public const int
                  HajvaliInFog = 11
                , HajvaliInDCCluster = 12
                , DavamiInFog = 1 //Fatemeh Davam
                , DavamiInDCCluster = 2 //Fatemeh Davami
                , GHeft_Cloud = 3
                , GHeft_Fog = 4
                // , Nakh = 3  // Narges Akhoond
                // , Mohammadi = 4
                , GeneralForIoTNodes = 10 // just forward the jobs to the cluster head or neighbors
                ;
        }
        public int AlgInFogPoint, AlgInCloudCluster, AlgInIoT;
    }


    public static SimuCfg ExperimentSettings(int CpuBaseLineMIPS)
    {
        bool _DoLogEachStep = true;
        bool _DoLogCells = false;
        CloudSpec cloudSpec = new CloudSpec(); FogSpec fogSpec = new FogSpec(); IoTSpec ioTSpec = new IoTSpec();
        JobGenerationSpec jobGenerationSpec = new JobGenerationSpec();

        SchedulingProfile scheduleProfile = new SchedulingProfile
        {
            AlgInIoT = SchedulingProfile.SchedulingAlgorithms.GeneralForIoTNodes,
            AlgInFogPoint = SchedulingProfile.SchedulingAlgorithms.HajvaliInFog,
            AlgInCloudCluster = SchedulingProfile.SchedulingAlgorithms.HajvaliInDCCluster
        };
        int TransmitAlgorithm = TransmitAlgorithms.Hajvali;

        int gridWidth = 5000; //25000
        int gridHeight = 5000; //8000
        int cellWidth = 500;
        int max = (Math.Max(gridWidth, gridHeight));
        if (max < 500)
        {
            gridWidth = gridHeight = 1000;
        }
        if (gridWidth % cellWidth != 0) gridWidth = ((gridWidth / cellWidth) + 1) * gridWidth;
        if (gridHeight % cellWidth != 0) gridHeight = ((gridHeight / cellWidth) + 1) * gridWidth;
        int speedMaxAllowed = 18;//12
        int speedMinAllowed = 2;//22
        int waitAtLocationMin = 10;
        int waitAtLocationMax = 10 + 300 / 12; //? zz
        


        ioTSpec.isIoTMobile = true;
        int SimulationSteps = 1000;// 60*12;          //steps
        jobGenerationSpec.MaxSimulationTimeToGenerateNewJobs = 800;// Math.Max(30, SimulationSteps - 700);
        ioTSpec.CountOfIoTNodes = 180;                       //50  MUST BE COEFFICIENT OF 10, e.g. 10 or 20 or 30, ...
        if (ioTSpec.CountOfIoTNodes % 10 != 0) ioTSpec.CountOfIoTNodes = ((ioTSpec.CountOfIoTNodes / 10) + 1) * 10;
        jobGenerationSpec.CountOfDags = 200;//60



        //job creation for DSL-
        //jobGenerationSpec.CountOfTasksInDagMin = 15;    jobGenerationSpec.CountOfTasksInDagMax = 15;

        //jobGenerationSpec.CountOfTasksInDagMin = 6; jobGenerationSpec.CountOfTasksInDagMax = 30;
        jobGenerationSpec.CountOfTasksInDagMin = 40; jobGenerationSpec.CountOfTasksInDagMax = 50;
        //jobGenerationSpec.CountOfTasksInDagMin = 2; jobGenerationSpec.CountOfTasksInDagMax = 4;


        //job creation for DSL-70
        //jobGenerationSpec.CountOfTasksInDagMin = 30;    jobGenerationSpec.CountOfTasksInDagMax = 70;

        //job creation for DSL-125
        //jobGenerationSpec.CountOfTasksInDagMin = 71;       jobGenerationSpec.CountOfTasksInDagMax = 125;

        jobGenerationSpec.EdgeWeightMin = 2; //MB
        jobGenerationSpec.EdgeWeightMax = 15;//80 MB
        jobGenerationSpec.TasksMemNeedMin = 20;// MB
        jobGenerationSpec.TasksMemNeedMax = 4000;// MB
        jobGenerationSpec.TasksStorageNeedMin = 1;  // MB
        jobGenerationSpec.TasksStorageNeedMax = 400;// MB
        jobGenerationSpec.MaxCountOfResourcesEachTaskMayNeed = 2;

        int[] resTypes = { 110, 120, 125, 133, 155, 12, 22, 86 };
        jobGenerationSpec.NeededResourceTypes = resTypes;

        NetworkProfile networkProfile = new NetworkProfile();
        networkProfile.clusteringWifiProfile.MaximumAllowableClusterHeadMemberCount = 25;
        networkProfile.PacketSizeMax_inKB = 4096;//  Kilo bytes
        networkProfile.PacketSizeMin_inKB = 1300;//   kilo bytes

        //

        //------------------------------------------------changes------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
        //JOB DEAD LINE IN FILE job.cs line 634
        jobGenerationSpec.AllowDynamicCountOfReForwarding = true;
        jobGenerationSpec.Deadline_PercentageOfTaskSize_Min = 20;//60
        jobGenerationSpec.Deadline_PercentageOfTaskSize_Max = 30;//100  //note: it is in PERCENT

        jobGenerationSpec.MaxConnectivity = 0.05; //for HV 0.05 
        jobGenerationSpec.TasksCPUNeedMin = Convert.ToInt32(Math.Ceiling((float)CpuBaseLineMIPS * 2.9)); // *0.6 MI  a task is at least one second on baseline cpu
        jobGenerationSpec.TasksCPUNeedMax = Convert.ToInt32(CpuBaseLineMIPS * 3);// MI //HV 0.7
        networkProfile.networkFailureModel.ProbablityOfCellularLostPacket = 0.22; //0.19
        networkProfile.CountOfPacketsToBeGeneratedByNode = 3;// no of packets   4
        networkProfile.PercentOfNodesWhichGenerateDataInEachStep = 35; //32
        networkProfile.networkFailureModel.ProbablityOfWifiLostPacket = 0.08; // 0.001 for HV
        networkProfile.networkFailureModel.ProbablityOfCellularInfrastructureLossPacket_InsideSystem = 0.08; //0.04
        //-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

        networkProfile.DataTransferAging_inKB = Convert.ToInt32(((float)networkProfile.PercentOfNodesWhichGenerateDataInEachStep / 100) * (networkProfile.CountOfPacketsToBeGeneratedByNode + 1) * ((networkProfile.PacketSizeMax_inKB)));
        networkProfile.TTL_of_Start = 10;
        networkProfile.PriorityMin = 0;
        networkProfile.PriorityMax = 0;
        networkProfile.DataTransferMaxLimitForScoreCalculation_inKB = Convert.ToInt32(100 * (networkProfile.PacketSizeMax_inKB + networkProfile.PacketSizeMin_inKB) / (float)2); // 100  Mega bytes
        networkProfile.networkFailureModel.ProbablityOfNodesHasInherentNetworkMalfunction = 0.02;
        networkProfile.networkFailureModel.ProbablityOfNodeWithMalfunctioningNetworkInterfaceLossesPackets = 0.01;

        cloudSpec.MaxCountOfCloudProviders = cloudSpec.MinCountOfCloudProviders = 1; //3
        cloudSpec.MaxCountOfCloudProvidersDataCenters = 1;//7                1
        cloudSpec.MinCountOfCloudProvidersDataCenters = 1; //5               1
        cloudSpec.MaxCountOfClustersInDataCenter = 3; //3                    1
        cloudSpec.MinCountOfClustersInDataCenter = 3;//3                     1
        cloudSpec.MaxCountOfNodesInDCCluster = 5; //3                       40
        cloudSpec.MinCountOfNodesInDCCluster = 20;//3                        40

        fogSpec.isFogMobile = false;
        fogSpec.MaxCountOfFogProviders = fogSpec.MinCountOfFogProviders = 1; //6
        fogSpec.MaxCountOfFogProviderFogPoint = 3; //8           1
        fogSpec.MinCountOfFogProviderFogPoint = 3; //8          1
        fogSpec.MaxCountOfNodesInFogPointCluster = 10; //4      25
        fogSpec.MinCountOfNodesInFogPointCluster = 10;//4       25
        LocationProfile.GridOverlay grid;
        grid = LocationProfile.GridOverlay.GenerateSimpleSquareGrid(cellWidth, gridWidth, gridHeight);
        TerrainSpec terrainSpec = new TerrainSpec(grid, speedMaxAllowed, speedMinAllowed, waitAtLocationMax, waitAtLocationMin);

        SimuCfg simuConfig = new SimuCfg(_DoLogEachStep, _DoLogCells, SimulationSteps, TransmitAlgorithm, CpuBaseLineMIPS, cloudSpec, fogSpec, ioTSpec, terrainSpec, jobGenerationSpec, networkProfile, scheduleProfile);
        return simuConfig;
    }




}
