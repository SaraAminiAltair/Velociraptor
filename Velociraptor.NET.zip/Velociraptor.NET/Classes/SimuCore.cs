﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Serialization;
using Velociraptor.Classes;

public class SimuCore
{
    bool doLogOnDatabase;

    public bool isTerrainInited = false;
    public bool isJobsGenerated = false;
    public CoUtils cu = new CoUtils();
    public DAL DAL = new DAL();

    public SimuData simuDB;



    public string Log = "";
    Thread threadMainForSimulation;
    Thread threadJobCreation;

    public bool isSimulationRunning = false, isJobGenerationRunning = false;
    private ManualResetEvent resetEvent = new ManualResetEvent(true);


    TextBox LogAcc, LogSingle;
    int CurrentSimulationTime = 0;
    public bool isFinished = false;
    public SimuCfg simulationConfig;
    public SimuCore(SimuCfg _simulationConfig)
    {
        DAL d = new DAL();
        this.simuDB = new SimuData(d);
        simulationConfig = _simulationConfig;

    }


    public void SimulationRun(TextBox reportBox, bool _doLogonDatabase)
    {
        doLogOnDatabase = _doLogonDatabase;
        if (this.isSimulationRunning)
        {
            return;
        }

        var watch = Stopwatch.StartNew();
        List<Task> tasks = new List<Task>();
        var t = Task.Factory.StartNew(() =>
        {

            GenerateRandomTerrainAndNodes(reportBox, true, simulationConfig);
        });
        tasks.Add(t);
        Task.Factory.ContinueWhenAll(tasks.ToArray(),
              result =>
              {
                  var time = watch.ElapsedMilliseconds;
                  InitAndRunSimWorker();

              });
    }

    void InitAndRunSimWorker()
    {
        CurrentSimulationTime = 0;
        /*
        threadMainForSimulation = new Thread(SimulationMainWorker);
        threadMainForSimulation.IsBackground = true;
        threadMainForSimulation.Start();
        */
        object value = null; // Used to store the return value
        var thread = new Thread(
          () =>
          {
              SimuData SimuDB_AfterSimulationEnded = SimulationMainWorker();

          });
        thread.Start();
        thread.Join();

    }

    public void DrawAndSaveGrid()
    {
        delWriteLog(true, "Loading node info to grid cells...");
        simuDB.terrain.TerrianGrid.LoadNodesToGrid(this.simuDB.Nodes);
        delWriteLog(true, "Generating grid images...");

        Velociraptor.frmTerrian formTerrian = new Velociraptor.frmTerrian();
        //formTerrian.Show();
        System.GC.Collect();
        formTerrian.DrawGrid(this.simuDB);
        delWriteLog(true, "Grid images exported as files.");
        formTerrian.Close();
        formTerrian.Dispose();


    }








    void WriteJobRecordsToDBForPredict()
    {
        Workload wl = new Workload(this.simuDB.JobsAll);
        PredictionRecordLogger.LogCollectionOfRecordsOnDB(simuDB, PredictionRecord.GenerateListOfPredictionRecords(wl));
    }

    void WriteJobRecordsToDBForPredict2()
    {
        foreach (var job in this.simuDB.JobsAll)
        {
            decimal[] InputVector = new decimal[64];

            InputVector[0] = job.Tasks.Count;
            InputVector[1] = job.Edges.Count;
            InputVector[2] = job.MaxEdgeWeight;
            InputVector[3] = job.EFT_DAG - job.TimeSubmission;
            InputVector[4] = job.MinEdgeWeight;
            InputVector[5] = (decimal)job.MaxTaskSize / 1000000;
            InputVector[6] = (decimal)job.MinTaskSize / 1000000;

            //InputVector[4] = (decimal)job.CriticalPath_Size;

            decimal OutputValueReal = job.MaxParallelExecutableTasks;
            ComputerNode.NodeScheduling_Davami_WriteTrainingRecord(this.simuDB, InputVector, OutputValueReal);
        }
    }

    public string ListToString(List<SimuData.CloudProvider> _list)
    {
        string s = "[";
        foreach (var n in _list)
        {
            if (s != "[") s += ",";
            s += n.CloudProviderID.ToString();
        }
        s += "]";
        return s;
    }
    public string ListToString(List<SimuData.FogProvider> _list)
    {
        string s = "[";
        foreach (var n in _list)
        {
            if (s != "[") s += ",";
            s += n.FogProviderID.ToString();
        }
        s += "]";
        return s;
    }
    public string ListToString(List<SimuData.FogPoint> _list)
    {
        string s = "[";
        foreach (var n in _list)
        {
            if (s != "[") s += ",";
            s += n.FogPointID.ToString();
        }
        s += "]";
        return s;
    }
    public string ListToString(List<SimuData.Cluster> _list)
    {
        string s = "[";
        foreach (var n in _list)
        {
            if (s != "[") s += ",";
            s += n.ClusterID.ToString();
        }
        s += "]";
        return s;
    }
    public string ListToString(List<SimuData.DataCenter> _list)
    {
        string s = "[";
        foreach (var n in _list)
        {
            if (s != "[") s += ",";
            s += n.DataCenterID.ToString();
        }
        s += "]";
        return s;
    }

    private string GetEnvironmentSetting()
    {
        List<SimuData.CloudProvider> cp = simuDB.CloudProviders;
        List<SimuData.FogProvider> fprov = simuDB.FogProviders;
        List<SimuData.Cluster> cl = simuDB.Clusters;
        List<SimuData.FogPoint> fpoints = simuDB.FogPoints;
        List<SimuData.DataCenter> dc = simuDB.DataCenters;

        string s = "";
        s = "CloudProviders:" + ListToString(cp) + Environment.NewLine;
        s += "FogProviders:" + ListToString(fprov) + Environment.NewLine;
        s += "Datacenters:" + ListToString(dc) + Environment.NewLine;

        s += "Clusters:" + ListToString(cl) + Environment.NewLine;
        s += "FogPoints:" + ListToString(fpoints) + Environment.NewLine;

        return s;

    }


    private SimuData SimulationMainWorker()
    {

        string env = GetEnvironmentSetting();
        delWriteLog(false, env);
        delWriteLog(true, "Preparing random job generator...");
        JobGeneratorWorker();
        delWriteLog(true, "All jobs were generated.");


        isSimulationRunning = true;

        delWriteLog(true, "Perform some startup tasks...");

        this.simuDB.SchedulingLog_Jobs_CountOfSubmitted = this.simuDB.JobsAll.Count;
        int c = 0;
        foreach (Job job in this.simuDB.JobsAll) c = c + job.Tasks.Count;
        this.simuDB.SchedulingLog_Tasks_CountOfSubmitted = c;


        BeforeStartDatabaseTasks();
        SimuData.SetCoordinatorsForFogsAndDCs_Randomly(this.simuDB);
        this.simuDB.SchedulingLog_Nodes_CountBusyExecutingTasks = new int[simulationConfig.simulationMaxStep + 1];
        this.simuDB.SchedulingLog_Nodes_CountBusyPerformingScheduling = new int[simulationConfig.simulationMaxStep + 1];


        WriteJobRecordsToDBForPredict();

        delWriteLog(true, "Starting simulation...");

        for (int i = 1; i <= simulationConfig.simulationMaxStep; i++)
        {
            this.simuDB.SchedulingLog_Nodes_CountBusyExecutingTasks[i] = 0;
            this.simuDB.SchedulingLog_Nodes_CountBusyPerformingScheduling[i] = 0;

            PerformOneCycleOfAllNodes();
            CurrentSimulationTime++;
            resetEvent.WaitOne();
        }

        PerformLogs();
        delWriteLog(true, string.Format("Generating scheduling reports..."));

        string schLog = CreateSchedulingReport();
        delWriteLog(false, schLog);
        delWriteLog(true, string.Format("Scheduling reports generated."));


        for (int i = 0; i < simuDB.Nodes.Count; i++)
        {
            ComputerNode node = simuDB.Nodes[i];
            bool x1 = node.DataPacketQueues_Cellular3G.AreAllQueuesEmpty();
            bool x2 = node.DataPacketQueues_Wifi.AreAllQueuesEmpty();
            bool x3 = (node.DataPacketQueueGenerated.Queue.Count > 0);
            if (x3)
            {
                MessageBox.Show("A Node found with non-empty queues ");
            }
        }

        delWriteLog(true, string.Format("Finalizing simulation."));

        int SimID = FinalizeSimulation();
        delWriteLog(true, string.Format("All operations finished."));


        return simuDB;

    }

    int GetFinishTimeForLastSchduledTask()
    {

        DataTable dt = new DataTable();
        SqlConnection conn = DAL.getConnectionObject();
        if (conn.State != ConnectionState.Open) conn.Open();
        using (SqlCommand cmd = new SqlCommand("SP_ScheduleGetFinishTimeLastTask", conn))
        {
            cmd.CommandType = CommandType.StoredProcedure;
            SqlDataReader sdr = DAL.ExecuteQuery(cmd);
            Boolean b = sdr.HasRows;
            dt.Load(sdr);
            dt.TableName = "t";
            sdr.Close();
        }
        if ((dt != null) && (dt.Rows.Count > 0))
            return Convert.ToInt32(dt.Rows[0][0].ToString());
        else return 0;
    }
    string CreateSchedulingReport()
    {

        foreach (var j in simuDB.JobsAll)
        {
            if (j.GetJobStatus() == Job.JobAndTaskStatus.FullyScheduled)
            {
                j.TimeFinished = j.Tasks[j.Tasks.Count - 1].OnMachine_FinishTime;
                j.UpdateJobShcedulingInfo(simuDB, j.TimeFinished);
            }


        }



        string s = "";
        s = s + Environment.NewLine + "Jobs Submitted: " + this.simuDB.SchedulingLog_Jobs_CountOfSubmitted.ToString();
        s = s + Environment.NewLine + "Jobs Undergone Scheduling: " + this.simuDB.SchedulingLog_Jobs_CountOfUndergoneSchedulingProcess.ToString();
        s = s + Environment.NewLine + "Jobs Scheduled: " + this.simuDB.SchedulingLog_Jobs_CountOfScheduled.ToString();
        s = s + Environment.NewLine + "Jobs Rejected: " + this.simuDB.SchedulingLog_Jobs_CountOfRejected.ToString();
        s = s + Environment.NewLine + "Jobs Finished: " + this.simuDB.SchedulingLog_Jobs_CountOfFinished.ToString();
        s = s + Environment.NewLine + "Jobs Failed During Execution: " + this.simuDB.SchedulingLog_Jobs_CountOfFailedDuringExecution_BecauseOfHostCrashed.ToString();
        s = s + Environment.NewLine + "Jobs Failed for Deadline: " + this.simuDB.SchedulingLog_Jobs_CountOfFailedDuringExecution_DeadlinePassed.ToString();

        s = s + Environment.NewLine + "Tasks Submitted: " + this.simuDB.SchedulingLog_Tasks_CountOfSubmitted.ToString();
        s = s + Environment.NewLine + "Tasks Undergone Scheduling: " + this.simuDB.SchedulingLog_Tasks_CountOfUndergoneSchedulingProcess.ToString();
        s = s + Environment.NewLine + "Tasks Scheduled: " + this.simuDB.SchedulingLog_Tasks_CountOfScheduled.ToString();
        s = s + Environment.NewLine + "Tasks Rejected: " + this.simuDB.SchedulingLog_Tasks_CountOfRejected.ToString();
        s = s + Environment.NewLine + "Tasks Finished: " + this.simuDB.SchedulingLog_Tasks_CountOfFinished.ToString();
        s = s + Environment.NewLine + "Tasks Failed During Execution: " + this.simuDB.SchedulingLog_Tasks_CountOfFailedDuringExecution_BecauseOfHostCrashed.ToString();
        s = s + Environment.NewLine + "Tasks Failed for Deadline: " + this.simuDB.SchedulingLog_Tasks_CountOfFailedDuringExecution_DeadlinePassed.ToString();
        s = s + Environment.NewLine + Environment.NewLine;

        float Ratio_ScheduledTaskToAllTasks = 100 * (float)(this.simuDB.SchedulingLog_Tasks_CountOfScheduled) / this.simuDB.SchedulingLog_Tasks_CountOfSubmitted;
        float Ratio_ScheduledJobsToAllJobs = 100 * (float)(this.simuDB.SchedulingLog_Jobs_CountOfScheduled) / this.simuDB.SchedulingLog_Jobs_CountOfSubmitted;
        s = s + Environment.NewLine + "Ratio Scheduled Tasks To All Tasks:" + Ratio_ScheduledTaskToAllTasks.ToString() + "%";
        s = s + Environment.NewLine + "Ratio Scheduled Jobs To All Jobs:" + Ratio_ScheduledJobsToAllJobs.ToString() + "%";




        int maxTimetoConsider = GetFinishTimeForLastSchduledTask();
        foreach (var node in simuDB.Nodes)
        {
            string CH = "";
            if ((node.InFog_Fixed_OwnerFogPoint != null) && (node.InFog_Fixed_OwnerFogPoint.CurrentClusterHead.NodeID == node.NodeID))
            {
                CH = " (Fog CH) ";
            }
            else if ((node.InCloud_Fixed_OwnerCluster != null) && (node.InCloud_Fixed_OwnerCluster.CurrentClusterHead.NodeID == node.NodeID))
            {
                CH = "  (Cloud CH) ";
            }
            float uu = node.GetUtilizationCombined(-1);
            string r = " Utilization of Node " + node.NodeID + CH + ":    " + uu + "%";

            this.WriteUtilReport(node, uu);


            s = s + Environment.NewLine + r;
        }

        s = s + Environment.NewLine + Environment.NewLine + Environment.NewLine;
        /* foreach (var node in simuDB.Nodes)
         {
             string x = "";
             foreach (var job in simuDB.JobsSuccessfullyFinished)
             {
                 foreach(var task in job.Tasks)
                 {
                     if (task.NodeID_ScheduledOn == node.NodeID) x = x + Environment.NewLine + "Job:" + job.JobID + " Task:" + task.TaskID;
                 }

             }
             s = s + Environment.NewLine + "on Node:" + node.NodeID + " these jobs:" + Environment.NewLine;
         }
         
         */
        foreach (var job in simuDB.JobsSuccessfullyFinished)
        {
            int ccx = 1;
        }


        /*
           foreach (var job in simuDB.JobsAll)
           {
               if (((job.GetJobStatus() == Job.JobAndTaskStatus.FullyScheduled)) || ((job.GetJobStatus() == Job.JobAndTaskStatus.Completed)))
               {
                   string x = "Job: " + job.JobID;
                   foreach (var task in job.Tasks)
                   {
                       x = x + Environment.NewLine + " Task:" + task.TaskID + " on " + task.NodeID_ScheduledOn;
                   }
                   s = s + Environment.NewLine + x;
               }
           }

       */
        return s;

    }
    void WriteUtilReport(ComputerNode node, float utilization)
    {
        string cc = "", fc = "";
        if (node.InCloud_Fixed_OwnerCluster != null) cc = node.InCloud_Fixed_OwnerCluster.ClusterID;
        if (node.InFog_Fixed_OwnerFogPoint != null) fc = node.InFog_Fixed_OwnerFogPoint.FogPointID;
        SqlConnection sqlConn = simuDB.dal.getConnectionObject();

        if (sqlConn.State != ConnectionState.Open) sqlConn.Open();
        using (SqlCommand cmd = new SqlCommand("SP_NodeLogUtilization", sqlConn))
        {
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.Add("@NodeID", SqlDbType.NVarChar).Value = node.NodeID;
            cmd.Parameters.Add("@ClusterID", SqlDbType.NVarChar).Value = cc;
            cmd.Parameters.Add("@FogID", SqlDbType.NVarChar).Value = fc;
            cmd.Parameters.Add("@Utilization", SqlDbType.Float).Value = utilization;
            cmd.Parameters.Add("@Time", SqlDbType.Int).Value = this.CurrentSimulationTime;



            DAL.ExecuteNonQuery(cmd);
            //cmd.ExecuteNonQuery();

        }

    }
    void PerformLogs()
    {
        SqlConnection conn = DAL.getConnectionObject();
        int i = 1;
        delWriteLog(false, "Simulation finished. Writting logs to  database...");
        if (this.simulationConfig.DoLogEachStep)
        {
            delWriteLog(false, "Writting node logs to  database...");
            foreach (ComputerNode node in simuDB.Nodes)
            {

                node.Log_NodeSteps(conn);
                delWriteLog(true, string.Format("Logging node {0} of {1}", i.ToString(), simuDB.Nodes.Count.ToString()));
                i++;
                //zz other loggings here
            }
            if (this.simulationConfig.DoLogCells)
            {
                delWriteLog(false, "Writting cell logs to database...");
                delWriteLog(true, "Writting cell logs to database...");

                this.simuDB.terrain.TerrianGrid.WriteCellLogs(this.DAL.getConnectionObject());
                delWriteLog(false, "Finished writting cell logs.");

            }

        }
        delWriteLog(false, string.Format("Logging finished."));
        delWriteLog(true, string.Format("Logging finished."));



    }

    void BeforeStartDatabaseTasks()
    {
        if (simuDB.SimuConfig.ClusteringAndDataTransmisionAlgorithm == SimuCfg.TransmitAlgorithms.Maleki) CleanPredictionData_Maleki();
    }
    void CleanPredictionData_Maleki()
    {
        SqlConnection sqlconn = DAL.getConnectionObject();
        if ((sqlconn == null)) return;
        if (sqlconn.State != ConnectionState.Open) sqlconn.Open();
        using (SqlCommand cmd = new SqlCommand("SP_MalekiPrediction_CleanPredictions", sqlconn))
        {
            cmd.CommandType = CommandType.StoredProcedure;
            DAL.ExecuteNonQuery(cmd);
            //cmd.ExecuteNonQuery();
        }

    }

    private void PerformOneCycleOfAllNodes()
    {
        Cellular.DispachAllPacketsFromAbstractNode(this.simuDB, this.CurrentSimulationTime);
        foreach (ComputerNode node in this.simuDB.Nodes)
        {
            node.DoOneStepOfMainLoop(simuDB, CurrentSimulationTime, this.DAL.getConnectionObject());
            float u = node.GetUtilizationCombined(CurrentSimulationTime);
            this.WriteUtilReport(node, u);
        }
        PerformPostCycleTasks();
        delWriteLog(true, ("Current Simulation Step " + CurrentSimulationTime.ToString() + " of " + simulationConfig.simulationMaxStep.ToString()));

        System.GC.Collect();

    }

    void PerformPostCycleTasks()
    {
        //check for finished jobs
        foreach (var job in this.simuDB.JobsAll)
        {
            if (job.GetJobStatus() == Job.JobAndTaskStatus.FullyScheduled)
            {
                //if all tasks finished
                int CountOfFinishedTasks = 0;
                foreach (var task in job.Tasks)
                    if (task.GetTaskStatus() == Job.JobAndTaskStatus.Completed) CountOfFinishedTasks++;

                if (CountOfFinishedTasks == job.Tasks.Count)
                {
                    job.TimeActuallyFinised = this.CurrentSimulationTime;
                    job.SetJobStatus(this.simuDB, job.TimeActuallyFinised, Job.JobAndTaskStatus.Completed);
                    this.simuDB.SchedulingLog_Jobs_CountOfFinished++;
                }

            }
        }



        //add log item for cells
        if (this.simulationConfig.DoLogCells)
        {
            LocationProfile.GridOverlay grd = this.simuDB.terrain.TerrianGrid;
            for (int i = 0; i < grd.Cells.GetLength(0); i++)
            {
                for (int j = 0; j < grd.Cells.GetLength(1); j++)
                {
                    LocationProfile.GridCell c = grd.Cells[i, j];

                    int Time = this.CurrentSimulationTime, isThisCellReachable = cu.BoolToInt(c.isThisCellNotReachableGenerally()), CellRow = c.CellIndex_Y, CellCol = c.CellIndex_X
                        , CountOfRequest = 0, SumSizeOfRequests = 0
                        , CountOfIoTNodes = 0, CountOfFogNodes = 0, CountOfCloudNodes = 0
                        , CountOf_Idle_IoTNodes = 0, CountOf_Idle_FogNodes = 0, CountOf_Idle_CloudNodes = 0

                        , SumProcPowerIoT = 0, SumProcPowerFog = 0, SumProcPowerCloud = 0;
                    float RatioOfIdleCloudHosts = 0, RatioOfIdleFogHosts = 0, RatioOfIdleIoTHosts = 0;
                    string ListOfIoTNodes = "";

                    foreach (var node in this.simuDB.Nodes)
                    {
                        bool isThisNodeInThisCell = c.IsNodeInThisCell(node);
                        if ((isThisNodeInThisCell) && (node.isNodeAlive))
                        {
                            switch (node.NodeTypeAsString)
                            {
                                case "iot":
                                    CountOfIoTNodes++;
                                    SumProcPowerIoT += node.HardwareProfile.ComputerHardwareProfile.CPUProfile.CPUCurrentMIPS_hardware;
                                    if (node.isNodeIdle(CurrentSimulationTime)) CountOf_Idle_IoTNodes++;
                                    ListOfIoTNodes += "," + node.NodeID;
                                    break;
                                case "fog":
                                    CountOfFogNodes++;
                                    SumProcPowerFog += node.HardwareProfile.ComputerHardwareProfile.CPUProfile.CPUCurrentMIPS_hardware;
                                    if (node.isNodeIdle(CurrentSimulationTime)) CountOf_Idle_FogNodes++;

                                    break;
                                case "cloud":
                                    CountOfCloudNodes++;
                                    SumProcPowerCloud += node.HardwareProfile.ComputerHardwareProfile.CPUProfile.CPUCurrentMIPS_hardware;
                                    if (node.isNodeIdle(CurrentSimulationTime)) CountOf_Idle_CloudNodes++;
                                    break;
                            }
                        }


                    }
                    if (CountOfIoTNodes > 0) RatioOfIdleCloudHosts = (float)CountOf_Idle_IoTNodes / CountOfIoTNodes;
                    if (CountOfFogNodes > 0) RatioOfIdleFogHosts = (float)CountOf_Idle_FogNodes / CountOfFogNodes;
                    if (CountOfCloudNodes > 0) RatioOfIdleIoTHosts = (float)CountOf_Idle_CloudNodes / CountOfCloudNodes;

                    foreach (var job in simuDB.JobsAll)
                    {
                        foreach (var task in job.Tasks)
                        {
                            if ((task.TimeSubmission <= CurrentSimulationTime) && (task.TimeDeadlineFinal > CurrentSimulationTime))
                            {
                                string nid = "";
                                nid = task.NodeID_ScheduledOn;
                                if (nid == "") nid = task.NodeID_CurrentlyOn;
                                if (nid == "") nid = job.NodeID_CurrentlyOn;
                                if (nid == "") nid = job.NodeSubmitted;
                                if (nid == "") continue;
                                ComputerNode node = SimuData.GetNodeByID(nid, this.simuDB.Nodes);

                                LocationProfile.GridCell theCellThatTheDagCurrentlyIs = this.simuDB.terrain.TerrianGrid.GetCellForLocation(node);
                                if ((c.CellIndex_X == theCellThatTheDagCurrentlyIs.CellIndex_X) && (c.CellIndex_Y == theCellThatTheDagCurrentlyIs.CellIndex_Y))
                                {
                                    CountOfRequest++;
                                    SumSizeOfRequests += Convert.ToInt32(task.CpuNeed_Claimed);
                                }
                            }


                        }
                    }


                    LocationProfile.GridCell.CellLogInfo logInf = new LocationProfile.GridCell.CellLogInfo(Time, CellRow, CellCol, CountOfRequest, SumSizeOfRequests, CountOfIoTNodes, CountOfFogNodes, CountOfCloudNodes, SumProcPowerIoT, SumProcPowerFog, SumProcPowerCloud, RatioOfIdleCloudHosts, RatioOfIdleFogHosts, RatioOfIdleIoTHosts, ListOfIoTNodes, isThisCellReachable);

                    c.CellLogAddnew(logInf);
                }
            }
        }

        //

        if (this.simuDB.SimuConfig.ClusteringAndDataTransmisionAlgorithm == SimuCfg.TransmitAlgorithms.Maleki)
            PostCycle_Maleki();
    }

    void PostCycle_Maleki()
    {
        return;
        if (CurrentSimulationTime < 21) return;
        if (CurrentSimulationTime % 10 != 0) return;
        //0. perform prediction by using python
        CoUtils cu = new CoUtils();
        cu.RunBatchFile(@"C:\Velociraptor\Python\", "r.bat");
        //1. read all predicted values from db
        DataTable dt = new DataTable();
        SqlConnection conn = DAL.getConnectionObject();
        if (conn.State != ConnectionState.Open) conn.Open();
        using (SqlCommand cmd = new SqlCommand("SP_MalekiPrediction_ReadAllPredictedValues", conn))
        {
            cmd.CommandType = CommandType.StoredProcedure;
            SqlDataReader sdr = DAL.ExecuteQuery(cmd);// cmd.ExecuteReader();
            Boolean b = sdr.HasRows;
            dt.Load(sdr);
            dt.TableName = "t";
            sdr.Close();
        }
        //2. set NODE.ClusterInfo_Wifi.MyInfoToShareWithOhers.DoAcceptBeingClusterHead according to predicted value
        foreach (ComputerNode node in this.simuDB.IoTNodes)
        {
            if (node.ClusterInfo_Wifi.MyInfoToShareWithOhers.DoAcceptBeingClusterHead == false) continue;

            if ((float)(node.HardwareProfile.PowerSupplyProfile.EnergyCurrent / node.HardwareProfile.PowerSupplyProfile.EnergyStart) < 0.3)
                node.ClusterInfo_Wifi.MyInfoToShareWithOhers.DoAcceptBeingClusterHead = false;
            else
            {
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    if (dt.Rows[i]["NodeID"].ToString() == node.NodeID)
                    {
                        decimal PredictedValue = Convert.ToDecimal(dt.Rows[i]["PredictedValue"].ToString());
                        if (PredictedValue <= 0.6m)
                        {
                            node.ClusterInfo_Wifi.MyInfoToShareWithOhers.DoAcceptBeingClusterHead = false;
                            foreach (string membernodeID in node.ClusterInfo_Wifi.MyInfoToShareWithOhers.ListOfMemberNodes)
                            {
                                ComputerNode membernode = SimuData.GetNodeByID(membernodeID, this.simuDB.Nodes);
                                membernode.ClusterInfo_Wifi.MyInfoToShareWithOhers.ListofMyClusterHeads.Clear();
                                membernode.ClusterInfo_Wifi.MyInfoToShareWithOhers.IHaveClusterHead = false;
                            }
                            node.ClusterInfo_Wifi.MyInfoToShareWithOhers.ListOfMemberNodes.Clear();
                            node.ClusterInfo_Wifi.MyInfoToShareWithOhers.CountOfCurrentMembersAsCH = 0;
                        }

                    }
                }
            }

        }
        //3. move data to archive table
        if ((conn == null)) return;
        if (conn.State != ConnectionState.Open) conn.Open();
        using (SqlCommand cmd = new SqlCommand("SP_MalekiPrediction_MoveAllPredictedValuesToArchive", conn))
        {
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.Add("@SimTime", SqlDbType.Int).Value = this.CurrentSimulationTime;
            DAL.ExecuteNonQuery(cmd);
            //cmd.ExecuteNonQuery();
        }



    }
    public void InitTextboxes(TextBox _LogAcc, TextBox _LogSingle)
    {
        LogAcc = _LogAcc;
        LogSingle = _LogSingle;
    }
    void delWriteLog(bool isDetailForSingleAct, string msg)
    {

        try
        {



            try
            {
                if (isDetailForSingleAct)
                {
                    LogSingle.Invoke(new WriteOnLogDelegate(WriteOnLog), true, msg);

                }
                else
                {
                    LogAcc.Invoke(new WriteOnLogDelegate(WriteOnLog), false, msg);

                }
            }
            catch (Exception)
            {


            }
        }
        catch (Exception)
        {

        }

    }

    private delegate void WriteOnLogDelegate(bool isDetailForSingleAct, string msg);
    void WriteOnLog(bool isDetailForSingleAct, string msg)
    {
        try
        {


            if (isDetailForSingleAct)
            {
                LogSingle.Text = msg;
            }
            else
            {
                LogAcc.Text += Environment.NewLine + msg;
            }
        }
        catch (Exception)
        {

            throw;
        }
    }

    public void SerializeNow(List<Job> Jobs, string FilePath)
    {
        XmlSerializer x = new XmlSerializer(typeof(List<Job>));
        TextWriter writer = new StreamWriter(FilePath);
        x.Serialize(writer, Jobs);
        writer.Close();
        writer.Dispose();
    }
    public List<Job> DeSerializeNow(string FilePath)
    {
        var mySerializer = new XmlSerializer(typeof(List<Job>));
        var myFileStream = new FileStream(FilePath, FileMode.Open);
        List<Job> obj = (List<Job>)mySerializer.Deserialize(myFileStream);
        myFileStream.Close();
        myFileStream.Dispose();
        return obj;
    }


    int FinalizeSimulation()
    {
        try

        {
            this.isSimulationRunning = false;
            int SimID = -1;
            if (doLogOnDatabase)
            {

                SqlConnection conn = DAL.getConnectionObject();
                if (conn.State != ConnectionState.Open) conn.Open();
                using (SqlCommand cmd = new SqlCommand("SP_Finalize", conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.Add("@Date", SqlDbType.NVarChar).Value = cu.getCurrentPersianDateFull();
                    cmd.Parameters.Add("@Time", SqlDbType.NVarChar).Value = cu.getCurrentTime_24Format_WithSeconds();

                    var SimulationID = cmd.Parameters.Add("@ReturnVal", SqlDbType.Int);
                    SimulationID.Direction = ParameterDirection.ReturnValue;
                    DAL.ExecuteNonQuery(cmd);
                    //cmd.ExecuteNonQuery();

                    SimID = Convert.ToInt32(SimulationID.Value);
                }
                string m = "";
                if (CurrentSimulationTime == simulationConfig.simulationMaxStep)
                {
                    m = "Simulation finished successfully";
                }
                else
                {
                    m = "Simulation stopped by the user.";

                }
                delWriteLog(false, m + Environment.NewLine + "Simulation ID in database is " + SimID.ToString());
            }
            else
            {
                delWriteLog(false, "Simulation finished");

            }
            return SimID;
        }
        catch (Exception e)
        {
            //    MessageBox.Show("Error ocurred in finalizing simulation" + Environment.NewLine + Environment.NewLine + e.ToString());
            threadMainForSimulation.Abort();
            return -1;
        }
    }
    public void SimulationPause()
    {
        try
        {
            this.resetEvent.Reset();
            // threadMainForSimulation.Abort();
            //delWriteLog(true, "");
            delWriteLog(false, "simulation paused by the user.");
        }
        catch (Exception)
        {
        }
    }
    public void SimulationContinue()
    {
        try
        {
            this.resetEvent.Set();

            delWriteLog(false, "simulation resumed by the user.");
        }
        catch (Exception)
        {
        }
    }
    public void GeneratingJobsStop()
    {
        try
        {
            threadJobCreation.Abort();
            delWriteLog(true, "");
            delWriteLog(false, "Job Generation stopped by the user.");
        }
        catch (Exception)
        {
        }
    }

    public void JobsSaveToFile(string filename)
    {
        if (this.simuDB.JobsAll != null)
        {
            SerializeNow(this.simuDB.JobsAll, filename);
            //    MessageBox.Show("All jobs were saved to the file.");
        }
        else
        {
            MessageBox.Show("No job is generated yet.");
        }
    }

    public void JobsLoadFromFile(string filename)
    {
        try
        {
            List<Job> ss = DeSerializeNow(filename);
            this.simuDB.JobsAll = ss;
            MessageBox.Show("Jobs loaded from file");


        }
        catch (FileNotFoundException ee)
        {
            MessageBox.Show("File not found.");
        }
        catch (Exception eee)
        {
            MessageBox.Show("Error occured:" + Environment.NewLine + eee.ToString());

        }
    }



    private void GenerateRandomTerrainAndNodes(TextBox reportBox, bool dologOnTextboxes, SimuCfg simulationConfig)
    {
        try
        {
            simuDB.Nodes = null;
            string msg;
            msg = string.Format(Environment.NewLine + "Initializing simulation engine" + Environment.NewLine);
            delWriteLog(false, msg);

            simuDB = SimuData.GenerateNodesRandomely(reportBox, this.DAL, simulationConfig);
            delWriteLog(true, "Nodes are generated.");

            delWriteLog(false, "------ Nodes Configuration -----");
            msg = string.Format("IoT nodes: {0}" + "", simuDB.IoTNodes.Count);
            delWriteLog(false, msg);
            delWriteLog(false, string.Format("Cloud providers: {0}" + "", simuDB.CloudProviders.Count));
            delWriteLog(false, string.Format("Datacenters: {0}" + "", simuDB.DataCenters.Count));
            delWriteLog(false, string.Format("Clusters: {0}" + "", simuDB.Clusters.Count));
            int c = 0;
            foreach (var cl in simuDB.Clusters) c = c + cl.MemberNodes.Count;
            delWriteLog(false, string.Format("Cloud hosts(total) : {0}" + "", c.ToString()));

            delWriteLog(false, string.Format("Fog providers: {0}" + "", simuDB.FogProviders.Count));
            delWriteLog(false, string.Format("Fog points: {0}" + "", simuDB.FogPoints.Count));
            foreach (var cl in simuDB.FogPoints) c = c + cl.MemberNodes.Count;

            delWriteLog(false, string.Format("Fog hosts(total) : {0}" + "", c.ToString()));


            simuDB.Nodes = simuDB.Nodes.Concat(simuDB.IoTNodes).ToList();
            delWriteLog(false, string.Format("Fog/Cloud hosts: {0}" + "", simuDB.Nodes.Count));
            delWriteLog(false, "----------------------------------");
            isTerrainInited = true;
            delWriteLog(true, "Writting grid cells to database...");
            simuDB.terrain.TerrianGrid.SaveGridOverLayToDatabase(DAL.getConnectionObject());
            delWriteLog(true, "Writting grid are written to database.");


        }

        catch (Exception e)
        {
            MessageBox.Show("Error occured" + Environment.NewLine + e.ToString());
            isTerrainInited = false;
        }

    }


    private void JobGeneratorWorker()
    {
        try
        {
            CoUtils cu = new CoUtils();
            List<Job> Jobs = new List<Job>();
            string msg = string.Format("creating job dags" + Environment.NewLine);
            delWriteLog(false, msg);
            while (Jobs.Count < simulationConfig.jobGenerationProfile.CountOfDags)
            {
                msg = String.Format("Creating job dag " + Jobs.Count.ToString() + " of " + simulationConfig.jobGenerationProfile.CountOfDags.ToString() + Environment.NewLine + "with {0} to {1} nodes...", simulationConfig.jobGenerationProfile.CountOfTasksInDagMin, simulationConfig.jobGenerationProfile.CountOfTasksInDagMax);
                delWriteLog(true, msg);

                Job job = Job.GenerateRandomDAG(Jobs.Count, simuDB);
                if (job != null)
                {
                    Jobs.Add(job);
                    //msg = string.Format("Job Id:{0} with {1} nodes and {2} edges has been created", job.JobID, job.Tasks.Count, job.Edges.Count);
                    // delWriteLog(false, msg);
                }
            }
            delWriteLog(true, "");
            msg = string.Format("Total {0} job(s) has been created.", Jobs.Count);
            delWriteLog(false, msg);
            this.simuDB.JobsAll = Jobs;
            //JobsSaveToFile("Dags__" + cu.getCurrentPersianDateFull().Replace('/', '-') + "__" + cu.getCurrentTime_24Format_WithSeconds().Replace(':', '-') + ".xml");
            isJobsGenerated = true;
        }
        catch (Exception ee)
        {
            MessageBox.Show("Error occured" + Environment.NewLine + ee.ToString());
            isTerrainInited = false;
        }
    }

    /*
    private void JobGeneratorWorker_Conventional()
    {

        try
        {

            Job.RequirementProfileForTasks trp = new Job.RequirementProfileForTasks();
            trp.RequirementProfileForTasks_Init(simulationConfig.jobGenerationProfile.TasksCPUNeedMin, simulationConfig.jobGenerationProfile.TasksCPUNeedMax, simulationConfig.jobGenerationProfile.TasksMemNeedMin, simulationConfig.jobGenerationProfile.TasksMemNeedMax, simulationConfig.jobGenerationProfile.TasksStorageNeedMin, simulationConfig.jobGenerationProfile.TasksStorageNeedMax, simulationConfig.jobGenerationProfile.NeededResourceTypes, simulationConfig.jobGenerationProfile.MaxCountOfResourcesEachTaskMayNeed, simulationConfig.jobGenerationProfile.Deadline_PercentageOfTaskSize_Min, simulationConfig.jobGenerationProfile.Deadline_PercentageOfTaskSize_Max);
            Job.RequirementProfileForEdges erp = new Job.RequirementProfileForEdges();
            erp.RequirementProfileForEdges_Init(simulationConfig.jobGenerationProfile.MaxConnectivity, simulationConfig.jobGenerationProfile.EdgeWeightMin, simulationConfig.jobGenerationProfile.EdgeWeightMax);
            List<Job> Jobs = new List<Job>();
            int JobID = 0;
            string msg = string.Format("creating job dags" + Environment.NewLine);
            delWriteLog(false, msg);
            for (int i = 0; i < simulationConfig.jobGenerationProfile.CountOfDags; i++)
            {
                int CountOfTasksInDAG = Convert.ToInt32(cu.RandomNumber(simulationConfig.jobGenerationProfile.CountOfTasksInDagMin, simulationConfig.jobGenerationProfile.CountOfTasksInDagMax));
                string UserIDOwner = cu.RandomString(1, false) + cu.RandomNumber(3);
                ComputerNode NodeSubmittedFrom = simuDB.Nodes[cu.RandomNumber(0, simuDB.Nodes.Count - 1)];
                int timeSubmission = 0; timeSubmission++;
                msg = String.Format("Creating job dag " + i.ToString() + " of " + simulationConfig.jobGenerationProfile.CountOfDags.ToString() + Environment.NewLine + "with {0} nodes...", CountOfTasksInDAG);
                delWriteLog(true, msg);
                timeSubmission = cu.RandomNumber(0, Math.Max(50, simulationConfig.simulationMaxStep - 100));
                Job job = Job.GenerateRandomDAG(JobID, CountOfTasksInDAG, trp, erp, timeSubmission, UserIDOwner, NodeSubmittedFrom, cu.getCurrentPersianDateFull(), simuDB);
                job.CalculateDagSuppInfo(this.simuDB);
                if (job != null)
                {
                    Jobs.Add(job);
                    NodeSubmittedFrom.JobQueueAddnew(job, Job.JobAndTaskStatus.InitializedAndWaiting, NodeSubmittedFrom.QueueJob_GeneratedInThisNode, simuDB);
                    msg = string.Format("Job Id:{0} with {1} nodes and {2} edges has been created", job.JobID, job.Tasks.Count, job.Edges.Count);
                    delWriteLog(false, msg);
                }
                JobID++;
            }
            msg = "";
            delWriteLog(true, msg);
            msg = string.Format("Total {0} job(s) has been created.", Jobs.Count);
            delWriteLog(false, msg);
            this.simuDB.JobsAll = Jobs;
            //JobsSaveToFile("Dags__" + cu.getCurrentPersianDateFull().Replace('/', '-') + "__" + cu.getCurrentTime_24Format_WithSeconds().Replace(':', '-') + ".xml");

            isJobsGenerated = true;
        }
        catch (Exception ee)
        {
            MessageBox.Show("Error occured" + Environment.NewLine + ee.ToString());
            isTerrainInited = false;
        }


    }

    */







}

