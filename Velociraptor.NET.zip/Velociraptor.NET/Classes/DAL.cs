﻿ 
// Data Access Layer Core Class (Base Class)
//  October 2009 

using System;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;
using System.Web;
 
using System.Collections;


/// <summary>
/// Summary description for DBClassDALcore
/// </summary>
public class DAL
{

    protected SqlConnection Connection;

    public DAL()
    {
        Connection = new SqlConnection(getAppConnStr());
        Connection.Open();
    }

    public string getAppConnStr()
    {
        string cnString = @"";//Server=127.0.0.1;Database=Velociraptor;User ID=VeloUser;Password=motogodsinemo10249972$jpark;Connection Timeout=300;MultipleActiveResultSets=true";
        /*
         * <add name="RaponConnection" connectionString="Server=localhost\SSiMac;Database=SimuPro;User ID=SimuProIIS;Password=motogodsinemo10249972$jpark" providerName="System.Data.SqlClient"/>
         */
        return cnString;

    }


    public String getField(DataTable dt,int RowIndex,string FieldName)
    {
        try
        {

            if (dt.Rows[RowIndex][FieldName] == null) return "";
        return (dt.Rows[RowIndex][FieldName].ToString());

        }
        catch (Exception e)
        {
            throw e;
        }
    }

    public string getCurrentConnStr()
    {
        return Connection.ConnectionString;
    }
    

    public SqlConnection getConnectionObject()
    {
        return Connection;
    }
    public DataSet GetDataSet(string Query)
    {
        if (Query.IndexOf("delete", StringComparison.CurrentCultureIgnoreCase) >= 0) return null;
        if (Query.IndexOf("drop", StringComparison.CurrentCultureIgnoreCase) >= 0) return null;
        if (Query.IndexOf("insert", StringComparison.CurrentCultureIgnoreCase) >= 0) return null;
        if (Query.IndexOf("update", StringComparison.CurrentCultureIgnoreCase) >= 0) return null;
        Exception e = new Exception();
        // any exception will be writed to e object
        SqlDataAdapter Adapter = new SqlDataAdapter(Query, Connection);
        DataSet ItemDataSet = new DataSet();
        try
        {
            if (Connection.State != ConnectionState.Open) Connection.Open();
            Adapter.Fill(ItemDataSet, "Table0");
            Connection.Close();
            e = null;
        }
        catch (SqlException e1)
        { // write Error To log DB ERROR!
            e = e1;
            ItemDataSet = null;
        }
        catch (Exception e2)
        {
            ItemDataSet = null;
        }
        return ItemDataSet;
    }

    public DataSet getTable(string _table, string _colname, string _criteria)
    {
        if (_criteria == "") { _criteria = " 1=1"; }
        string qry = "select " + _colname + " from " + _table + " where " + _criteria;
        DataSet tmpDs = GetDataSet(qry);
        return tmpDs;
    }

    public bool IsUniqueValue(int value, string tableName, string fieldName)
    {
        string qry = "select " + fieldName + " from " + tableName + " where " + fieldName + "=" + value.ToString() + "";
        DataSet tmpDataSet = GetDataSet(qry);

        if ((tmpDataSet.Tables[0].Rows.Count == 0)) { tmpDataSet = null; return true; } else { tmpDataSet = null; return false; }
    }

    public bool IsUniqueValue(string value, string tableName, string fieldName)
    {
        
        if (value.IndexOf("delete", StringComparison.CurrentCultureIgnoreCase) >= 0) return false;
        if (value.IndexOf("drop", StringComparison.CurrentCultureIgnoreCase) >= 0) return false;
        if (value.IndexOf("insert", StringComparison.CurrentCultureIgnoreCase) >= 0) return false;
        if (value.IndexOf("update", StringComparison.CurrentCultureIgnoreCase) >= 0) return false; ;

        value = (new CoUtils()).MakeInjectionSafeString(value);

        string qry = "select " + fieldName + " from " + tableName + " where " + fieldName + "='" + value + "'";
        DataSet tmpDataSet = GetDataSet(qry);

        if ((tmpDataSet.Tables[0].Rows.Count == 0)) { tmpDataSet = null; return true; } else { tmpDataSet = null; return false; }
    }
    public static SqlDataReader ExecuteQuery(SqlCommand cmd)
    {

        SqlDataReader r = null;
        int countOfRetry = 30;
        bool done = false;
        while (!done)
        {
            try
            {
                cmd.Connection.Close();
                cmd.Connection.Open();
                r =cmd.ExecuteReader();
                done = true;
            }
            catch (Exception ee)
            {
                countOfRetry--;
                if (countOfRetry == 0) break;
            }

        }
        return r;
    }

    public static bool ExecuteNonQuery(SqlCommand cmd)
    {
        int countOfRetry = 30;
        bool done = false;
        while (!done)
        {
            try
            {
                cmd.ExecuteNonQuery();
                done = true;
            }
            catch (Exception ee)
            {
                countOfRetry--;
                if (countOfRetry == 0) break;
            }

        }
        return done;
    }
    public bool ExecuteQuery(string DBquery)
    {
        if (DBquery.IndexOf("drop", StringComparison.CurrentCultureIgnoreCase) >= 0) return false;

        try
        {
            SqlCommand Command = new SqlCommand(DBquery, Connection);
            if (Connection.State != ConnectionState.Open) Connection.Open();
            Command.ExecuteNonQuery();
            Connection.Close();
            return (true);
        }
        catch (SqlException Sqlexc)
        {
            // write Error to Log
            return (false);
        }


    }
}






