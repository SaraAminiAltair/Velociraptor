﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


public class NodeInfoForClustering : ICloneable
{
    public static int NodeTypes_IoT = 1, NodeTypes_Fog = 2, NodeTypes_Cloud = 3;
    public int NodeType;
    public bool isNodeAlive;
    public string NodeID;
    public bool IHaveClusterHead = false;
    public decimal Score;
    public float Speed;
    public float DirectionAngle;
    public int CountOfCurrentMembersAsCH = 0, CurrrentDurationOfBeingCH = 0, TotalDurationOfBeingCH = 0;
    public int CountOfNeighbors;
    public decimal EnergyRemaining, EnergyMax;
    public decimal Availability = 1;
    public decimal ReputationEsfandiari = 2;
    public decimal NeighborsStabilityFactorBy_TimeBeingNearFormula;
    public decimal CountOfNeighborsNormalized;
    public int DataTransfered_inKB = 0;
    public int CountOfReceivedRequests = 0;
    public int CountOfSuccessfullyTransferedRequests = 0;
    public int MaximumMembersThreshold_Partovi = 0;
    public List<string> ListofMyClusterHeads = new List<string>();
    public decimal Esf_Reputation;
    public decimal Throghtput;
    public List<string> ListOfMemberNodes = new List<string>();
    public bool DoAcceptBeingClusterHead;// in some algorithms a node may refuse to act as a cluster head (e.g. due to lack of enough energy)
    public object Clone()
    {
        return this.MemberwiseClone();
    }

    public NodeInfoForClustering GetCopy()
    {
        CoUtils cu = new CoUtils();

        NodeInfoForClustering c = (NodeInfoForClustering)this.Clone();
        List<string> members = cu.ListCopy(this.ListOfMemberNodes);
        List<string> chs = cu.ListCopy(this.ListofMyClusterHeads);
        c.ListOfMemberNodes = members;
        c.ListofMyClusterHeads = chs;
        return c;
    }

}
public class NeighborInfo
{
    public NodeInfoForClustering NodeInfo;
    public int DistanceToNeighbor;
    public int NeighborBeingNearMeTime = 0;
    public NeighborInfo GetCopy()
    {
        NeighborInfo nifo = new NeighborInfo();
        nifo.DistanceToNeighbor = this.DistanceToNeighbor;
        nifo.NeighborBeingNearMeTime = this.NeighborBeingNearMeTime;
        nifo.NodeInfo = this.NodeInfo.GetCopy();
        return nifo;
    }
}

public class NeighborsTable
{
    public string NodeID;
    public List<NeighborInfo> Neighbors = new List<NeighborInfo>();


    public bool isNeighbor(string nodeID)
    {
        foreach (NeighborInfo nei in this.Neighbors)
        {
            if (nei.NodeInfo.NodeID == nodeID) return true;
        }
        return false;
    }
    public NeighborsTable GetCopy()
    {
        NeighborsTable nt = new NeighborsTable();
        nt.NodeID = this.NodeID;
        List<NeighborInfo> neighbors = new List<NeighborInfo>();
        foreach (NeighborInfo nifo in this.Neighbors)
        {
            neighbors.Add(nifo.GetCopy());
        }

        nt.Neighbors = neighbors;
        return nt;
    }

    public string GetListOfNeighborsNodeID()
    {
        string s = "[";
        foreach (NeighborInfo nifo in this.Neighbors)
        {
            if (s != "[") s += ",";
            s += nifo.NodeInfo.NodeID;
        }
        s += "]";
        return s;
    }
    public NeighborInfo FindNeighborWithMaximumScore(ComputerNode Me)
    {
        decimal maxScore = -100;
        NeighborInfo nodeWithHighestScore = null; ;
        foreach (NeighborInfo nei in this.Neighbors)
        {
            if (!nei.NodeInfo.isNodeAlive) continue;
            if (!nei.NodeInfo.DoAcceptBeingClusterHead) continue;
            if (nei.NodeInfo.ListofMyClusterHeads.IndexOf(Me.NodeID) >= 0)
            {
                continue; //pass this neighbor because I am a clusterheadf of this node
            }
            if (nei.NodeInfo.Score > maxScore) { nodeWithHighestScore = nei; maxScore = nei.NodeInfo.Score; }
        }
        return nodeWithHighestScore;
    }
    public List<NeighborInfo> GetListOfNeighborsWhichAreClusterHead() //returns a list string of all neighbor nodes which are cluster head for some nodes
    {
        List<NeighborInfo> l = new List<NeighborInfo>();
        foreach (NeighborInfo nifo in this.Neighbors)
        {
            if ((nifo.NodeInfo.CountOfCurrentMembersAsCH > 0) && (nifo.NodeInfo.ListofMyClusterHeads.IndexOf(this.NodeID) < 0))
            {
                l.Add(nifo);
            }
        }
        return l;
    }

    public List<NeighborInfo> GetListOfNeighborsWithSpecificType(SimuData nodeStructure, int NodeType, bool OnlySelectHeads)
    {
        // NodeType will come from:  NodeInfoForClustering.NodeTypes_Fog ,  NodeInfoForClustering.NodeTypes_Cloud ,  NodeInfoForClustering.NodeTypes_IoT
        List<NeighborInfo> l = new List<NeighborInfo>();
        foreach (NeighborInfo nifo in this.Neighbors)
        {
            if (nifo.NodeInfo.NodeType == NodeType)
            {
                ComputerNode theNeighbor = SimuData.GetNodeByID(nifo.NodeInfo.NodeID, nodeStructure.Nodes);
                //SimuData.FogPoint fp = theNeighbor.InFog_Fixed_OwnerFogPoint;
                //ComputerNode fp_ch = fp.CurrentClusterHead;
                //if (fp_ch.NodeID == theNeighbor.NodeID)//this is the fogpoint clusterhead.
                if (OnlySelectHeads)
                {
                    if (NodeInfoForClustering.NodeTypes_Fog == NodeType)
                    {
                        SimuData.FogPoint fp = theNeighbor.InFog_Fixed_OwnerFogPoint;
                        ComputerNode fp_ch = fp.CurrentClusterHead;
                        if (fp_ch.NodeID == theNeighbor.NodeID)
                        { l.Add(nifo); }
                    }
                    else if (NodeInfoForClustering.NodeTypes_Cloud == NodeType)
                    {
                        SimuData.Cluster cl = theNeighbor.InCloud_Fixed_OwnerCluster;
                        ComputerNode cl_ch = cl.CurrentClusterHead;
                        if (cl_ch.NodeID == theNeighbor.NodeID)
                        { l.Add(nifo); }
                    }
                }
                else
                {
                    l.Add(nifo);
                }
            }
        }
        return l;
    }


    public Dictionary<string, int> GetDistanceWithAllNeighbors()
    {
        Dictionary<string, int> l = new Dictionary<string, int>();
        foreach (NeighborInfo nifo in this.Neighbors) l.Add(nifo.NodeInfo.NodeID, nifo.DistanceToNeighbor);

        return l;
    }


    public Dictionary<string, decimal> GetNeighborsScores()
    {
        Dictionary<string, decimal> l = new Dictionary<string, decimal>();
        foreach (NeighborInfo nifo in this.Neighbors) l.Add(nifo.NodeInfo.NodeID, nifo.NodeInfo.Score);
        return l;
    }

    public string GetNeighborsTableAsString()
    {
        CoUtils cu = new CoUtils();
        string s = "[";
        foreach (NeighborInfo nifo in this.Neighbors)
        {
            if (s != "[") s += ",";
            s += "(NodeID:" + nifo.NodeInfo.NodeID
                + ",DistanceToNeighbor:" + nifo.DistanceToNeighbor.ToString()
                + ",Score:" + nifo.NodeInfo.Score.ToString()
                + ",Speed:" + nifo.NodeInfo.Speed.ToString()
                + ",DirectionAngle:" + nifo.NodeInfo.DirectionAngle.ToString()
                + ",EnergyRemaining:" + nifo.NodeInfo.EnergyRemaining.ToString()
                + ",EnergyMax:" + nifo.NodeInfo.EnergyMax.ToString()
                + ",Availability:" + nifo.NodeInfo.Availability.ToString()
                + ",CurrentMembers:" + cu.ListToString(nifo.NodeInfo.ListOfMemberNodes)
                + ",CountOfNeighbors:" + nifo.NodeInfo.CountOfNeighbors.ToString()
                + ",CurrrentDurationOfBeingCH:" + nifo.NodeInfo.CurrrentDurationOfBeingCH.ToString()
                + ",TotalDurationOfBeingCH:" + nifo.NodeInfo.TotalDurationOfBeingCH.ToString()
                  + ",TotalDurationOfBeingCH:" + nifo.NodeInfo.TotalDurationOfBeingCH.ToString()
                + ")";
        }
        s += "]";
        return s;
    }


}


public class ClusteringRelatedInfo  //holds information about clustering algorithms
{
    public List<string> MyAvailableClusterHeadNodeIDs = new List<string>();
    public NodeInfoForClustering MyInfoToShareWithOhers = new NodeInfoForClustering();
    public NeighborsTable NeighborsTable = new NeighborsTable();

    public void AddNodeToListOfThisNodeClusterMembers(string nodeid) //this function should be call by any node who wishes to choose This node as its CH
    {
        this.MyInfoToShareWithOhers.ListOfMemberNodes.Remove(nodeid);
        this.MyInfoToShareWithOhers.ListOfMemberNodes.Add(nodeid);
        this.MyInfoToShareWithOhers.CountOfCurrentMembersAsCH = this.MyInfoToShareWithOhers.ListOfMemberNodes.Count;

    }
    public List<string> GetCopy(List<string> list)
    {
        List<string> l = new List<string>();
        for (int i = 0; i < list.Count; i++)
        {
            l.Add(list[i]);
        }
        return l;
    }


    public ClusteringRelatedInfo GetCopy()
    {
        ClusteringRelatedInfo c = new ClusteringRelatedInfo();

        c.MyAvailableClusterHeadNodeIDs = GetCopy(this.MyAvailableClusterHeadNodeIDs);
        c.NeighborsTable = this.NeighborsTable.GetCopy();
        c.MyInfoToShareWithOhers = this.MyInfoToShareWithOhers.GetCopy();
        return c;
    }
}