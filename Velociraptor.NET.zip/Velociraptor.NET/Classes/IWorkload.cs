﻿using System.Collections.Generic;

namespace Velociraptor.Classes
{
    interface IWorkload
    {
        Dictionary<int, WorkloadData> WorkloadInfo { get; }
    }
}