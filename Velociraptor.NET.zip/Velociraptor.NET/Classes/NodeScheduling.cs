﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

public partial class ComputerNode
{
    public List<Job.DagInnerNode> NodeScheduleAdvancedReservationPlan = new List<Job.DagInnerNode>();

    public void NodeScheduling_DropTaskFromAdvancedReservationPlan(Job.DagInnerNode task)
    {
        int i = NodeScheduleAdvancedReservationPlan.Count - 1;
        while ((i>=0)&&(NodeScheduleAdvancedReservationPlan.Count>0))
        {
            var t = NodeScheduleAdvancedReservationPlan[i];
            if ((t.TaskID==task.TaskID)&&(t.OwnerJobID==task.OwnerJobID))
            {
                NodeScheduleAdvancedReservationPlan.RemoveAt(i);
            }
            i = i - 1;
        }
    }
    public void NodeMainSchedulingStructure(SimuData simuDB, Job job, List<Job> theQueueCurrentlyTheJobIs, bool isQueuForSelfGeneratedTasks)
    {

        if (this.NodeTypeAsString == "cloud")
        {
            if (simuDB.SimuConfig.schedulingProfile.AlgInCloudCluster == SimuCfg.SchedulingProfile.SchedulingAlgorithms.DavamiInDCCluster)
                NodeSchedulingAlgorithm_DavamiInDCCluster(simuDB, job, isQueuForSelfGeneratedTasks);
            if (simuDB.SimuConfig.schedulingProfile.AlgInCloudCluster == SimuCfg.SchedulingProfile.SchedulingAlgorithms.HajvaliInDCCluster)
                NodeSchedulingAlgorithm_HajvaliInDCCluster(simuDB, job, isQueuForSelfGeneratedTasks);
            if (simuDB.SimuConfig.schedulingProfile.AlgInCloudCluster == SimuCfg.SchedulingProfile.SchedulingAlgorithms.GHeft_Cloud)
                NodeSchedulingAlgorithm_GHEFT_InDCCluster(simuDB, job, isQueuForSelfGeneratedTasks);
        }
        else if (this.NodeTypeAsString == "fog")
        {
            if (simuDB.SimuConfig.schedulingProfile.AlgInFogPoint == SimuCfg.SchedulingProfile.SchedulingAlgorithms.DavamiInFog)
                NodeSchedulingAlgorithm_DavamiInFog(simuDB, job, isQueuForSelfGeneratedTasks);
            if (simuDB.SimuConfig.schedulingProfile.AlgInFogPoint == SimuCfg.SchedulingProfile.SchedulingAlgorithms.HajvaliInFog)
                NodeSchedulingAlgorithm_HajvaliInFog(simuDB, job, isQueuForSelfGeneratedTasks);
            if (simuDB.SimuConfig.schedulingProfile.AlgInFogPoint == SimuCfg.SchedulingProfile.SchedulingAlgorithms.GHeft_Fog)
                NodeSchedulingAlgorithm_GHEFTInFog(simuDB, job, isQueuForSelfGeneratedTasks);
        }
        else if (this.NodeTypeAsString == "iot")
        {
            if (simuDB.SimuConfig.schedulingProfile.AlgInIoT == SimuCfg.SchedulingProfile.SchedulingAlgorithms.GeneralForIoTNodes)
                NodeSchedulingAlgorithm_GeneralForIoTNodes(simuDB, job, isQueuForSelfGeneratedTasks);
        }
        else
        {
            MessageBox.Show("error");

        }

    }
    public ComputerNode GetNearestFogorDC(SimuData simuDB)
    {
        //zz currently random
        int max = simuDB.Clusters.Count;
        int r = (new CoUtils()).RandomNumber(0, max);
        if (r == max) r--;
        ComputerNode cn = simuDB.Clusters[r].CurrentClusterHead;
        return cn;
    }
    public void NodeSchedulingAlgorithm_GeneralForIoTNodes(SimuData simuDB, Job job, bool isQueuForSelfGeneratedTasks)
    {
        ComputerNode tnode = new ComputerNode();
        if (isQueuForSelfGeneratedTasks)
        {
            switch (this.NodeSchedulingClass)
            {
                case NodeSchedulingClassTypes.NodeScheClass_IoT_isCH:
                    //send to fog or cloud
                    //find a fog or dc (nearest is better) and send the job to its CH
                    tnode = GetNearestFogorDC(simuDB);
                    tnode.QueueJob_TobeScheduledByThisNode.Add(job);
                    break;
                case NodeSchedulingClassTypes.NodeScheClass_IoT_NotCH_hasCH:
                    //send to clusterhead
                    string targetNode = this.ClusterInfo_Wifi.MyInfoToShareWithOhers.ListofMyClusterHeads[0];
                    tnode = SimuData.GetNodeByID(targetNode, simuDB.Nodes);
                    tnode.QueueJob_TobeScheduledByThisNode.Add(job);
                    break;
                case NodeSchedulingClassTypes.NodeScheClass_IoT_NotCH_NoCH:
                    //schedule on itself
                    this.QueueJob_TobeScheduledByThisNode.Add(job);

                    break;
            }
        }
        else
        {
            switch (this.NodeSchedulingClass)
            {
                case NodeSchedulingClassTypes.NodeScheClass_IoT_isCH:
                    //send to fog or cloud
                    //find a fog or dc (nearest is better) and send the job to its CH
                    tnode = GetNearestFogorDC(simuDB);
                    tnode.QueueJob_TobeScheduledByThisNode.Add(job);
                    break;
                case NodeSchedulingClassTypes.NodeScheClass_IoT_NotCH_hasCH:
                    //send to clusterhead
                    string targetNode = this.ClusterInfo_Wifi.MyInfoToShareWithOhers.ListofMyClusterHeads[0];
                    tnode = SimuData.GetNodeByID(targetNode, simuDB.Nodes);
                    tnode.QueueJob_TobeScheduledByThisNode.Add(job);
                    break;
                case NodeSchedulingClassTypes.NodeScheClass_IoT_NotCH_NoCH:
                    //schedule on itself
                    if (job.NodeSubmitted == this.NodeID)
                    {
                        tnode = GetNearestFogorDC(simuDB);
                        tnode.QueueJob_TobeScheduledByThisNode.Add(job);
                    }
                    else
                    {
                        tnode = GetNearestFogorDC(simuDB);
                        tnode.QueueJob_TobeScheduledByThisNode.Add(job);
                    }
                    break;
            }






        }
    }
    public static class NodeSchedulingClassTypes
    {

        public const int
              // this node is member of a Fog point of Cloud Cluster So it is a member of a fixed Cluster. according to the scheduling algorithm, we may send the job to that node
              NodeScheClass_InFog_isCH = 1 //this node is the cluster head 
            , NodeScheClass_InFog_NotCH = 2//this node is not the clusterhead
            , NodeScheClass_InCloud_isCH = 3 //this node is the cluster head 
            , NodeScheClass_InCloud_NotCH = 4//this node is not the clusterhead
                                             // this node is an IoT node and it is not a member of a fixed cluster formation
            , NodeScheClass_IoT_isCH = 5//this node is  a CH
            , NodeScheClass_IoT_NotCH_hasCH = 6//this node is not a CH and it has one or more cluster head(s)
            , NodeScheClass_IoT_NotCH_NoCH = 7; //this node is not a CH and it has no cluster head
    }
    public int NodeSchedulingSetNodeClassForScheduling()
    {
        int nodeClass = -1;
        if (this.InCloud_Fixed_OwnerCluster != null)
        {
            if (this.InCloud_Fixed_OwnerCluster.CurrentClusterHead.NodeID == this.NodeID)
                nodeClass = NodeSchedulingClassTypes.NodeScheClass_InCloud_isCH;
            else
                nodeClass = NodeSchedulingClassTypes.NodeScheClass_InCloud_NotCH;
        }
        else if (this.InFog_Fixed_OwnerFogPoint != null)
        {
            if (this.InFog_Fixed_OwnerFogPoint.CurrentClusterHead.NodeID == this.NodeID)
                nodeClass = NodeSchedulingClassTypes.NodeScheClass_InFog_isCH;
            else
                nodeClass = NodeSchedulingClassTypes.NodeScheClass_InFog_NotCH;
        }
        else if ((this.InFog_Fixed_OwnerFogPoint==null) &&(InCloud_Fixed_OwnerCluster==null))
        {
            if (this.ClusterInfo_Wifi.MyInfoToShareWithOhers.CountOfCurrentMembersAsCH > 0)
                nodeClass = NodeSchedulingClassTypes.NodeScheClass_IoT_isCH;
            else
            {
                if (this.ClusterInfo_Wifi.MyInfoToShareWithOhers.ListofMyClusterHeads.Count == 0)
                    nodeClass = NodeSchedulingClassTypes.NodeScheClass_IoT_NotCH_NoCH;
                else
                    nodeClass = NodeSchedulingClassTypes.NodeScheClass_IoT_NotCH_hasCH;
            }
        }
        return nodeClass;
    }
    private void NodeSchedulingPreiodicalRoutineTobeCalledEachStep(SimuData simuDB)
    {
        if (simuDB.SimuConfig.schedulingProfile.AlgInCloudCluster == SimuCfg.SchedulingProfile.SchedulingAlgorithms.DavamiInDCCluster)
            CheckTriggersForSendingOrSchedulingPackOfWorkflows(simuDB);
    }
    public class SchedulingResult
    {
        public int ScheduleResultCode;
        public static int failed_TaskDeadlineIsPassed = -1


            , failed_NoSlotForTask = -2
            , successfull = 1;
    }
 



public SchedulingResult NodeSchedule_PerformScheduling_a_Task_On_ThisNode(Job.DagInnerNode task)
{
    //this method is called by the cluster head for each task of a job on each node of a cluster until a successfull result for a task received
    //this method should be called for each task of a job
    //note that upon successfull scheduling, two fields: OnMachine_StartTime, OnMachine_FinishTime of the task should be set
    SchedulingResult sr = new SchedulingResult();

    if (task.TimeDeadlineFinal <= CurrentSimulationTime) // tasks deadline already passed
    {
        sr.ScheduleResultCode = SchedulingResult.failed_TaskDeadlineIsPassed;
        return sr;
    }
    int thisCPUMIPS = this.HardwareProfile.ComputerHardwareProfile.CPUProfile.CPUCurrentMIPS_hardware;
    float TaskLengthOnThisNode_Seconds = Math.Max(1, task.CpuNeed_Claimed / (float)thisCPUMIPS);
    float ActualEarliestStartTime = Math.Max(CurrentSimulationTime, task.EST); //for now
    float ActualEarliestFinishTime = ActualEarliestStartTime + TaskLengthOnThisNode_Seconds;
    float ActualLatestFinishTime = task.TimeDeadlineFinal;
    float ActualLatestStartTime = ActualLatestFinishTime - TaskLengthOnThisNode_Seconds; //for now



    if (task.TimeDeadlineFinal < ActualEarliestFinishTime)//on this machine, task can not be finished before its deadline. May be there are other machines that care capable of handling it.
    {
        sr.ScheduleResultCode = SchedulingResult.failed_NoSlotForTask;
        return sr;
    }
    else if (NodeScheduleAdvancedReservationPlan.Count == 0)// node reservation list is empty and according to task.TimeDeadlineFinal > ActualEarliestFinishTime we can say that node can handle the task
    {
        sr.ScheduleResultCode = SchedulingResult.successfull;
        int OnMachine_StartTime = Math.Max(CurrentSimulationTime, task.EST)
        , OnMachine_FinishTime = Convert.ToInt32(OnMachine_StartTime + TaskLengthOnThisNode_Seconds);
        ScheduleTaskOnNode(task, OnMachine_StartTime, OnMachine_FinishTime);
        return sr;

    }
    if (NodeScheduleAdvancedReservationPlan.Count == 1)
    { //there is one task.(it may be before, after or concurrent to this task
        Job.DagInnerNode ta = NodeScheduleAdvancedReservationPlan[0];
        if (ta.OnMachine_FinishTime < ActualLatestStartTime)
        {
            ActualEarliestStartTime = Math.Max(ta.OnMachine_FinishTime, ActualEarliestStartTime);
            sr.ScheduleResultCode = SchedulingResult.successfull;
            int OnMachine_StartTime = Convert.ToInt32(ActualEarliestStartTime)
            , OnMachine_FinishTime = Convert.ToInt32(OnMachine_StartTime + TaskLengthOnThisNode_Seconds);
            ScheduleTaskOnNode(task, OnMachine_StartTime, OnMachine_FinishTime);
            return sr;
        }
        if (ta.OnMachine_StartTime > ActualEarliestFinishTime)
        {
            ActualLatestFinishTime = Math.Min(ActualLatestFinishTime, ta.OnMachine_StartTime);
            ActualLatestStartTime = ActualLatestFinishTime - TaskLengthOnThisNode_Seconds;
            sr.ScheduleResultCode = SchedulingResult.successfull;
            int OnMachine_StartTime = Convert.ToInt32(ActualEarliestStartTime)
            , OnMachine_FinishTime = Convert.ToInt32(OnMachine_StartTime + TaskLengthOnThisNode_Seconds);
            ScheduleTaskOnNode(task, OnMachine_StartTime, OnMachine_FinishTime);
            return sr;

        }
        sr.ScheduleResultCode = SchedulingResult.failed_NoSlotForTask;
        return sr;
    }
    if (NodeScheduleAdvancedReservationPlan.Count > 1)
    {

        // TaskLengthOnThisNode_Seconds ActualEarliestStartTime ActualEarliestFinishTime ActualLatestFinishTime ActualLatestStartTime


        List<Gap> FreeGaps = new List<Gap>();
        for (int i = 0; i < NodeScheduleAdvancedReservationPlan.Count; i++)
        {
            if (NodeScheduleAdvancedReservationPlan[i].OnMachine_FinishTime < CurrentSimulationTime) continue; //this task is irrelevant
            if (NodeScheduleAdvancedReservationPlan[i].OnMachine_StartTime > CurrentSimulationTime)
            {
                int gapStartTime = CurrentSimulationTime;
                if (i > 0) gapStartTime = NodeScheduleAdvancedReservationPlan[i - 1].OnMachine_FinishTime;
                int gapFinishTime = NodeScheduleAdvancedReservationPlan[i].OnMachine_StartTime;
                if (gapStartTime == gapFinishTime) continue;
                Gap gap = new Gap(gapStartTime, gapFinishTime);
                FreeGaps.Add(gap);
            }
            else
            {
                /*
                if (tmp[i].OnMachine_FinishTime == tmp[i + 1].OnMachine_StartTime) continue;
                Gap gap = new Gap(tmp[i].OnMachine_FinishTime, tmp[i + 1].OnMachine_StartTime);
                FreeGaps.Add(gap);
                */
            }

        }
        //last job
        Gap g = new Gap(NodeScheduleAdvancedReservationPlan[NodeScheduleAdvancedReservationPlan.Count - 1].OnMachine_FinishTime);

        FreeGaps.Add(g);
        int xxaq = 12;
        //now search in gaps for approriate fit for the task
        for (int i = 0; i < FreeGaps.Count; i++)
        {
            if (FreeGaps[i].DoesItFit(ActualEarliestStartTime, task.TimeDeadlineFinal, TaskLengthOnThisNode_Seconds))
            {

                sr.ScheduleResultCode = SchedulingResult.successfull;
                int OnMachine_StartTime = Convert.ToInt32(Math.Max(ActualEarliestStartTime, FreeGaps[i].GapStartTime))
                , OnMachine_FinishTime = Convert.ToInt32(OnMachine_StartTime + TaskLengthOnThisNode_Seconds);
                ScheduleTaskOnNode(task, OnMachine_StartTime, OnMachine_FinishTime);
                return sr;
            }
        }

        sr.ScheduleResultCode = SchedulingResult.failed_TaskDeadlineIsPassed;
        return sr;

    }
    else
    {
        //This code-block never be reached. Added it just for propoer compilation
        sr.ScheduleResultCode = SchedulingResult.failed_TaskDeadlineIsPassed;
        return sr;
    }

}
private class Gap
{
    public Gap(int startTime = 0, int finishTime = 1000000)
    {
        this.GapStartTime = startTime;// 0 for unlimitted
        this.GapFinishTime = finishTime;//1000000 for unlimited
    }
    public bool DoesItFit(float EarliestStartTime, int Deadline, float LengthOnThisMachine)
    {
        if ((Deadline < this.GapStartTime) || (EarliestStartTime > this.GapFinishTime)) return false; //irrelevant gap
        if (LengthOnThisMachine > GapFinishTime - GapStartTime) return false; // gap is too small
        int Actual_EarliestStartTime = Math.Max(Convert.ToInt32(EarliestStartTime), this.GapStartTime);
        int LatestPossibleFinishTime = Math.Min(Deadline, this.GapFinishTime);
        if (LatestPossibleFinishTime - Actual_EarliestStartTime >= LengthOnThisMachine) return true; else return false;
    }
    public int GapStartTime, GapFinishTime;

}

private void ScheduleTaskOnNode(Job.DagInnerNode task, int startOnMachine, int finishOnMachine)
{
    task.NodeID_ScheduledOn = this.NodeID;
    task.NodeID_CurrentlyOn = this.NodeID;

        task.TimeScheduled = CurrentSimulationTime;
    task.OnMachine_StartTime = startOnMachine;
    task.OnMachine_FinishTime = finishOnMachine;
    NodeScheduleAdvancedReservationPlan.Add(task);
    //sort it
    List<Job.DagInnerNode> list_temp = new List<Job.DagInnerNode>();
    foreach (var t in NodeScheduleAdvancedReservationPlan)
    {
        list_temp.Add(t);
    }

    List<Job.DagInnerNode> sortedList = new List<Job.DagInnerNode>();
    while (list_temp.Count > 0)
    {
        int index = 0;
        Job.DagInnerNode taskWithLowestStartTime = list_temp[0];
        for (int i = 0; i < list_temp.Count; i++)
        {
            if (taskWithLowestStartTime.OnMachine_StartTime > list_temp[i].OnMachine_StartTime)
            {
                taskWithLowestStartTime = list_temp[i];
                index = i;
            }

        }
        sortedList.Add(taskWithLowestStartTime);
        list_temp.RemoveAt(index);
    }

    NodeScheduleAdvancedReservationPlan = sortedList;

    //task record change on db is performed in scheduling method
}

}
