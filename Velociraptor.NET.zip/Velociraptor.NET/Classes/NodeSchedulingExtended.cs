﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

public partial class ComputerNode
{
    // Important note: in Davami Algorithm without any account for the priority of the workflows, ALL workflows that are in IN-Queues of a Cloud data center cluster head, will be scheduled in each step.
    //workflow and job are the exact same words for an application workflow dag

    List<Job> TemporaryScheduling_JobsWaitingList = new List<Job>();
    const int DavamiScheduling_JobsWaitingList_maxLength = 2; //start prioritizing the JobWitingList after receiving 5 workflows 
    const int DavamiScheduling_JobsWaitingList_maxTimeFromFirstAddedJob = 10; //start prioritizing the JobWitingList after 10 time units has passed from the receiving of the first workflow
    int TemporarySchedulingBuffer_FirstAddedJobTime = 0;

    public void NodeSchedulingAlgorithm_HajvaliInFog(SimuData simuDB, Job job, bool isQueuForSelfGeneratedTasks)
    {/*
     IF this node is CLUSTER HEAD:
        put the job on JobsWaitingList.
        Upon fulfilment of any of two following conditions->
             condition 1: after receiving DavamiScheduling_JobsWaitingList_maxLength workflows 
             condition 2: after DavamiScheduling_JobsWaitingList_maxTimeFromFirstAddedJob time units has passed from the receiving of the first workflow
        Then
          1- call NodeSchedulingDavamiAssignPriorityToWorkflows() function  to tag the priority number to all in-queue workdflow and sort the DavamiScheduling_JobsWaitingList according to priority number
          2- sort the nearby data centers according to their workload (ascedning, the best datacenter will be on top of the list)
          3- eliminate the Q4 and Q3 data centers from the list
          4- send half of the uppermost part of the prioritized workflows to the Q1 data centers (by using round robbin)
          5- send the remainder workflows to Q2 data centers (by using round robbin)
     ELSE (this is a non-cluster head fog node)
            send the workflow to this node's cluster head
     */
        if (this.NodeSchedulingClass == NodeSchedulingClassTypes.NodeScheClass_InFog_isCH)
        { //this node is a cluster head
            if (TemporaryScheduling_JobsWaitingList.Count == 0) //this is the first job to be added to the list, so reset the FirstJobTimer
                TemporarySchedulingBuffer_FirstAddedJobTime = CurrentSimulationTime;
            TemporaryScheduling_JobsWaitingList.Add(job);
            //check for trigger conditions
            CheckTriggersForSendingOrSchedulingPackOfWorkflows(simuDB);
        }
        else if (this.NodeSchedulingClass == NodeSchedulingClassTypes.NodeScheClass_InFog_NotCH)
        {
            //this node is a not a cluster head, send the job th its cluster head
            ComputerNode ch = this.InFog_Fixed_OwnerFogPoint.CurrentClusterHead;
            ch.QueueJob_TobeScheduledByThisNode.Add(job);

        }
        else
        {
            throw new Exception("wrong call");
        }


    }

    public void NodeSchedulingAlgorithm_HajvaliInDCCluster(SimuData simuDB, Job job, bool isQueuForSelfGeneratedTasks)
    {
        /*
        IF this node is CLUSTER HEAD:      
           schedule the received workflow
        ELSE (this is a non-cluster head Cloud cluster node)
           send the workflow to this node's cluster head
        */

        if (this.NodeSchedulingClass == NodeSchedulingClassTypes.NodeScheClass_InCloud_isCH)
        {

            if (TemporaryScheduling_JobsWaitingList.Count == 0) //this is the first job to be added to the list, so reset the FirstJobTimer
                TemporarySchedulingBuffer_FirstAddedJobTime = CurrentSimulationTime;
            TemporaryScheduling_JobsWaitingList.Add(job);
            /*
             * select from the task of the job. 
             * try from the first node of the cluster and test whether that node can handle it (is it possible to schedule the task on that node?)
             * if the first node was not able to handle the task, test next node. Do this till a capable node is found. If no node is found, the job should be dropped so write record to db. 
             * after successfull scheduling of each task, go for the next task in the job dag. If all tasks are scheduled, write the record on db.
             */
            //MessageBox.Show("performing Dag scheduling on dag: " + job.JobID);

            CheckTriggersForSendingOrSchedulingPackOfWorkflows(simuDB);
        }
        else if (this.NodeSchedulingClass == NodeSchedulingClassTypes.NodeScheClass_InCloud_NotCH)
        {
            //this node is a not a cluster head, send the job th its cluster head
            ComputerNode ch = this.InCloud_Fixed_OwnerCluster.CurrentClusterHead;
            ch.QueueJob_TobeScheduledByThisNode.Add(job);
        }
        else
        {
            throw new Exception("wrong call");
        }

    }

    public void NodeSchedulingAlgorithm_DavamiInFog(SimuData simuDB, Job job, bool isQueuForSelfGeneratedTasks)
    {/*
     IF this node is CLUSTER HEAD:
        put the job on JobsWaitingList.
        Upon fulfilment of any of two following conditions->
             condition 1: after receiving DavamiScheduling_JobsWaitingList_maxLength workflows 
             condition 2: after DavamiScheduling_JobsWaitingList_maxTimeFromFirstAddedJob time units has passed from the receiving of the first workflow
        Then
          1- call NodeSchedulingDavamiAssignPriorityToWorkflows() function  to tag the priority number to all in-queue workdflow and sort the DavamiScheduling_JobsWaitingList according to priority number
          2- sort the nearby data centers according to their workload (ascedning, the best datacenter will be on top of the list)
          3- eliminate the Q4 and Q3 data centers from the list
          4- send half of the uppermost part of the prioritized workflows to the Q1 data centers (by using round robbin)
          5- send the remainder workflows to Q2 data centers (by using round robbin)
     ELSE (this is a non-cluster head fog node)
            send the workflow to this node's cluster head
     */
        if (this.NodeSchedulingClass == NodeSchedulingClassTypes.NodeScheClass_InFog_isCH)
        { //this node is a cluster head
            if (TemporaryScheduling_JobsWaitingList.Count == 0) //this is the first job to be added to the list, so reset the FirstJobTimer
                TemporarySchedulingBuffer_FirstAddedJobTime = CurrentSimulationTime;
            TemporaryScheduling_JobsWaitingList.Add(job);
            //check for trigger conditions
            CheckTriggersForSendingOrSchedulingPackOfWorkflows(simuDB);
        }
        else if (this.NodeSchedulingClass == NodeSchedulingClassTypes.NodeScheClass_InFog_NotCH)
        {
            //this node is a not a cluster head, send the job th its cluster head
            ComputerNode ch = this.InFog_Fixed_OwnerFogPoint.CurrentClusterHead;
            ch.QueueJob_TobeScheduledByThisNode.Add(job);

        }
        else
        {
            throw new Exception("wrong call");
        }


    }


    public void NodeSchedulingAlgorithm_GHEFTInFog(SimuData simuDB, Job job, bool isQueuForSelfGeneratedTasks)
    {/*
     IF this node is CLUSTER HEAD:
        put the job on JobsWaitingList.
        Upon fulfilment of any of two following conditions->
             condition 1: after receiving DavamiScheduling_JobsWaitingList_maxLength workflows 
             condition 2: after DavamiScheduling_JobsWaitingList_maxTimeFromFirstAddedJob time units has passed from the receiving of the first workflow
        Then
          1- call NodeSchedulingDavamiAssignPriorityToWorkflows() function  to tag the priority number to all in-queue workdflow and sort the DavamiScheduling_JobsWaitingList according to priority number
          2- sort the nearby data centers according to their workload (ascedning, the best datacenter will be on top of the list)
          3- eliminate the Q4 and Q3 data centers from the list
          4- send half of the uppermost part of the prioritized workflows to the Q1 data centers (by using round robbin)
          5- send the remainder workflows to Q2 data centers (by using round robbin)
     ELSE (this is a non-cluster head fog node)
            send the workflow to this node's cluster head
     */
        if (this.NodeSchedulingClass == NodeSchedulingClassTypes.NodeScheClass_InFog_isCH)
        { //this node is a cluster head
            if (TemporaryScheduling_JobsWaitingList.Count == 0) //this is the first job to be added to the list, so reset the FirstJobTimer
                TemporarySchedulingBuffer_FirstAddedJobTime = CurrentSimulationTime;
            TemporaryScheduling_JobsWaitingList.Add(job);
            //check for trigger conditions
            CheckTriggersForSendingOrSchedulingPackOfWorkflows(simuDB);
        }
        else if (this.NodeSchedulingClass == NodeSchedulingClassTypes.NodeScheClass_InFog_NotCH)
        {
            //this node is a not a cluster head, send the job th its cluster head
            ComputerNode ch = this.InFog_Fixed_OwnerFogPoint.CurrentClusterHead;
            ch.QueueJob_TobeScheduledByThisNode.Add(job);

        }
        else
        {
            throw new Exception("wrong call");
        }


    }


    private void CheckTriggersForSendingOrSchedulingPackOfWorkflows(SimuData simuDB)
    {
        if ((simuDB.SimuConfig.schedulingProfile.AlgInCloudCluster == SimuCfg.SchedulingProfile.SchedulingAlgorithms.DavamiInDCCluster)
            ||
            (simuDB.SimuConfig.schedulingProfile.AlgInFogPoint == SimuCfg.SchedulingProfile.SchedulingAlgorithms.DavamiInFog)
           )
        {
            CheckTriggersForSendingOrSchedulingPackOfWorkflows_Davami(simuDB);
        }

        if ((simuDB.SimuConfig.schedulingProfile.AlgInCloudCluster == SimuCfg.SchedulingProfile.SchedulingAlgorithms.HajvaliInDCCluster)
      ||
      (simuDB.SimuConfig.schedulingProfile.AlgInFogPoint == SimuCfg.SchedulingProfile.SchedulingAlgorithms.HajvaliInFog)
     )
        {
            CheckTriggersForSendingOrSchedulingPackOfWorkflows_Hajvali(simuDB);
        }

    }

    private void CheckTriggersForSendingOrSchedulingPackOfWorkflows_Hajvali(SimuData simuDB)
    {
        //NodeSchedulingAssignPriorityToWorkflows(); ??

        if ((this.NodeSchedulingClass == NodeSchedulingClassTypes.NodeScheClass_InFog_isCH) || (this.NodeSchedulingClass == NodeSchedulingClassTypes.NodeScheClass_InCloud_isCH))
        {

            foreach (var job in TemporaryScheduling_JobsWaitingList)
            {
                List<double> CandidateClustersScore = new List<double>();

                NodeScheduling_ScheduleJobOnCandidateClusters_Hajvali(simuDB, job);
                /*                
               ComputerNode nextCH = null;
                if (TargetClustersAndTheirWorkloads.Count > 1) { nextCH = TargetClustersAndTheirWorkloads[1].groupOfComputers.CurrentClusterHead; }
                List<ComputerNode> targetNodes;
                if (this.InFog_Fixed_OwnerFogPoint.MemberNodes.Count > 0) targetNodes = this.InFog_Fixed_OwnerFogPoint.MemberNodes;
                    else  targetNodes = this.InCloud_Fixed_OwnerCluster.MemberNodes;
                NodeScheduling_ScheduleJobOnClusterOrForwardToAnotherClusterHead(simuDB, job, targetNodes, nextCH);
                */
            }
            TemporaryScheduling_JobsWaitingList.Clear();

        }



    }

    private void CheckTriggersForSendingOrSchedulingPackOfWorkflows_Davami(SimuData simuDB)
    {

        if (
            (TemporaryScheduling_JobsWaitingList.Count == DavamiScheduling_JobsWaitingList_maxLength)
            ||
            ((TemporaryScheduling_JobsWaitingList.Count > 0) && (CurrentSimulationTime - TemporarySchedulingBuffer_FirstAddedJobTime >= DavamiScheduling_JobsWaitingList_maxTimeFromFirstAddedJob))
           )
        {
            NodeSchedulingDavamiAssignPriorityToWorkflows();

            if (this.NodeSchedulingClass == NodeSchedulingClassTypes.NodeScheClass_InFog_isCH)
            {
                NodeSchedulingDavamiAssignPriorityToWorkflows();
                int indexToTheStartOfQ2clustersInThe_TargetClustersList = 0;
                List<GrouppOfComputersWorkload> TargetClustersAndTheirWorkloads = NodeScheduling_GetSortedListOfCloudClusterHeads_BasedOnWorkloads(simuDB, out indexToTheStartOfQ2clustersInThe_TargetClustersList);
                //Schedule workflows
                foreach (var job in TemporaryScheduling_JobsWaitingList)
                {
                    ComputerNode nextCH = null;
                    if (TargetClustersAndTheirWorkloads.Count > 1) { nextCH = TargetClustersAndTheirWorkloads[1].groupOfComputers.CurrentClusterHead; }
                    NodeScheduling_ScheduleJobOnClusterOrForwardToAnotherClusterHead(simuDB, job, this.InFog_Fixed_OwnerFogPoint.MemberNodes, nextCH);
                }
                TemporaryScheduling_JobsWaitingList.Clear();

            }
            if (this.NodeSchedulingClass == NodeSchedulingClassTypes.NodeScheClass_InCloud_isCH)
            {
                NodeSchedulingDavamiAssignPriorityToWorkflows();
                int indexToTheStartOfQ2clustersInThe_TargetClustersList = 0;
                List<GrouppOfComputersWorkload> TargetClustersAndTheirWorkloads = NodeScheduling_GetSortedListOfCloudClusterHeads_BasedOnWorkloads(simuDB, out indexToTheStartOfQ2clustersInThe_TargetClustersList);
                //Schedule workflows
                foreach (var job in TemporaryScheduling_JobsWaitingList)
                {
                    ComputerNode nextCH = null;
                    if (TargetClustersAndTheirWorkloads.Count > 1) { nextCH = TargetClustersAndTheirWorkloads[1].groupOfComputers.CurrentClusterHead; }
                    NodeScheduling_ScheduleJobOnClusterOrForwardToAnotherClusterHead(simuDB, job, this.InCloud_Fixed_OwnerCluster.MemberNodes, nextCH);
                }
                TemporaryScheduling_JobsWaitingList.Clear();
            }

        }
    }

    private void NodeSchedulingDavamiAssignPriorityToWorkflows()
    {
        //this method processes the DavamiScheduling_JobsWaitingList. It assigns a priority number to each job and sort the DavamiScheduling_JobsWaitingList according to this priority number.
        //to calculate priority number it runs the NN to get some parameters, then it runs the FIS to assign the priority to the job (workflow)
        //zz NN and FIS are currently stub
        List<Job> list_temp = new List<Job>();


        foreach (Job job in TemporaryScheduling_JobsWaitingList)
        {
            //zz after neural network change the following line
            job.EFT_PredictedByNeuralNetwork = job.EFT_DAG;
            job.MaxParallelExecutableTasks_PredictedByNeuralNetwork = job.MaxParallelExecutableTasks;
            //----

            if (job.PriorityNo == -1) // if priority != -1 then it has been calculated so we do not calculate it again
            {
                //job.PriorityNo =  Convert.ToDecimal((new CoUtils()).RandomNumber(1, 100)); //FIS and NN goes here
                job.PriorityNo = NodeShceduling_DavamiPriorityByFIS(job, TemporaryScheduling_JobsWaitingList, 3);
                this.TimepointsLog_CountOfRunningComplexAlgorithm[CurrentSimulationTime]++;

            }
            list_temp.Add(job);
        }
        //sort jobs accoring to their priority

        List<Job> sortedList = new List<Job>();
        while (list_temp.Count > 0)
        {
            int index = 0;
            Job jobWithHighestPriority = list_temp[0];
            for (int i = 0; i < list_temp.Count; i++)
            {
                if (jobWithHighestPriority.PriorityNo < list_temp[i].PriorityNo)
                {
                    jobWithHighestPriority = list_temp[i];
                    index = i;
                }

            }
            sortedList.Add(jobWithHighestPriority);
            list_temp.RemoveAt(index);
        }


        TemporaryScheduling_JobsWaitingList = sortedList;

    }
    public class GrouppOfComputersWorkload
    {
        public SimuData.GroupsOfComputers groupOfComputers;
        public float Workload;
        public double ScoreForScheduling;
    }
    private List<GrouppOfComputersWorkload> NodeScheduling_GetSortedListOfCloudClusterHeads_BasedOnWorkloads(SimuData simuDB, out int indexNumberWhereQ2Starts)
    {

        // returns the  list of target cluster heads which is sorted ascendingly according to workloads of the clusters
        indexNumberWhereQ2Starts = 1;
        List<ComputerNode> list = new List<ComputerNode>();
        List<GrouppOfComputersWorkload> list_temp = new List<GrouppOfComputersWorkload>();

        for (int i = 0; i < simuDB.Clusters.Count; i++)
        {
            float workload = simuDB.Clusters[i].Workload.GetWorkload(CurrentSimulationTime);
            GrouppOfComputersWorkload gwl = new GrouppOfComputersWorkload();
            gwl.groupOfComputers = (SimuData.GroupsOfComputers)simuDB.Clusters[i];
            gwl.Workload = workload;
            list_temp.Add(gwl);
        }
        for (int i = 0; i < simuDB.FogPoints.Count; i++)
        {
            float workload = simuDB.FogPoints[i].Workload.GetWorkload(CurrentSimulationTime);
            GrouppOfComputersWorkload gwl = new GrouppOfComputersWorkload();
            gwl.groupOfComputers = (SimuData.GroupsOfComputers)simuDB.FogPoints[i];
            gwl.Workload = workload;
            list_temp.Add(gwl);
        }
        GrouppOfComputersWorkload t;

        List<GrouppOfComputersWorkload> sortedList = new List<GrouppOfComputersWorkload>();
        while (list_temp.Count > 0)
        {
            int index = 0;
            GrouppOfComputersWorkload lowestWorkloadCluster = list_temp[0];
            for (int i = 0; i < list_temp.Count; i++)
            {
                if (lowestWorkloadCluster.Workload > list_temp[i].Workload)
                {
                    lowestWorkloadCluster = list_temp[i];
                    index = i;
                }

            }
            sortedList.Add(lowestWorkloadCluster);
            list_temp.RemoveAt(index);
        }


        return sortedList;
    }

    private Double NodeScheduling_UtilityFunction_Hajvali(SimuData simuDB, Job job, SimuData.GroupsOfComputers TargetNodes)
    {
        decimal MIPS = 0;
        foreach (var Node in TargetNodes.MemberNodes) MIPS += Node.HardwareProfile.ComputerHardwareProfile.CPUProfile.CPUCurrentMIPS_hardware;
        decimal AvgMIPS_inThisCluster = MIPS / TargetNodes.MemberNodes.Count;

        decimal JobSizeSerial = job.JobSizeWithoutAccountForParallelism;
        decimal JobSizeWithMaxParallelelism = job.MinimumPassThrough_MI_withHighestParallelism;

        decimal AET_Serial_on_This_Cluster = JobSizeSerial / AvgMIPS_inThisCluster;
        decimal AET_Parallel_on_This_Cluster = JobSizeWithMaxParallelelism / AvgMIPS_inThisCluster;

        decimal AET_Serial_on_MostPowerfulCluster = job.MinTimeForExecuteDagSerialOnCloud;
        decimal AET_Parallel_on_MostPowerfulCluster = job.MinTimeForExecuteDagWithMaxParallelismOnCloud;


        decimal UtilityValue = AET_Serial_on_This_Cluster / AET_Serial_on_MostPowerfulCluster
                        + AET_Parallel_on_This_Cluster / AET_Parallel_on_MostPowerfulCluster;
        return (double)UtilityValue; //the lower the better
    }
    private List<GrouppOfComputersWorkload> NodeScheduling_GetSortedListOfFogAndCloudClusterHeads_BasedOnScoreForJob_Hajvali(SimuData simuDB, Job job)
    {
        // returns the  list of target cluster heads which is sorted ascendingly according to workloads of the clusters
        List<ComputerNode> list = new List<ComputerNode>();
        List<GrouppOfComputersWorkload> list_temp = new List<GrouppOfComputersWorkload>();


        for (int i = 0; i < simuDB.Clusters.Count; i++)
        {
            float workload = simuDB.Clusters[i].Workload.GetWorkload(CurrentSimulationTime);
            GrouppOfComputersWorkload gwl = new GrouppOfComputersWorkload();
            gwl.groupOfComputers = (SimuData.GroupsOfComputers)simuDB.Clusters[i];
            gwl.Workload = workload;
            gwl.ScoreForScheduling = NodeScheduling_UtilityFunction_Hajvali(simuDB, job, gwl.groupOfComputers);
            list_temp.Add(gwl);
        }
        for (int i = 0; i < simuDB.FogPoints.Count; i++)
        {
            float workload = simuDB.FogPoints[i].Workload.GetWorkload(CurrentSimulationTime);
            GrouppOfComputersWorkload gwl = new GrouppOfComputersWorkload();
            gwl.groupOfComputers = (SimuData.GroupsOfComputers)simuDB.FogPoints[i];
            gwl.Workload = workload;
            gwl.ScoreForScheduling = NodeScheduling_UtilityFunction_Hajvali(simuDB, job, gwl.groupOfComputers);

            list_temp.Add(gwl);
        }



        GrouppOfComputersWorkload t;

        List<GrouppOfComputersWorkload> sortedList = new List<GrouppOfComputersWorkload>();
        while (list_temp.Count > 0)
        {
            int index = 0;
            GrouppOfComputersWorkload lowestWorkloadCluster = list_temp[0];
            for (int i = 0; i < list_temp.Count; i++)
            {
                if (lowestWorkloadCluster.ScoreForScheduling > list_temp[i].ScoreForScheduling)
                {
                    lowestWorkloadCluster = list_temp[i];
                    index = i;
                }

            }
            sortedList.Add(lowestWorkloadCluster);
            list_temp.RemoveAt(index);
        }


        return sortedList;
    }


    public void NodeSchedulingAlgorithm_GHEFT_InDCCluster(SimuData simuDB, Job job, bool isQueuForSelfGeneratedTasks)
    {

        /*
        IF this node is CLUSTER HEAD:      
           schedule the received workflow
        ELSE (this is a non-cluster head Cloud cluster node)
           send the workflow to this node's cluster head
        */

        if (this.NodeSchedulingClass == NodeSchedulingClassTypes.NodeScheClass_InCloud_isCH)
        {

            if (TemporaryScheduling_JobsWaitingList.Count == 0) //this is the first job to be added to the list, so reset the FirstJobTimer
                TemporarySchedulingBuffer_FirstAddedJobTime = CurrentSimulationTime;
            TemporaryScheduling_JobsWaitingList.Add(job);
            /*
             * select from the task of the job. 
             * try from the first node of the cluster and test whether that node can handle it (is it possible to schedule the task on that node?)
             * if the first node was not able to handle the task, test next node. Do this till a capable node is found. If no node is found, the job should be dropped so write record to db. 
             * after successfull scheduling of each task, go for the next task in the job dag. If all tasks are scheduled, write the record on db.
             */
            //MessageBox.Show("performing Dag scheduling on dag: " + job.JobID);

            CheckTriggersForSendingOrSchedulingPackOfWorkflows(simuDB);
        }
        else if (this.NodeSchedulingClass == NodeSchedulingClassTypes.NodeScheClass_InCloud_NotCH)
        {
            //this node is a not a cluster head, send the job th its cluster head
            ComputerNode ch = this.InCloud_Fixed_OwnerCluster.CurrentClusterHead;
            ch.QueueJob_TobeScheduledByThisNode.Add(job);
        }
        else
        {
            throw new Exception("wrong call");
        }

    }


    public void NodeSchedulingAlgorithm_DavamiInDCCluster(SimuData simuDB, Job job, bool isQueuForSelfGeneratedTasks)
    {
        /*
        IF this node is CLUSTER HEAD:      
           schedule the received workflow
        ELSE (this is a non-cluster head Cloud cluster node)
           send the workflow to this node's cluster head
        */

        if (this.NodeSchedulingClass == NodeSchedulingClassTypes.NodeScheClass_InCloud_isCH)
        {

            if (TemporaryScheduling_JobsWaitingList.Count == 0) //this is the first job to be added to the list, so reset the FirstJobTimer
                TemporarySchedulingBuffer_FirstAddedJobTime = CurrentSimulationTime;
            TemporaryScheduling_JobsWaitingList.Add(job);
            /*
             * select from the task of the job. 
             * try from the first node of the cluster and test whether that node can handle it (is it possible to schedule the task on that node?)
             * if the first node was not able to handle the task, test next node. Do this till a capable node is found. If no node is found, the job should be dropped so write record to db. 
             * after successfull scheduling of each task, go for the next task in the job dag. If all tasks are scheduled, write the record on db.
             */
            //MessageBox.Show("performing Dag scheduling on dag: " + job.JobID);

            CheckTriggersForSendingOrSchedulingPackOfWorkflows(simuDB);
        }
        else if (this.NodeSchedulingClass == NodeSchedulingClassTypes.NodeScheClass_InCloud_NotCH)
        {
            //this node is a not a cluster head, send the job th its cluster head
            ComputerNode ch = this.InCloud_Fixed_OwnerCluster.CurrentClusterHead;
            ch.QueueJob_TobeScheduledByThisNode.Add(job);
        }
        else
        {
            throw new Exception("wrong call");
        }

    }

    void NodeScheduling_UpdateDatabaseOnJobScheduling(SimuData simuDB, Job job, bool isFullyScheduled)
    {
        if (!isFullyScheduled)
        {
            foreach (Job.DagInnerNode task in job.Tasks)
            {
                task.NodeID_ScheduledOn = "";
                task.OnMachine_StartTime = -1;
                task.OnMachine_FinishTime = -1;
                task.NodeID_ScheduledOn = "";
                task.NodeID_CurrentlyOn = job.NodeID_CurrentlyOn;
                task.SetTaskStatus(simuDB, task.TimeSubmission, Job.JobAndTaskStatus.SchedulingFailed);
                foreach (var node in simuDB.Nodes)
                {
                    node.NodeScheduling_DropTaskFromAdvancedReservationPlan(task);
                }
            }
            simuDB.SchedulingLog_Jobs_CountOfRejected++;
            simuDB.SchedulingLog_Tasks_CountOfRejected = simuDB.SchedulingLog_Tasks_CountOfRejected + job.Tasks.Count;
            job.SetJobStatus(simuDB, CurrentSimulationTime, Job.JobAndTaskStatus.SchedulingFailed);

        }
        else
        {
            job.TimeScheduled = CurrentSimulationTime;
            simuDB.SchedulingLog_Jobs_CountOfScheduled++;
            simuDB.SchedulingLog_Tasks_CountOfScheduled += job.Tasks.Count;
            if (this.InCloud_Fixed_OwnerCluster != null)
                this.InCloud_Fixed_OwnerCluster.Workload.RegisterNewScheduling(job, CurrentSimulationTime);
            else if (this.InFog_Fixed_OwnerFogPoint != null)
                this.InFog_Fixed_OwnerFogPoint.Workload.RegisterNewScheduling(job, CurrentSimulationTime);
            job.UpdateJobShcedulingInfo(simuDB, CurrentSimulationTime);
            foreach (Job.DagInnerNode task in job.Tasks)
                task.SetTaskStatus(simuDB, task.TimeSubmission, Job.JobAndTaskStatus.FullyScheduled);
        }

    }


    private void NodeScheduling_ScheduleJobOnCandidateClusters_Hajvali(SimuData simuDB, Job job)
    {
        if (job.HowManyTimesJobForwardedForScheduling == 0) //if this job is being processed for the first time
        {
            simuDB.SchedulingLog_Jobs_CountOfUndergoneSchedulingProcess++;
            simuDB.SchedulingLog_Tasks_CountOfUndergoneSchedulingProcess = simuDB.SchedulingLog_Tasks_CountOfUndergoneSchedulingProcess + job.Tasks.Count;
        }
        // generate all possible schedules AND calculate utility function value for each schedule AND sort the schedules
        List<GrouppOfComputersWorkload> CandidateClustersForJob = NodeScheduling_GetSortedListOfFogAndCloudClusterHeads_BasedOnScoreForJob_Hajvali(simuDB, job);
        // perform scheduling to BEST schedule (the schedule with highest score)
        bool isJobScheduled = false;
        for (int i = 0; i < CandidateClustersForJob.Count; i++)
        {
            GrouppOfComputersWorkload Target = CandidateClustersForJob[i];
            List<ComputerNode> TargetNodes = Target.groupOfComputers.MemberNodes;
            isJobScheduled = NodeScheduling_ScheduleJobOnCluster_RandomFirstFit(simuDB, job, TargetNodes);
            if (isJobScheduled) break;
        }

        if (!isJobScheduled)
        {
            job.HowManyTimesJobForwardedForScheduling++;
            NodeScheduling_UpdateDatabaseOnJobScheduling(simuDB, job, false);
        }
        else NodeScheduling_UpdateDatabaseOnJobScheduling(simuDB, job, true);

    }

    private void NodeScheduling_ScheduleJobOnClusterOrForwardToAnotherClusterHead(SimuData simuDB, Job job, List<ComputerNode> TargetNodes, ComputerNode NextClusterHead_ToForwardTheJob_IfSchedulingFailedInThisCluster)
    {
        if (job.HowManyTimesJobForwardedForScheduling == 0)
        {
            simuDB.SchedulingLog_Jobs_CountOfUndergoneSchedulingProcess++;
            simuDB.SchedulingLog_Tasks_CountOfUndergoneSchedulingProcess = simuDB.SchedulingLog_Tasks_CountOfUndergoneSchedulingProcess + job.Tasks.Count;
        }
        bool isJobScheduled;

        if ((simuDB.SimuConfig.schedulingProfile.AlgInCloudCluster == SimuCfg.SchedulingProfile.SchedulingAlgorithms.HajvaliInDCCluster) || (simuDB.SimuConfig.schedulingProfile.AlgInFogPoint == SimuCfg.SchedulingProfile.SchedulingAlgorithms.HajvaliInFog))
        {
            isJobScheduled = NodeScheduling_ScheduleJobOnCluster_RandomFirstFit(simuDB, job, TargetNodes);
        }
        else
        {
            isJobScheduled = NodeScheduling_ScheduleJobOnCluster_RandomFirstFit(simuDB, job, TargetNodes);
        }
        if (!isJobScheduled)
        {
            //scheduling was failed: 
            job.HowManyTimesJobForwardedForScheduling++;

            if ((NextClusterHead_ToForwardTheJob_IfSchedulingFailedInThisCluster == null) || (job.HowManyTimesJobForwardedForScheduling > job.MaxNumberForForwardingJobForScheduling))
            {
                NodeScheduling_UpdateDatabaseOnJobScheduling(simuDB, job, false);
            }
            else
            {
                NextClusterHead_ToForwardTheJob_IfSchedulingFailedInThisCluster.QueueJob_TobeScheduledByThisNode.Add(job);
            }
        }
        else
        {
            NodeScheduling_UpdateDatabaseOnJobScheduling(simuDB, job, true);
            //     MessageBox.Show("Job " + job.JobID + " is scheduled successfully");
        }
    }
    private bool NodeScheduling_ScheduleJobOnCluster_FirstFit(SimuData simuDB, Job job, List<ComputerNode> TargetNodes)
    {

        bool isAllTasksCheckedAndScheduled = false;
        for (int i = 0; i < job.Tasks.Count; i++)
        {
            this.TimepointsLog_CountOfSchedulingTasks[CurrentSimulationTime]++;

            Job.DagInnerNode task = job.Tasks[i];
            //MessageBox.Show("performing task scheduling on task " + task.TaskID + " of job " + task.OwnerJobID);

            bool isTaskSuccessfullyScheduled = false;
            foreach (ComputerNode node in TargetNodes)
            {
                if (node.NodeID == this.NodeID) continue; // no scheduling on the cluster head nodes (this node)
                ComputerNode.SchedulingResult sr = node.NodeSchedule_PerformScheduling_a_Task_On_ThisNode(task);
                if (sr.ScheduleResultCode == ComputerNode.SchedulingResult.successfull)
                {
                    isTaskSuccessfullyScheduled = true;

                    break;
                }

            }
            // here all nodes has been visited (and tested for scheduling of the task)
            if (isTaskSuccessfullyScheduled)
            {
                task.SetTaskStatus(simuDB, task.TimeSubmission, Job.JobAndTaskStatus.FullyScheduled);
                // MessageBox.Show("Task " + task.TaskID + " of job " + task.OwnerJobID + " is scheduled successfully");
            }
            else
            {
                //  MessageBox.Show("Task " + task.TaskID + " of job " + task.OwnerJobID + " is FAILED to be scheduled");
                task.SetTaskStatus(simuDB, task.TimeSubmission, Job.JobAndTaskStatus.SchedulingFailed);
                break;
            }

            if (i == job.Tasks.Count - 1) isAllTasksCheckedAndScheduled = true;  //this is the last task
        }


        return isAllTasksCheckedAndScheduled;

    }

    private bool NodeScheduling_ScheduleJobOnCluster_RandomFirstFit(SimuData simuDB, Job job, List<ComputerNode> TargetNodes)
    {

        bool isAllTasksCheckedAndScheduled = false;
        for (int i = 0; i < job.Tasks.Count; i++)
        {
            this.TimepointsLog_CountOfSchedulingTasks[CurrentSimulationTime]++;

            Job.DagInnerNode task = job.Tasks[i];
            //MessageBox.Show("performing task scheduling on task " + task.TaskID + " of job " + task.OwnerJobID);

            bool isTaskSuccessfullyScheduled = false;
            foreach (ComputerNode node in TargetNodes)
            {
                //  zz     if (node.NodeID == this.NodeID) continue; // no scheduling on the cluster head nodes (this node)
                ComputerNode.SchedulingResult sr = node.NodeSchedule_PerformScheduling_a_Task_On_ThisNode(task);
                if (sr.ScheduleResultCode == ComputerNode.SchedulingResult.successfull)
                {
                    isTaskSuccessfullyScheduled = true;
                    break;
                }

            }
            // here all nodes has been visited (and tested for scheduling of the task)
            if (isTaskSuccessfullyScheduled)
            {
                //
                //  MessageBox.Show("Task " + task.TaskID + " of job " + task.OwnerJobID + " is on node: "+task.NodeID_ScheduledOn+" S,F:"+task.OnMachine_StartTime+","+task.OnMachine_FinishTime);
            }
            else
            {
                //MessageBox.Show("Task " + task.TaskID + " of job " + task.OwnerJobID + " is FAILED to be scheduled");

                break;
            }

            if (i == job.Tasks.Count - 1) isAllTasksCheckedAndScheduled = true;  //this is the last task
        }


        return isAllTasksCheckedAndScheduled;

    }






    decimal NodeShceduling_DavamiPriorityByFIS(Job job, List<Job> CompetingJobs, int retryToUseMatlabEngine)
    {
        return (decimal)(new CoUtils()).RandomNumber(0, 1);



        float MaxEFT_InCompeteingTasks = 0
            , MaxjobSizeWithoutAccountForParallelsim_InCompeteingasks = 0
            , MaxParallel_InCompeteingasks = 0
            , CriticalPathSize_InCompetiongJobs = 0;
        foreach (Job compJob in CompetingJobs)
        {

            MaxEFT_InCompeteingTasks = Math.Max(MaxEFT_InCompeteingTasks, Math.Max(0, (compJob.EFT_PredictedByNeuralNetwork - CurrentSimulationTime)));
            MaxjobSizeWithoutAccountForParallelsim_InCompeteingasks = Math.Max(MaxjobSizeWithoutAccountForParallelsim_InCompeteingasks, compJob.JobSizeWithoutAccountForParallelism);
            MaxParallel_InCompeteingasks = Math.Max(MaxParallel_InCompeteingasks, compJob.MaxParallelExecutableTasks_PredictedByNeuralNetwork);
            CriticalPathSize_InCompetiongJobs = Math.Max(CriticalPathSize_InCompetiongJobs, compJob.GetCriticalPath().PathWeight);
        }

        float EFT_Normalized = Math.Max(0, (job.EFT_PredictedByNeuralNetwork - CurrentSimulationTime)) / MaxEFT_InCompeteingTasks
             , WorkflowSize_Normalized = job.JobSizeWithoutAccountForParallelism / MaxjobSizeWithoutAccountForParallelsim_InCompeteingasks
             , MaxParallel_Normalized = job.MaxParallelExecutableTasks_PredictedByNeuralNetwork / MaxParallel_InCompeteingasks
             , CriticalPath_Normalized = job.GetCriticalPath().PathWeight / CriticalPathSize_InCompetiongJobs;
        if (retryToUseMatlabEngine == 0)
        {
            //MessageBox.Show("Exception occured during calling matlab environment!"+Environment.NewLine);
            return 0.0m;
        }
        try
        {
            MLApp.MLApp matlab = getMatlabRuntime(5);
            if (matlab == null) return -1;
            matlab.Execute(@"cd C:\Velociraptor\Davami\Matlab");
            object result = null;

            matlab.Feval("FIS_Call", 1, out result
                            , (float)EFT_Normalized
                            , (float)WorkflowSize_Normalized
                            , (float)CriticalPath_Normalized
                            , (float)MaxParallel_Normalized
                            );

            object[] res = result as object[];
            double fis_result = (double)res[0];
            return (decimal)fis_result;
        }
        catch (Exception e)
        {
            retryToUseMatlabEngine--;
            System.Threading.Thread.Sleep(1500);
            return NodeShceduling_DavamiPriorityByFIS(job, CompetingJobs, retryToUseMatlabEngine);
        }
    }
}

