﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


public class DataPacketsQueues
{
    // public SingleDataPacketQueue QueueGeneratedPackets = new SingleDataPacketQueue();
    public SingleDataPacketQueue QueIn = new SingleDataPacketQueue();
    public SingleDataPacketQueue QueOut = new SingleDataPacketQueue();



    public class SingleDataPacketQueue
    {
        public List<DataPacket> Queue = new List<DataPacket>();
    }

    public bool AreAllQueuesEmpty()

    {
        if (QueIn.Queue.Count + QueOut.Queue.Count == 0) return true; else return false;
    }


}

