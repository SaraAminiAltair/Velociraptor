﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

public class SimuData
{

    public List<Job> JobsAll = null;
    public List<Job> JobsDropped = new List<Job>();
    public List<Job> JobsSuccessfullyFinished = new List<Job>();

    public SimuCfg.Terrain terrain;
    public List<ComputerNode> Nodes = new List<ComputerNode>();
    public List<ComputerNode> IoTNodes = new List<ComputerNode>();
    public List<FogProvider> FogProviders = new List<FogProvider>();
    public List<CloudProvider> CloudProviders = new List<CloudProvider>();
    public List<FogPoint> FogPoints = new List<FogPoint>();
    public List<DataCenter> DataCenters = new List<DataCenter>();
    public List<Cluster> Clusters = new List<Cluster>();
    public DataPacketsQueues.SingleDataPacketQueue DroppedPackets = new DataPacketsQueues.SingleDataPacketQueue();
    public DataPacketsQueues.SingleDataPacketQueue SuccessfullyTransferedPackets = new DataPacketsQueues.SingleDataPacketQueue();

    public DataPacketsQueues.SingleDataPacketQueue AllGeneratedPackets = new DataPacketsQueues.SingleDataPacketQueue();
    public List<ComputerNode> DeadNodes = new List<ComputerNode>();
    public DAL dal;
    private int BaseLineCpuCloudFogMIPS = -1, BaseLineCpuCloudMIPS = -1, BaseLineCpuFogMIPS = -1, BaseLineCpuIoTMIPS = -1;
    public SimuCfg SimuConfig;
    public ComputerNode Cellular3GInfrastructureAbstractNode = new ComputerNode();
    public int PacketIDLastGenerated = 0;

    public int[] SchedulingLog_Nodes_CountBusyExecutingTasks;
    public int[] SchedulingLog_Nodes_CountBusyPerformingScheduling;

    public int SchedulingLog_Jobs_CountOfSubmitted = 0
                , SchedulingLog_Jobs_CountOfUndergoneSchedulingProcess = 0
                , SchedulingLog_Jobs_CountOfScheduled = 0
                , SchedulingLog_Jobs_CountOfRejected = 0
                , SchedulingLog_Jobs_CountOfFinished = 0
                , SchedulingLog_Jobs_CountOfFailedDuringExecution_BecauseOfHostCrashed = 0
                , SchedulingLog_Jobs_CountOfFailedDuringExecution_DeadlinePassed = 0
                , SchedulingLog_Tasks_CountOfSubmitted = 0
                , SchedulingLog_Tasks_CountOfUndergoneSchedulingProcess = 0
                , SchedulingLog_Tasks_CountOfScheduled = 0
                , SchedulingLog_Tasks_CountOfRejected = 0
                , SchedulingLog_Tasks_CountOfFinished = 0
                , SchedulingLog_Tasks_CountOfFailedDuringExecution = 0
                , SchedulingLog_Tasks_CountOfFailedDuringExecution_BecauseOfHostCrashed = 0
                , SchedulingLog_Tasks_CountOfFailedDuringExecution_DeadlinePassed = 0;
    public static ComputerNode GetNodeByID(string NodeID, List<ComputerNode> ListOfNodes)
    {

        foreach (ComputerNode n in ListOfNodes) if (n.NodeID == NodeID) return n;
        return null;
    }

    public static ComputerNode FindNodeWithMaxComputationPower (List <ComputerNode> Nodes)
    {
        ComputerNode r = null;
        long MaxMips = 0;
        foreach(ComputerNode node in Nodes)
        {
            long m = node.HardwareProfile.ComputerHardwareProfile.CPUProfile.CPUCurrentMIPS_hardware;
            if (m> MaxMips)
            {
                MaxMips = m;
                r = node;
            }
        }
        return r;
    }
    public static ComputerNode FindNodeWithMaxRemainingEnergy(List<ComputerNode> Nodes)
    {
        ComputerNode r = null;
        decimal MaxRemainingEnergy = 0;
        foreach (ComputerNode node in Nodes)
        {
            decimal m = node.HardwareProfile.PowerSupplyProfile.EnergyCurrent;
            if (m > MaxRemainingEnergy)
            {
                MaxRemainingEnergy = m;
                r = node;
            }
        }
        return r;
    }

    public static Cluster FindBiggestCluster(List<SimuData.Cluster> Clusters)
    {
        Cluster BiggestCluster = null;
        int CountOfMembersOfBiggestCluster = 0;
        foreach (Cluster cl in Clusters)
        {
            int m = cl.MemberNodes.Count;
            if (m > CountOfMembersOfBiggestCluster)
            {
                CountOfMembersOfBiggestCluster = m;
                BiggestCluster = cl;
            }
        }
        return BiggestCluster;
    }



    public ComputerNode GetRandomNode(bool onlyFromIoTNodes, string NodeID_to_Except)
    {
        CoUtils cu = new CoUtils();
        bool found = false;
        List<ComputerNode> theNodeSet = Nodes; //all nodes
        if (onlyFromIoTNodes) theNodeSet = IoTNodes;

        while (!found)
        {
            int i = cu.RandomNumber(0, theNodeSet.Count - 1);
            if ((theNodeSet[i].NodeID != NodeID_to_Except) && (theNodeSet[i].isNodeAlive))
            {
                return theNodeSet[i];
            }
        }
        return null;
    }
    public CpuAndBandwidthBaseLines GetBaseLines()
    {
        int CpuBaseLineFogAndCloud = GetAverageCpuMipsInAllFogAndCloudNodes(false);
        int CpuBaseLineCloud = GetAverageCpuMipsInAllCloudNodes(false);
        int CpuBaseLineFog = GetAverageCpuMipsInAllFogPoints(false);
        int CpuBaseLineIoT = GetAverageCpuMipsInAllIoTNodes(false);
        int BaseLineBandwidthCloud, BaseLineBandwidthFogCloud, BaseLineBandwidthFog, BaseLineBandwidthIoT;
        BaseLineBandwidthCloud = BaseLineBandwidthFogCloud = BaseLineBandwidthFog = BaseLineBandwidthIoT = 2; //2 MB per Second
        CpuAndBandwidthBaseLines baselines = new CpuAndBandwidthBaseLines();
        baselines.MandatoryInit(CpuBaseLineFogAndCloud, CpuBaseLineCloud, CpuBaseLineFog, CpuBaseLineIoT, BaseLineBandwidthCloud, BaseLineBandwidthFogCloud, BaseLineBandwidthFog, BaseLineBandwidthIoT);

        return baselines;
    }
    public SimuData(DAL _dal)
    {
        this.dal = _dal;
    }


    void CreateCellularAbstractInfra( double ProbablityOfCellularInfrastructureLossPacket_InsideSystem)
    {
        NodeHardwareProfile hwp = new NodeHardwareProfile();
        int DeviceCode = NodeHardwareProfile.DeviceCodes.CellularBTS;
        hwp.MandatoryInit(DeviceCode, NodeHardwareProfile.HardwarePowerSupply.Typical(DeviceCode), NodeHardwareProfile.HardwareComputer.Typical(DeviceCode), NodeHardwareProfile.GetDeviceNameBaseOnDeviceCode(DeviceCode), ProbablityOfCellularInfrastructureLossPacket_InsideSystem);
        LocationProfile loc = new LocationProfile();

        LocationPoint newLoc = this.terrain.TerrianGrid.GetRandomLocationPointInGridForNode("bts");
        loc.MandatoryInit(0, false, 0, this.terrain, newLoc);
        NodeRolesProfile role = new NodeRolesProfile();
        NodeRolesProfile.NodeRoleRecord rolereco = new NodeRolesProfile.NodeRoleRecord();
        rolereco.MandatoryInit(0, NodeRolesProfile.NodeRoleCodes.RelayData);
        role.AddNewRole(rolereco);

        ComputerNode node = new ComputerNode();
        Cellular3GInfrastructureAbstractNode.ComputerNode_MandatoryInit(  "CellularInfrastructure", hwp, loc, role, this);
    }

    public class FogProvider
    {
        public string FogProviderID;
        public List<string> MemberFogPointIDs = new List<string>();
    }


    public class FogPoint : GroupsOfComputers
    {
        public FogPoint()
        { Workload = new WorkloadProfile((GroupsOfComputers)this); }
        public WorkloadProfile Workload;
        public FogProvider ownerFogProvider;
        public string FogPointID;
        public LocationPoint Location;
        public ComputerNode FogPointHead;
    }
    public class CloudProvider
    {
        public string CloudProviderID;

        public List<string> MemberDataCenterIDs = new List<string>();
    }



    public int GetAverageCpuMipsInAllFogAndCloudNodes(bool ForceRecalculate)
    {
        if (!((ForceRecalculate) || (BaseLineCpuCloudFogMIPS == -1))) return BaseLineCpuCloudFogMIPS;

        int s = 0;
        int c = 0;
        foreach (ComputerNode node in this.Nodes)
        {
            s = s + node.HardwareProfile.ComputerHardwareProfile.CPUProfile.CPUMaxMIPS;
            c++;
        }
        if ((s == 0) || (c == 0)) return 1;
        int avg = Convert.ToInt32(Math.Ceiling((double)s / c));
        BaseLineCpuCloudFogMIPS = avg;
        return BaseLineCpuCloudFogMIPS;
    }
    public int GetAverageCpuMipsInAllIoTNodes(bool ForceRecalculate)
    {
        if (!((ForceRecalculate) || (BaseLineCpuIoTMIPS == -1))) return BaseLineCpuIoTMIPS;

        int s = 0;
        int c = 0;
        foreach (ComputerNode node in this.IoTNodes)
        {
            s = s + node.HardwareProfile.ComputerHardwareProfile.CPUProfile.CPUMaxMIPS;
            c++;
        }
        if ((s == 0) || (c == 0)) return 1;
        this.BaseLineCpuIoTMIPS = Convert.ToInt32(Math.Ceiling((double)s / c));

        return BaseLineCpuIoTMIPS;
    }
    public int GetAverageCpuMipsInAllFogPoints(bool ForceRecalculate)
    {
        if (!((ForceRecalculate) || (BaseLineCpuFogMIPS == -1))) return BaseLineCpuFogMIPS;

        int s = 0;
        int c = 0;
        foreach (FogPoint fogpoint in FogPoints)
        {

            foreach (ComputerNode node in fogpoint.MemberNodes)
            {
                s = s + node.HardwareProfile.ComputerHardwareProfile.CPUProfile.CPUMaxMIPS;
                c++;
            }
        }

        if ((s == 0) || (c == 0)) return 1;
        this.BaseLineCpuFogMIPS = Convert.ToInt32(Math.Ceiling((double)s / c));
        return BaseLineCpuFogMIPS;
    }
    public int GetAverageCpuMipsInAllCloudNodes(bool ForceRecalculate)
    {
        if (!((ForceRecalculate) || (BaseLineCpuCloudMIPS == -1))) return BaseLineCpuCloudMIPS;

        int s = 0;
        int c = 0;
        foreach (Cluster cluster in Clusters)
        {
            foreach (ComputerNode node in cluster.MemberNodes)
            {

                s = s + node.HardwareProfile.ComputerHardwareProfile.CPUProfile.CPUMaxMIPS;
                c++;
            }
        }
        if ((s == 0) || (c == 0)) return 1;
        this.BaseLineCpuCloudMIPS = Convert.ToInt32(Math.Ceiling((double)s / c));

        return BaseLineCpuCloudMIPS;
    }
    public class DataCenter
    {
        public CloudProvider ownerCloudProvider;

        public string DataCenterID;
        public LocationPoint Location;

        public List<Cluster> MemberClusters = new List<Cluster>();
    }
    public class GroupsOfComputers
    {
        public List<ComputerNode> MemberNodes = new List<ComputerNode>();
        public ComputerNode CurrentClusterHead;
    }

    public class Cluster : GroupsOfComputers
    {
        public Cluster()
        { Workload = new WorkloadProfile((GroupsOfComputers)this); }
        public DataCenter ownerDataCenter;
        public WorkloadProfile Workload;
        public string ClusterID;

    }

    public class WorkloadProfile
    {
        private GroupsOfComputers thisCluster;


        public WorkloadProfile(GroupsOfComputers theCluster)
        {
            thisCluster = theCluster;
        }

        public void RegisterNewScheduling(Job job, int Time)
        {
            jobProfile jp = new jobProfile();
            jp.ArrivalTime = Time;
            jp.JobLenthInMips = job.JobSizeWithoutAccountForParallelism;
            jp.AverageInterTasksCommunication = (float)job.SumOfEdgeWeight / job.Edges.Count;
            jp.CountOfTasks = job.CountOfTasks;
            jp.CountOfEdges = job.CountOfEdges;
            ScheduledJobsProfile.Add(jp);
        }
        public Dictionary<int, float> WorkloadHistory = new Dictionary<int, float>();
        public float GetWorkload(int CurrentTime, int effectiveHistory = 300)
        {
            float wl = 0;

            //how many timepoints in history should be accounted in calculations

            int lowestArrivalTime = Math.Max(0, CurrentTime - effectiveHistory);
            float interarrivalTime = 0, avgLengthOfJobs = 0;
            List<int> arrivalTimes = new List<int>();
            foreach (var jp in this.ScheduledJobsProfile)
            {
                if (jp.ArrivalTime >= lowestArrivalTime)
                {
                    arrivalTimes.Add(jp.ArrivalTime);
                    avgLengthOfJobs += jp.JobLenthInMips;
                }
            }
            if (arrivalTimes.Count == 0)
            {
                //no jobs!
                WorkloadHistory[CurrentTime] = 0;
                return wl;
            }
            avgLengthOfJobs = avgLengthOfJobs / 1000000; //I to MI
            avgLengthOfJobs = avgLengthOfJobs / arrivalTimes.Count;
            arrivalTimes.Sort();

            for (int i = 0; i < arrivalTimes.Count; i++)
            {
                interarrivalTime += arrivalTimes[i];
            }
            interarrivalTime = interarrivalTime / arrivalTimes.Count;

            int countOfAliveMembers = 0;
            for (int i = 0; i < thisCluster.MemberNodes.Count; i++)
                if (thisCluster.MemberNodes[i].isNodeAlive == true) countOfAliveMembers++;
            if (countOfAliveMembers == 1) countOfAliveMembers++;
            wl = (interarrivalTime) * (avgLengthOfJobs) / (float)(countOfAliveMembers - 1);
            try { WorkloadHistory[CurrentTime] = wl; }
            catch (Exception e)
            {
                WorkloadHistory.Add(CurrentTime, wl);
            }


            return wl;


        }
        private List<jobProfile> ScheduledJobsProfile = new List<jobProfile>();




    }
    public class jobProfile
    {
        //concise info about scheduled jobs for workload calculation
        public int ArrivalTime;
        public long JobLenthInMips;
        public float AverageInterTasksCommunication;
        public int CountOfTasks;
        public int CountOfEdges;
    }



    private static string getARandomName(bool useNumberAtEnd)
    {
        CoUtils cu = new CoUtils();
        try
        {
            string[] n = { "TravoSystems", "Jackolicom", "Cyphocom", "Naxodoc", "Lomocom", "Yachta", "Jeronicomp", "Utalita", "Comtroniz", "Alabamacom", "Niniocom", "Clouderino", "zuffolonic" };
            string s = n[cu.RandomNumber(0, n.Length - 1)];
            if (useNumberAtEnd) s = s + cu.RandomNumber(2);
            return s;
        }
        catch (Exception)
        {
            return "Tatojan";
        }

    }

    public static SimuData GenerateNodesRandomely(TextBox reportbox, DAL _dal, SimuCfg simuConfig)
    {
        CoUtils cu = new CoUtils();
        SimuData simuDB = new SimuData(_dal);
        simuDB.terrain = new SimuCfg.Terrain(simuConfig.terrainSpec);
        simuDB.SimuConfig = simuConfig;

        simuDB.CreateCellularAbstractInfra(  simuDB.SimuConfig.networkProfile.networkFailureModel.ProbablityOfCellularInfrastructureLossPacket_InsideSystem);
        {//-------------------------------------------------------------------IoT Nodes---------------------------------------------------------------

            List<ComputerNode> res = new List<ComputerNode>();
            Dictionary<int, int> portion = new Dictionary<int, int>();
            double ratio = 1 / 10.0; // we have 10 different IoT node type, we assign 1/10  that is 0.1 ratio to each node type. 
            portion.Add(NodeHardwareProfile.DeviceCodes.iphoneX, Convert.ToInt32(simuConfig.ioTSpec.CountOfIoTNodes * ratio));
            portion.Add(NodeHardwareProfile.DeviceCodes.samsungS8, Convert.ToInt32(simuConfig.ioTSpec.CountOfIoTNodes * ratio));
            portion.Add(NodeHardwareProfile.DeviceCodes.RPi2OnBattery, Convert.ToInt32(simuConfig.ioTSpec.CountOfIoTNodes * ratio));
            portion.Add(NodeHardwareProfile.DeviceCodes.iPad4, Convert.ToInt32(simuConfig.ioTSpec.CountOfIoTNodes * ratio));

            portion.Add(NodeHardwareProfile.DeviceCodes.iPhone13, Convert.ToInt32(simuConfig.ioTSpec.CountOfIoTNodes * ratio));
            portion.Add(NodeHardwareProfile.DeviceCodes.LaptopAsusZenBook, Convert.ToInt32(simuConfig.ioTSpec.CountOfIoTNodes * ratio));
            portion.Add(NodeHardwareProfile.DeviceCodes.LaptopLenovo, Convert.ToInt32(simuConfig.ioTSpec.CountOfIoTNodes * ratio));
            portion.Add(NodeHardwareProfile.DeviceCodes.LaptopMacbookProM1, Convert.ToInt32(simuConfig.ioTSpec.CountOfIoTNodes * ratio));
            portion.Add(NodeHardwareProfile.DeviceCodes.WatchAppleSeries7, Convert.ToInt32(simuConfig.ioTSpec.CountOfIoTNodes * ratio));
            portion.Add(NodeHardwareProfile.DeviceCodes.WatchSamsungGalaxy4, Convert.ToInt32(simuConfig.ioTSpec.CountOfIoTNodes * ratio));


            int accel, speed, speedmax;
            LocationProfile loc;
            NodeRolesProfile role;
            NodeHardwareProfile hwp;
            int nodeDataGenerationStatus = 0;

            foreach (var item in portion)
            {
                int devCode = item.Key;
                int count = item.Value;
                for (int i = 0; i < count; i++)
                {


                    hwp = NodeHardwareProfile.TypicalGenerate(devCode, NodeHardwareProfile.NodeTypes.IoTNode, simuDB.SimuConfig.networkProfile);

                    accel = 0;
                    loc = new LocationProfile();
                    LocationPoint initLocation = simuDB.terrain.TerrianGrid.GetRandomLocationPointInGridForNode("iot");
                    //---
                    LocationProfile.GridCell cell= simuDB.terrain.TerrianGrid.GetCellForLocation(initLocation.X, initLocation.Y);
                    if ((cell.CellTerrianType==LocationProfile.GridCell.TerrianTypeCodes.Land_NotPartOfMapAndNotReachable) || (cell.CellTerrianType == LocationProfile.GridCell.TerrianTypeCodes.Water_NotPartOfMapAndNotReachable))
                    {
                        MessageBox.Show("what?");
                    }

                    //---
                        loc.MandatoryInit(0, simuConfig.ioTSpec.isIoTMobile, accel, simuDB.terrain, initLocation);
                    role = new NodeRolesProfile();
                    NodeRolesProfile.NodeRoleRecord rolereco = new NodeRolesProfile.NodeRoleRecord();
                    rolereco.MandatoryInit(0, nodeDataGenerationStatus);
                    role.AddNewRole(rolereco);
                    string nodeid = cu.RandomString(2, false) + cu.RandomNumber(3).ToString();
                    ComputerNode node = new ComputerNode();
                    node.ComputerNode_MandatoryInit( nodeid, hwp, loc, role, simuDB);

                    res.Add(node);
                }
            }

            simuDB.IoTNodes = res;

        }
        //-------------------------------------------------------------------End of IoT Nodes---------------------------------------------------------------

        //-------------------------------------------------------------------Cloud and Fog Nodes---------------------------------------------------------------
        int CountOfCloudProviders = Math.Max(1, cu.RandomNumber(simuConfig.cloudSpec.MinCountOfCloudProviders, simuConfig.cloudSpec.MaxCountOfCloudProviders));
        List<string> cloudNames = new List<string>();
        for (int i = 0; i < CountOfCloudProviders; i++)
        {
            string name = "";
            while ((name == "") || (cloudNames.IndexOf(name) >= 0)) name = "CP_" + getARandomName(true);
            cloudNames.Add(name);
            CloudProvider cp = new CloudProvider();
            cp.CloudProviderID = name;
            simuDB.CloudProviders.Add(cp);
        }
        foreach (CloudProvider cloudProvider in simuDB.CloudProviders)
        {
            int Count = Math.Max(1, cu.RandomNumber(simuConfig.cloudSpec.MinCountOfCloudProvidersDataCenters, simuConfig.cloudSpec.MaxCountOfCloudProvidersDataCenters));
            for (int i = 0; i < Count; i++)
            {
                string name = "DC_" + (i).ToString() + "_of_" + cloudProvider.CloudProviderID;
                DataCenter dc = new DataCenter();
                dc.DataCenterID = name;
                dc.ownerCloudProvider = cloudProvider;
                dc.Location = simuDB.terrain.TerrianGrid.GetRandomLocationPointInGridForNode("cloud");
                if (dc.Location == null)
                {
                    int h = 10;
                }
                simuDB.DataCenters.Add(dc);
                cloudProvider.MemberDataCenterIDs.Add(dc.DataCenterID);
            }
        }

        foreach (DataCenter dc in simuDB.DataCenters)
        {
            int Count = Math.Max(1, cu.RandomNumber(simuConfig.cloudSpec.MinCountOfClustersInDataCenter, simuConfig.cloudSpec.MaxCountOfClustersInDataCenter));
            for (int i = 0; i < Count; i++)
            {
                string name = "Clst_" + i.ToString() + "_of_" + dc.DataCenterID;
                Cluster cluster = new Cluster();
                cluster.ClusterID = name;
                cluster.ownerDataCenter = dc;


                simuDB.Clusters.Add(cluster);
                dc.MemberClusters.Add(cluster);
            }
        }
        int[] devcodesForCloudDataCenter = { NodeHardwareProfile.DeviceCodes.serverAMDRyzenThreadripper, NodeHardwareProfile.DeviceCodes.serverAMDMagnyCours, NodeHardwareProfile.DeviceCodes.serverIntelXeon5500, NodeHardwareProfile.DeviceCodes.serverIntelXeon6500 };
        int[] devcodesForFogPoints = { NodeHardwareProfile.DeviceCodes.serverAMDRyzen9, NodeHardwareProfile.DeviceCodes.serverCorei9_9900, NodeHardwareProfile.DeviceCodes.serverCorei7_8086 };
        int TotalMachinesInCloud = 0;
        for (int z = 0; z < simuDB.Clusters.Count; z++)
        {
            Cluster cluster = simuDB.Clusters[z];
            string ss = "Creating Cloud cluster number " + (z + 1).ToString() + " of " + simuDB.Clusters.Count.ToString();


            int Count = Math.Max(1, cu.RandomNumber(simuConfig.cloudSpec.MinCountOfNodesInDCCluster, simuConfig.cloudSpec.MaxCountOfNodesInDCCluster));
            for (int i = 0; i < Count; i++)
            {
                NodeHardwareProfile hwp = NodeHardwareProfile.TypicalGenerate(devcodesForCloudDataCenter[cu.RandomNumber(0, devcodesForCloudDataCenter.Length - 1)], NodeHardwareProfile.NodeTypes.Host_InCloudDataCenter, simuDB.SimuConfig.networkProfile);
                int accel = 0;
                string nodeid = "N_" + i.ToString() + "_of_" + cluster.ClusterID;
                LocationPoint currentLoc = cluster.ownerDataCenter.Location;
                LocationProfile loc = new LocationProfile();
                loc.MandatoryInit(0, false, accel, simuDB.terrain, currentLoc);
                NodeRolesProfile nodeRolesprofile = new NodeRolesProfile();
                NodeRolesProfile.NodeRoleRecord rolereco;


                rolereco = new NodeRolesProfile.NodeRoleRecord();
                rolereco.MandatoryInit(0, NodeRolesProfile.NodeRoleCodes.PerformSchedulingOnSelftAndOtherNodes);
                nodeRolesprofile.AddNewRole(rolereco);

                rolereco = new NodeRolesProfile.NodeRoleRecord();
                rolereco.MandatoryInit(0, NodeRolesProfile.NodeRoleCodes.OfferResourcesForScheduling);
                nodeRolesprofile.AddNewRole(rolereco);




                ComputerNode node = new ComputerNode();
                node.ComputerNode_MandatoryInit( nodeid, hwp, loc, nodeRolesprofile, simuDB);

                cluster.MemberNodes.Add(node);
                simuDB.Nodes.Add(node);
                node.InCloud_Fixed_OwnerCluster = cluster;

                string rep = Environment.NewLine + "Node " + i.ToString() + " of " + Count.ToString() + " added.";
                rep = ss + rep;
                reportbox.Invoke(new Action(() => reportbox.Text = rep));
                TotalMachinesInCloud++;
            }
        }


        //Creating Fog Providers
        int countOfFogProviders = Math.Max(1, cu.RandomNumber(simuConfig.fogSpec.MinCountOfFogProviders, simuConfig.fogSpec.MaxCountOfFogProviders));
        List<string> fogProviderNames = new List<string>();
        for (int i = 0; i < countOfFogProviders; i++)
        {
            string name = "";
            while ((name == "") || (fogProviderNames.IndexOf(name) >= 0))
            {
                name = getARandomName(true);
            }

            fogProviderNames.Add(name);
            FogProvider fp = new FogProvider();
            fp.FogProviderID = name;

            simuDB.FogProviders.Add(fp);
        }



        foreach (FogProvider fogpro in simuDB.FogProviders)
        {
            int Count = Math.Max(1, cu.RandomNumber(simuConfig.fogSpec.MinCountOfFogProviderFogPoint, simuConfig.fogSpec.MaxCountOfFogProviderFogPoint));
            for (int i = 0; i < Count; i++)
            {
                string name = "FP_" + (i).ToString() + "_of_" + fogpro.FogProviderID;
                FogPoint fp = new FogPoint();
                fp.FogPointID = name;
                fp.ownerFogProvider = fogpro;
                fp.Location = simuDB.terrain.TerrianGrid.GetRandomLocationPointInGridForNode("fog"); 
                simuDB.FogPoints.Add(fp);
                fogpro.MemberFogPointIDs.Add(fp.FogPointID);
            }
        }




        for (int z = 0; z < simuDB.FogPoints.Count; z++)
        {
            FogPoint fogpoint = simuDB.FogPoints[z];
            string ss = "Working on FogPoint " + z.ToString() + " of " + simuDB.FogPoints.Count.ToString();
            int Count = Math.Max(1, cu.RandomNumber(simuConfig.fogSpec.MinCountOfNodesInFogPointCluster, simuConfig.fogSpec.MaxCountOfNodesInFogPointCluster));
            for (int i = 0; i < Count; i++)
            {
                NodeHardwareProfile hwp = NodeHardwareProfile.TypicalGenerate(devcodesForFogPoints[cu.RandomNumber(0, devcodesForFogPoints.Length - 1)], NodeHardwareProfile.NodeTypes.Host_InFogPoint, simuDB.SimuConfig.networkProfile);
                int accel = 0;
                string nodeid = "N_" + i.ToString() + "_of_" + fogpoint.FogPointID;
                LocationProfile loc = new LocationProfile();
                loc.MandatoryInit(0, simuConfig.fogSpec.isFogMobile, accel, simuDB.terrain, fogpoint.Location); //zz may need new constructor
                NodeRolesProfile role = new NodeRolesProfile();
                NodeRolesProfile.NodeRoleRecord rolereco = new NodeRolesProfile.NodeRoleRecord();

                rolereco.MandatoryInit(0, NodeRolesProfile.NodeRoleCodes.PerformSchedulingOnSelftAndOtherNodes);
                role.AddNewRole(rolereco);//performs scheduling
                rolereco = new NodeRolesProfile.NodeRoleRecord();
                rolereco.MandatoryInit(0, NodeRolesProfile.NodeRoleCodes.OfferResourcesForScheduling);
                role.AddNewRole(rolereco);//performs scheduling

                ComputerNode node = new ComputerNode();
                node.ComputerNode_MandatoryInit( nodeid, hwp, loc, role, simuDB);
                fogpoint.MemberNodes.Add(node);
                simuDB.Nodes.Add(node);
                node.InFog_Fixed_OwnerFogPoint = fogpoint;
                string rep = ss + Environment.NewLine + "node " + i.ToString() + " of " + Count + "added.";
                reportbox.Invoke(new Action(() => reportbox.Text = rep));
            }
        }
        //-----------------

        //zz location of datacenters and fogpoints


        return simuDB;

    }


    public static void SetCoordinatorsForFogsAndDCs_Randomly(SimuData simuBank)
    {
        // simuBank.FogPoints
        // simuBank.Clusters
        foreach (Cluster cluster in simuBank.Clusters)
        {
            int r = (new CoUtils()).RandomNumber(0, cluster.MemberNodes.Count - 1);
            ComputerNode nodeSelectedAsclusterHead = cluster.MemberNodes[r];
            NodeRolesProfile role = new NodeRolesProfile();
            NodeRolesProfile.NodeRoleRecord rolereco = new NodeRolesProfile.NodeRoleRecord();
            rolereco.MandatoryInit(0, NodeRolesProfile.NodeRoleCodes.ClusterHead);
            nodeSelectedAsclusterHead.RoleProfile.AddNewRole(rolereco);
            cluster.CurrentClusterHead = nodeSelectedAsclusterHead;
        }
        foreach (FogPoint fogpoint in simuBank.FogPoints)
        {
            int r = (new CoUtils()).RandomNumber(0, fogpoint.MemberNodes.Count - 1);
            ComputerNode nodeSelectedAsclusterHead = fogpoint.MemberNodes[r];
            NodeRolesProfile role = new NodeRolesProfile();
            NodeRolesProfile.NodeRoleRecord rolereco = new NodeRolesProfile.NodeRoleRecord();
            rolereco.MandatoryInit(0, NodeRolesProfile.NodeRoleCodes.ClusterHead);
            nodeSelectedAsclusterHead.RoleProfile.AddNewRole(rolereco);
            fogpoint.CurrentClusterHead = nodeSelectedAsclusterHead;

        }
    }



}







public class CpuAndBandwidthBaseLines
{
    public void MandatoryInit(int _CPUFogCloudBaseLineMips, int _CPUCloudMachineBaseLineMips, int _CPUFogMachineBaseLineMips, int _CPUIoTMachineBaseLineMips, int _BandwidthInCloudBaseLine, int _BandwidthCloudFogBaseLine, int _BandwidthFogBaseLine, int _BandwidthIoTBaseLine)
    {
        CPUFogCloudBaseLineMips = _CPUFogCloudBaseLineMips;
        CPUCloudMachineBaseLineMips = _CPUCloudMachineBaseLineMips;
        CPUFogMachineBaseLineMips = _CPUFogMachineBaseLineMips;
        CPUIoTMachineBaseLineMips = _CPUIoTMachineBaseLineMips;
        BandwidthInCloudBaseLine = _BandwidthInCloudBaseLine;
        BandwidthCloudFogBaseLine = _BandwidthCloudFogBaseLine;
        BandwidthFogBaseLine = _BandwidthFogBaseLine;
        BandwidthIoTBaseLine = _BandwidthIoTBaseLine;
    }

    public int CPUFogCloudBaseLineMips, CPUCloudMachineBaseLineMips, CPUFogMachineBaseLineMips, CPUIoTMachineBaseLineMips, BandwidthInCloudBaseLine, BandwidthCloudFogBaseLine, BandwidthFogBaseLine, BandwidthIoTBaseLine;
}


