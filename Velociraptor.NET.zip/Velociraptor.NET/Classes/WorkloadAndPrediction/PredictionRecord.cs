﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Velociraptor.Classes
{
    class PredictionRecord
    {
        public decimal[] InputVector { get; }
        public decimal OutputValue { get; }
        public PredictionRecord(IWorkloadData WorkloadData)
        {
            InputVector = new decimal[64];
            InputVector[0] = WorkloadData.CountOfJobs;
            InputVector[1] = WorkloadData.CountOfTasks;
            InputVector[2] = WorkloadData.SumJobSize;
            InputVector[3] = WorkloadData.CountOfEdges;
            InputVector[4] = WorkloadData.ExecOnCloudParallel;
            InputVector[5] = WorkloadData.ExecOnCloudSerial;
            InputVector[6] = WorkloadData.ExecOnFogParallel;
            InputVector[7] = WorkloadData.ExecOnFogSerial;

            OutputValue = (decimal)WorkloadData.WorkloadScore;
        }
        public static List<PredictionRecord> GenerateListOfPredictionRecords(IWorkload Workload)
        {
            List<PredictionRecord> result=new List<PredictionRecord>();
            foreach (var item in Workload.WorkloadInfo)
            {
                PredictionRecord pr = new PredictionRecord(item.Value);
                result.Add(pr);
            }
            return result;
        }

    }






    class PredictionRecordLogger
    {

        public static void LogCollectionOfRecordsOnDB(SimuData simuDB, List<PredictionRecord> PRList)
        {
            foreach (var pr in PRList)
            {
                LogSingleRecordOnDB(simuDB, pr);
            }
        }
        public static void LogSingleRecordOnDB(SimuData simuDB, PredictionRecord PR)
        {
            SqlConnection sqlconn = simuDB.dal.getConnectionObject();
            if ((sqlconn == null)) return;
            if (sqlconn.State != ConnectionState.Open) sqlconn.Open();
            using (SqlCommand cmd = new SqlCommand("SP_WriteATrainingRecord", sqlconn))
            {
                cmd.CommandType = CommandType.StoredProcedure;
                for (int i = 0; i < PR.InputVector.Length; i++)
                {
                    cmd.Parameters.Add("@x" + (i + 1).ToString(), SqlDbType.Decimal).Value = PR.InputVector[i];
                }
                cmd.Parameters.Add("@y", SqlDbType.Decimal).Value = PR.OutputValue;
                DAL.ExecuteNonQuery(cmd);
                //cmd.ExecuteNonQuery();
            }
        }
    }
}
