﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Velociraptor.Classes
{
    public class WorkloadData : IWorkloadData
    {

        public long SumJobSize { get; set; }
        public long CountOfJobs { get; set; }
        public long CountOfTasks { get; set; }
        public long CountOfServers { get; set; }
        public long CountOfEdges { get; set; }
        public long ExecOnCloudSerial { get; set; }
        public long ExecOnFogSerial { get; set; }
        public long ExecOnCloudParallel { get; set; }
        public long ExecOnFogParallel { get; set; }
        private double _WorkloadScore = -1;
        public double WorkloadScore
        {
            get
            {
                if (_WorkloadScore != -1) return _WorkloadScore; else throw new Exception("not calculated yet!");
            }
            set
            {
                if (_WorkloadScore == -1) _WorkloadScore = value; else throw new Exception("re-assigning workload value is not permitted!");
            }
        }
    }

    class Workload : IWorkload
    {
        long _MaxJobSize, _MinJobSize;
        public Dictionary<int, WorkloadData> WorkloadInfo { get; }
        private long _MaxCountOfJobs;
        private long _MinCountOfJobs;
        private long _MinCountOfTasks;
        private long _MaxCountOfTasks;



        public Workload(List<Job> Jobs)
        {
            Jobs.Sort((x, y) => x.TimeSubmission.CompareTo(y.TimeSubmission));
            var JobGroups = from job in Jobs
                            group job by job.TimeSubmission
                            into jobgroup
                            orderby jobgroup.Key
                            select jobgroup;
            WorkloadInfo = new Dictionary<int, WorkloadData>();
            foreach (var group in JobGroups)
            {
                WorkloadData wl = new WorkloadData()
                {
                    SumJobSize = group.Sum(t => t.JobSizeWithoutAccountForParallelism),
                    CountOfJobs = group.Count(),
                    CountOfTasks = group.Sum(t => t.CountOfTasks),
                    CountOfEdges = group.Sum(t => t.CountOfEdges),
                    ExecOnCloudSerial = group.Sum(t => (long)t.MinTimeForExecuteDagSerialOnCloud),
                    ExecOnFogSerial = group.Sum(t => (long)t.MinTimeForExecuteDagSerialOnFog),

                    ExecOnCloudParallel = group.Sum(t => (long)t.MinTimeForExecuteDagWithMaxParallelismOnCloud),
                    ExecOnFogParallel = group.Sum(t => (long)t.MinTimeForExecuteDagWithMaxParallelismOnFog),
                };
                WorkloadInfo.Add(group.Key, wl);
            }
            CalculateWorkloadScores();


        }

        private void CalculateWorkloadScores()
        {

            _MaxJobSize = WorkloadInfo.Max(t => t.Value.SumJobSize);
            _MinJobSize = WorkloadInfo.Min(t => t.Value.SumJobSize);
            _MaxCountOfJobs = WorkloadInfo.Min(t => t.Value.CountOfJobs);
            _MinCountOfJobs = WorkloadInfo.Min(t => t.Value.CountOfJobs);
            _MinCountOfTasks = WorkloadInfo.Min(t => t.Value.CountOfTasks);
            _MaxCountOfTasks = WorkloadInfo.Min(t => t.Value.CountOfTasks);

            foreach (var item in WorkloadInfo)
            {
                item.Value.WorkloadScore = CalculateWorkloadScore(item.Key);
            }
        }
        double CalculateWorkloadScore(int Time)
        {
            var item = WorkloadInfo[Time];
            double r = 4* (double)(item.SumJobSize) / (this._MaxJobSize);
            r += (double)(item.CountOfJobs ) /( this._MaxCountOfJobs );
            r += (double)(item.CountOfTasks ) /( this._MaxCountOfTasks );
            return r;
        }
    }

}
