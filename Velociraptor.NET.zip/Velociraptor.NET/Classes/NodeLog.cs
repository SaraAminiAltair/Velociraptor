﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Windows.Forms;

public partial class ComputerNode
{
    void DoLogs()
    {
        NodeStepLog log = new NodeStepLog();
        log.DoAcceptBeingClusterHead = this.ClusterInfo_Wifi.MyInfoToShareWithOhers.DoAcceptBeingClusterHead;
        log.SimulationTime = this.CurrentSimulationTime;
        log.MyScore = this.ClusterInfo_Wifi.MyInfoToShareWithOhers.Score;
        log.Date = this.Date;
        log.ActionForManagement = _thisStepActionForManagement;
        log.ActionForMovement = _thisStepActionForMovement;
        log.ActionForPackets = _thisStepActionForPackets;
        log.ActionForScheduling = _thisStepActionForScheduling; ;
        log.EnergyCurrent = this.HardwareProfile.PowerSupplyProfile.EnergyCurrent;
        log.CountOfAllowedMembers = this.ClusterInfo_Wifi.MyInfoToShareWithOhers.MaximumMembersThreshold_Partovi;
        log.EnergyUsedInThisStep = this.HardwareProfile.PowerSupplyProfile.EnergyUsedInThisStep;
        log.NeighborsStability = this.ClusterInfo_Wifi.MyInfoToShareWithOhers.NeighborsStabilityFactorBy_TimeBeingNearFormula;
        log.CountOfNeighborsNormalized = this.ClusterInfo_Wifi.MyInfoToShareWithOhers.CountOfNeighborsNormalized;

        this.HardwareProfile.PowerSupplyProfile.EnergyUsedInThisStep = 0; //reset the field


        log.isCPUIdle = this.HardwareProfile.ComputerHardwareProfile.CPUProfile.isIdle;
        log.RamFree = this.HardwareProfile.ComputerHardwareProfile.Ram_free;
        log.StorageFree = this.HardwareProfile.ComputerHardwareProfile.StorageProfile.HDDFree;
        log.DistanceFromTarget = LocationProfile.DistanceFromTarget;
        //clustering related
        log.clusterRelatedInfo_WiFi = this.ClusterInfo_Wifi.GetCopy();
        log.clusterRelatedInfo_Bluetooth = this.ClusterInfo_Bluetooth.GetCopy();
        //---

        NodeStepLogs.Add(log);

        _thisStepActionForManagement = _thisStepActionForMovement = _thisStepActionForPackets = _thisStepActionForScheduling = "";
        
        



    }

    private void Log_NodeInit(SimuData simuDB)
    {
        try
        {


            string clusterOrFogpointID = "";
            if (this.InCloud_Fixed_OwnerCluster != null) clusterOrFogpointID = this.InCloud_Fixed_OwnerCluster.ClusterID;
            if (this.InFog_Fixed_OwnerFogPoint != null) clusterOrFogpointID = this.InFog_Fixed_OwnerFogPoint.FogPointID;

            //NodeID_OnDatabase should be set.
            SqlConnection sqlConn = simuDB.dal.getConnectionObject();
            if ((sqlConn == null)) return;
            if (sqlConn.State != ConnectionState.Open) sqlConn.Open();
            using (SqlCommand cmd = new SqlCommand("SP_NodesInit", sqlConn))
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@PowerSupplyType", SqlDbType.NVarChar).Value = NodeHardwareProfile.HardwarePowerSupply.PowerSupplyType.getPowerSupplyTypeAsText(HardwareProfile.PowerSupplyProfile.PowerType);
                cmd.Parameters.Add("@EnergyStart", SqlDbType.Int).Value = Convert.ToInt32(HardwareProfile.PowerSupplyProfile.EnergyStart);
                cmd.Parameters.Add("@NodeDeviceName", SqlDbType.NVarChar).Value = HardwareProfile.NodeDeviceName;
                cmd.Parameters.Add("@NodeID", SqlDbType.NVarChar).Value = NodeID;
                cmd.Parameters.Add("@NodeTypeCode", SqlDbType.NVarChar).Value = NodeHardwareProfile.NodeTypes.getNodeTypeAsText(this.HardwareProfile.NodeTypeCode);
                cmd.Parameters.Add("@OwnerClusterID", SqlDbType.NVarChar).Value = clusterOrFogpointID;
                cmd.Parameters.Add("@Storage", SqlDbType.NVarChar).Value = HardwareProfile.ComputerHardwareProfile.StorageProfile.getStorageHardwareAsText();
                cmd.Parameters.Add("@RAM", SqlDbType.Int).Value = HardwareProfile.ComputerHardwareProfile.Ram_free;
                cmd.Parameters.Add("@CPU", SqlDbType.Int).Value = HardwareProfile.ComputerHardwareProfile.CPUProfile.CPUCurrentMIPS_hardware;
                cmd.Parameters.Add("@NetworkInterfaceMalfunctionProbablity", SqlDbType.Float).Value = HardwareProfile.NodePacketLossProbablityDueToMalfuntionInHWorSW;


                var NodeID_InDB = cmd.Parameters.Add("@ReturnVal", SqlDbType.Int);
                NodeID_InDB.Direction = ParameterDirection.ReturnValue;
                DAL.ExecuteNonQuery(cmd);
                //cmd.ExecuteNonQuery();
                NodeID_OnDatabase = Convert.ToInt32(NodeID_InDB.Value);
            }
        }
        catch (Exception ee)
        {

            //   MessageBox.Show("Error in Logging Node Initialization" + Environment.NewLine + Environment.NewLine + ee.ToString());
            System.Threading.Thread.Sleep(4000);

        }
    }

    public void Log_NodeSteps(SqlConnection SqlConnectionForLoggingDatabase)
    {



        CoUtils cu = new CoUtils();
        if ((SqlConnectionForLoggingDatabase == null)) return;
        if (SqlConnectionForLoggingDatabase.State != ConnectionState.Open) SqlConnectionForLoggingDatabase.Open();
        for (int i = 0; i < NodeStepLogs.Count; i++)
        {
            try
            {
                using (SqlCommand cmd = new SqlCommand("SP_NodeLogStepVer3", SqlConnectionForLoggingDatabase))
                {
                    cmd.CommandType = CommandType.StoredProcedure;

                    cmd.Parameters.Add("@ActionForPackets", SqlDbType.NVarChar).Value = NodeStepLogs[i].ActionForPackets;
                    cmd.Parameters.Add("@NodeID", SqlDbType.NVarChar).Value = this.NodeID;

                    cmd.Parameters.Add("@ActionForScheduling", SqlDbType.NVarChar).Value = NodeStepLogs[i].ActionForScheduling;
                    cmd.Parameters.Add("@ActionForManagement", SqlDbType.NVarChar).Value = NodeStepLogs[i].ActionForManagement;
                    cmd.Parameters.Add("@NodeIDKey", SqlDbType.Int).Value = NodeID_OnDatabase;
                    cmd.Parameters.Add("@Date", SqlDbType.NVarChar).Value = NodeStepLogs[i].Date;
                    cmd.Parameters.Add("@Time", SqlDbType.NVarChar).Value = NodeStepLogs[i].SimulationTime;
                    if (LocationProfile.LocationHistory.Count == 0)
                    { //this is not a mobile node
                        cmd.Parameters.Add("@DistanceFromTarget", SqlDbType.Int).Value = 0;
                        cmd.Parameters.Add("@x", SqlDbType.Int).Value = LocationProfile.LocationCurrent.LocationPoint.X;
                        cmd.Parameters.Add("@Y", SqlDbType.Int).Value = LocationProfile.LocationCurrent.LocationPoint.Y;
                        cmd.Parameters.Add("@Z", SqlDbType.Int).Value = LocationProfile.LocationCurrent.LocationPoint.Z;
                        cmd.Parameters.Add("@Target_X", SqlDbType.Int).Value = LocationProfile.LocationCurrent.LocationPoint.X;
                        cmd.Parameters.Add("@Target_Y", SqlDbType.Int).Value = LocationProfile.LocationCurrent.LocationPoint.Y;
                        cmd.Parameters.Add("@Target_Z", SqlDbType.Int).Value = LocationProfile.LocationCurrent.LocationPoint.Z;
                        cmd.Parameters.Add("@SpeedCurrent", SqlDbType.Int).Value = 0;
                        cmd.Parameters.Add("@Acceleration", SqlDbType.Float).Value = 0;
                        cmd.Parameters.Add("@ActionForMovement", SqlDbType.NVarChar).Value = "";
                    }
                    else
                    {
                        cmd.Parameters.Add("@DistanceFromTarget", SqlDbType.Int).Value = NodeStepLogs[i].DistanceFromTarget;
                        cmd.Parameters.Add("@x", SqlDbType.Int).Value = LocationProfile.LocationHistory[i].LocationPoint.X;
                        cmd.Parameters.Add("@Y", SqlDbType.Int).Value = LocationProfile.LocationHistory[i].LocationPoint.Y;
                        cmd.Parameters.Add("@Z", SqlDbType.Int).Value = LocationProfile.LocationHistory[i].LocationPoint.Z;
                        cmd.Parameters.Add("@Target_X", SqlDbType.Int).Value = LocationProfile.LocationHistory[i].TargetPoint.X;
                        cmd.Parameters.Add("@Target_Y", SqlDbType.Int).Value = LocationProfile.LocationHistory[i].TargetPoint.Y;
                        cmd.Parameters.Add("@Target_Z", SqlDbType.Int).Value = LocationProfile.LocationHistory[i].TargetPoint.Z;
                        cmd.Parameters.Add("@SpeedCurrent", SqlDbType.Int).Value = LocationProfile.LocationHistory[i].CurrentSpeed;
                        cmd.Parameters.Add("@Acceleration", SqlDbType.Float).Value = (float)LocationProfile.LocationHistory[i].Acceleration;
                        cmd.Parameters.Add("@ActionForMovement", SqlDbType.NVarChar).Value = NodeStepLogs[i].ActionForMovement;
                    }
                    cmd.Parameters.Add("@RamFree", SqlDbType.Int).Value = this.HardwareProfile.ComputerHardwareProfile.Ram_free;
                    cmd.Parameters.Add("@StorageFree", SqlDbType.Int).Value = this.HardwareProfile.ComputerHardwareProfile.StorageProfile.HDDFree;
                    cmd.Parameters.Add("@isCPUIdle", SqlDbType.Int).Value = booltoint(NodeStepLogs[i].isCPUIdle);
                    cmd.Parameters.Add("@EnergyCurrent", SqlDbType.Decimal).Value = NodeStepLogs[i].EnergyCurrent;
         
                    cmd.Parameters.Add("@CountOfAllowedMembers", SqlDbType.Int).Value = NodeStepLogs[i].CountOfAllowedMembers;
                    cmd.Parameters.Add("@EnergyUsedInThisStep", SqlDbType.Int).Value = Convert.ToInt32(NodeStepLogs[i].EnergyUsedInThisStep);

                    //clustering related
                    cmd.Parameters.Add("@Cl_NeighborsTable", SqlDbType.NVarChar).Value = NodeStepLogs[i].clusterRelatedInfo_WiFi.NeighborsTable.GetNeighborsTableAsString();
                    cmd.Parameters.Add("@Cl_OneHopNeighborsNodeIDs", SqlDbType.NVarChar).Value = NodeStepLogs[i].clusterRelatedInfo_WiFi.NeighborsTable.GetListOfNeighborsNodeID();
                    cmd.Parameters.Add("@Cl_CurrentListOfCH", SqlDbType.NVarChar).Value = cu.ListToString(NodeStepLogs[i].clusterRelatedInfo_WiFi.MyInfoToShareWithOhers.ListofMyClusterHeads);
                    cmd.Parameters.Add("@Cl_AvailableListOfCH", SqlDbType.NVarChar).Value = cu.ListToString(NodeStepLogs[i].clusterRelatedInfo_WiFi.MyAvailableClusterHeadNodeIDs);
                    cmd.Parameters.Add("@Cl_SelfScore", SqlDbType.Decimal).Value = NodeStepLogs[i].MyScore;
                    cmd.Parameters.Add("@DoAcceptBeingClusterHead", SqlDbType.Int).Value = booltoint(NodeStepLogs[i].DoAcceptBeingClusterHead);
                    if (NodeStepLogs[i].DoAcceptBeingClusterHead!=true)
                    {
                        int a = 10;
                    }


                    cmd.Parameters.Add("@Cl_ListOfMemberNodes", SqlDbType.NVarChar).Value = cu.ListToString(NodeStepLogs[i].clusterRelatedInfo_WiFi.MyInfoToShareWithOhers.ListOfMemberNodes);
                    List<NeighborInfo> nchn = NodeStepLogs[i].clusterRelatedInfo_WiFi.NeighborsTable.GetListOfNeighborsWhichAreClusterHead();

                    cmd.Parameters.Add("@Cl_ListOfNeighborClusterHeadNodes", SqlDbType.NVarChar).Value = ListNeighborsToString(nchn);
                    cmd.Parameters.Add("@Cl_CountOfNeighborsWhichAreCH", SqlDbType.Int).Value = nchn.Count;
                    cmd.Parameters.Add("@Cl_CountOfMembers", SqlDbType.Int).Value = NodeStepLogs[i].clusterRelatedInfo_WiFi.MyInfoToShareWithOhers.ListOfMemberNodes.Count;
                    cmd.Parameters.Add("@Cl_CurrentDurationOfBeingCH", SqlDbType.Int).Value = NodeStepLogs[i].clusterRelatedInfo_WiFi.MyInfoToShareWithOhers.CurrrentDurationOfBeingCH;
                    cmd.Parameters.Add("@Cl_TotalDurationOfBeingCH", SqlDbType.Int).Value = NodeStepLogs[i].clusterRelatedInfo_WiFi.MyInfoToShareWithOhers.TotalDurationOfBeingCH;

                    cmd.Parameters.Add("@Cl_Availability", SqlDbType.Decimal).Value = NodeStepLogs[i].clusterRelatedInfo_WiFi.MyInfoToShareWithOhers.Availability;
                    cmd.Parameters.Add("@Cl_Reputation", SqlDbType.Decimal).Value = NodeStepLogs[i].clusterRelatedInfo_WiFi.MyInfoToShareWithOhers.ReputationEsfandiari;
                    cmd.Parameters.Add("@Cl_TransferedData", SqlDbType.Int).Value = NodeStepLogs[i].clusterRelatedInfo_WiFi.MyInfoToShareWithOhers.DataTransfered_inKB;
                    cmd.Parameters.Add("@Cl_CountOfReceivedRequests", SqlDbType.Int).Value = NodeStepLogs[i].clusterRelatedInfo_WiFi.MyInfoToShareWithOhers.CountOfReceivedRequests;
                    cmd.Parameters.Add("@Cl_CountOfSuccessfullyTransmittedRequests", SqlDbType.Int).Value = NodeStepLogs[i].clusterRelatedInfo_WiFi.MyInfoToShareWithOhers.CountOfSuccessfullyTransferedRequests;

                    cmd.Parameters.Add("@Cl_NeighborsStabilityFactor", SqlDbType.Decimal).Value = NodeStepLogs[i].clusterRelatedInfo_WiFi.MyInfoToShareWithOhers.NeighborsStabilityFactorBy_TimeBeingNearFormula;
                    cmd.Parameters.Add("@Cl_CountOfNeighbors", SqlDbType.Int).Value = NodeStepLogs[i].clusterRelatedInfo_WiFi.MyInfoToShareWithOhers.CountOfNeighbors;
                    cmd.Parameters.Add("@Cl_CountOfNeighborsNormalized", SqlDbType.Decimal).Value = NodeStepLogs[i].clusterRelatedInfo_WiFi.MyInfoToShareWithOhers.CountOfNeighborsNormalized;

                    DAL.ExecuteNonQuery(cmd);
                    //cmd.ExecuteNonQuery();



                }
            }
            catch (Exception exception)
            {
                //     MessageBox.Show("Error in Logging Node Step " + i.ToString() + Environment.NewLine + Environment.NewLine + exception.ToString());
                System.Threading.Thread.Sleep(1000);


            }
        }


    }


}
