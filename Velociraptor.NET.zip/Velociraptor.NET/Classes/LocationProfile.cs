﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for SLocationProfile
/// </summary>
public class LocationProfile
{
    CoUtils cu = new CoUtils();
    public SLocation LocationCurrent;
    public List<SLocation> LocationHistory;
    public LocationPoint Target;

    public int SpeedMax, SpeedMin;
    double reachTargetThreshold;
    public bool canMove;
    int RemainingTimeToWaitAtThisLocation = 0;


    public int DistanceFromTarget;


    public static double DistanceTwoPoints(LocationPoint d1, LocationPoint d2)
    {
        double dist = Math.Sqrt(Math.Pow(Math.Abs(d1.X - d2.X), 2) + Math.Pow(Math.Abs(d1.Y - d2.Y), 2) + Math.Pow(Math.Abs(d1.Z - d2.Z), 2));
        return dist;
    }
    private bool TargetReached()
    {
        this.reachTargetThreshold = SpeedMax;
        this.DistanceFromTarget = Convert.ToInt32(DistanceTwoPoints(Target, LocationCurrent.LocationPoint));
        if (this.DistanceFromTarget <= this.reachTargetThreshold) return true; else return false;
    }
    public string MoveOneStep(SimuCfg.Terrain terrain, int simulationTime, string nodeTypeAsString)
    {

        string r = "";
        if (!canMove)
        {
            SLocation currentLocCopy = this.LocationCurrent.GetACopy();
            LocationHistory.Add(currentLocCopy);
            return r;
        }

        if (Target == null)
        {
            LocationPoint p = terrain.TerrianGrid.GetRandomLocationPointInGridForNode(nodeTypeAsString);
            Target = p;
            LocationCurrent.CurrentSpeed = cu.RandomNumber(SpeedMin, SpeedMax);// ;
            r = "NoTarget,NewTargetSelected,";
        }

        if (RemainingTimeToWaitAtThisLocation > 0)
        {
            RemainingTimeToWaitAtThisLocation--;
            r = r + "WaitingAtThisLocationForNext_" + RemainingTimeToWaitAtThisLocation.ToString() + "_TimeSteps";
            LocationCurrent.CurrentSpeed = 0;
        }
        else
        {
            if (TargetReached())
            {


                r = r + "TargetReached,";
                bool x = WaitHere();
                if (!x)
                {
                    LocationPoint p = terrain.TerrianGrid.GetRandomLocationPointInGridForNode(nodeTypeAsString);
                    LocationCurrent.CurrentSpeed = cu.RandomNumber(SpeedMin, SpeedMax);// ;
                    Target = p;

                    r = r + "NewTargetSelected,";
                }
                else
                {
                    RemainingTimeToWaitAtThisLocation = cu.RandomNumber(terrain.WaitAtLocationMin, terrain.WaitAtLocationMax);
                    r = r + "WaitingAtThisLocationForNext_" + RemainingTimeToWaitAtThisLocation.ToString() + "_TimeSteps";
                    LocationCurrent.CurrentSpeed = 0;
                }

            }
        }
        float Speed = LocationCurrent.CurrentSpeed;
        float DirectionAngle = 0;
        LocationPoint newLocPoint = getNextPointUpponMovement(out DirectionAngle);
        SLocation newLoc = new SLocation();

        newLoc.MandatoryInit(simulationTime, newLocPoint, DirectionAngle, LocationCurrent.Acceleration, Target);
        newLoc.CurrentSpeed = LocationCurrent.CurrentSpeed;

        if (LocationCurrent.CurrentSpeed > 0) r = r + " Moving Toward Target ";
        LocationHistory.Add(newLoc);
        LocationCurrent = newLoc;

        return r;
    }
    bool WaitHere()
    {
        if (cu.RandomNumber(0, 100) < 90) return false;// no need to wait, start right for next target
        else return true;
    }

    private LocationPoint getNextPointUpponMovement(out float DirectionAngleInRadians)
    {
        float dist = LocationCurrent.CurrentSpeed;
        double AngleInRadians;

        double dy = (double)(Target.Y - LocationCurrent.LocationPoint.Y);
        double dx = (double)(Target.X - LocationCurrent.LocationPoint.X);
        AngleInRadians = Math.Atan2(dy, dx);

        int xProgress;
        int yProgress;
        if (dx == 0) xProgress = 0; else xProgress = Convert.ToInt32(dist * Math.Cos(AngleInRadians));
        if (dy == 0) yProgress = 0; else yProgress = Convert.ToInt32(dist * Math.Sin(AngleInRadians));

        int newx = LocationCurrent.LocationPoint.X + xProgress,
        newy = LocationCurrent.LocationPoint.Y + yProgress,
        newz = Target.Z;

        LocationPoint lopo = new LocationPoint();
        lopo.MandatoryInit(newx, newy, newz);
        DirectionAngleInRadians = (float)AngleInRadians;

        return lopo;
    }

    public void MandatoryInit(int simulationTime, bool isMobile, float _Accelaration, SimuCfg.Terrain terrain, LocationPoint _CurrentLocation)
    {
        LocationHistory = new List<SLocation>();
        CoUtils cu = new CoUtils();
        float Angle = 0;
        _Accelaration = 0;
        canMove = isMobile;
        this.SpeedMax = terrain.SpeedMaxAllowed;
        this.SpeedMin = terrain.SpeedMinAllowed;


        LocationCurrent = new SLocation();
        LocationCurrent.MandatoryInit(simulationTime, _CurrentLocation, Angle, _Accelaration, Target); ;
        SLocation l = LocationCurrent.GetACopy();
        LocationHistory.Add(l);
    }

    /* public SLocationProfile(int simulationTime, bool isMobile, double _Accelaration, int currentSpeed, int SpeedMax, Terrain terrain)
     {
         init(simulationTime, isMobile, _Accelaration, currentSpeed, SpeedMax, terrain.GeoXmin, terrain.GeoXmax, terrain.GeoYmin, terrain.GeoYmax, terrain.GeoZmin, terrain.GeoZmax);
     }
     */

    private void init(int simulationTime, bool isMobile, float _Accelaration, int currentSpeed, int SpeedMax, int GeoXmin, int GeoXmax, int GeoYmin, int GeoYmax, int GeoZmin, int GeoZmax)
    {
        LocationHistory = new List<SLocation>();
        CoUtils cu = new CoUtils();

        float Angle = 0;
        int geox = cu.RandomNumber(GeoXmin, GeoXmax)
            , geoy = cu.RandomNumber(GeoYmin, GeoYmax)
            , geoz = cu.RandomNumber(GeoZmin, GeoZmax);
        LocationPoint currentLoc = new LocationPoint();

        currentLoc.MandatoryInit(geox, geoy, geoz);

        _Accelaration = 0;
        canMove = isMobile;


        LocationCurrent = new SLocation();
        LocationCurrent.MandatoryInit(simulationTime, currentLoc, Angle, _Accelaration, Target);
    }

    /*  public SLocationProfile(int simulationTime, bool isMobile, double _Accelaration, int currentSpeed, int SpeedMax, int GeoXmin, int GeoXmax, int GeoYmin, int GeoYmax, int GeoZmin, int GeoZmax)
      {
          init(simulationTime, isMobile, _Accelaration, currentSpeed, SpeedMax, GeoXmin, GeoXmax, GeoYmin, GeoYmax, GeoZmin, GeoZmax);
      }
      */

    public static int getQuartile(int currentValue, int maxValue)
    {
        double v = currentValue / maxValue;
        if (v <= 0.25) return 1;
        if ((v > 0.25) && (v <= 0.5)) return 2;
        if ((v > 0.5) && (v <= 0.75)) return 3;
        if ((v > 0.75) && (v <= 1)) return 4;
        return 0;

    }


    public class GridOverlay
    {
        public GridOverlay(string gridName, GridCell[,] cells, int gridWidthInMeters, int gridHeightInMeters, int cellWidthInMeters)
        {
            this.GridName = gridName;
            this.GridWidthInMeters = gridWidthInMeters;
            this.GridHeightInMeters = gridHeightInMeters;
            this.CellWidthInMeters = cellWidthInMeters;
            this.Cells = cells;

            CheckGridForAtleastOneCellForEach(cells);

        }
        public string GridName;
        public GridCell[,] Cells;
        public int GridWidthInMeters, GridHeightInMeters, CellWidthInMeters;





        public void SaveGridOverLayToDatabase(SqlConnection sql)
        {
            CoUtils cu = new CoUtils();


            if ((sql == null)) return;
            if (sql.State != ConnectionState.Open) sql.Open();


            for (int i = 0; i < Cells.GetLength(0); i++)
            {
                for (int j = 0; j < Cells.GetLength(1); j++)
                {
                    GridCell cell = this.Cells[i, j];
                    using (SqlCommand cmd = new SqlCommand("SP_CellAddnew", sql))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.Add("@RowNumber", SqlDbType.Int).Value = cell.CellIndex_Y;
                        cmd.Parameters.Add("@ColNumber", SqlDbType.Int).Value = cell.CellIndex_X;
                        cmd.Parameters.Add("@Width", SqlDbType.Int).Value = cell.CellWidth;
                        cmd.Parameters.Add("@LeftX", SqlDbType.Int).Value = cell.LeftX;
                        cmd.Parameters.Add("@BottomY", SqlDbType.Int).Value = cell.BottomY;
                        cmd.Parameters.Add("@TerrianType", SqlDbType.NVarChar).Value = LocationProfile.GridCell.TerrianTypeCodes.GetTerrianTypeAsString(cell.CellTerrianType);
                        cmd.Parameters.Add("@CanIoT", SqlDbType.Int).Value = cu.BoolToInt(cell.CanHostIoTNode);
                        cmd.Parameters.Add("@CanCloud", SqlDbType.Int).Value = cu.BoolToInt(cell.CanHostCloudDC);
                        cmd.Parameters.Add("@CanFog", SqlDbType.Int).Value = cu.BoolToInt(cell.CanHostFogPoint);
                        cmd.Parameters.Add("@Description", SqlDbType.NVarChar).Value = cell.Description;
                        DAL.ExecuteNonQuery(cmd);
                        //cmd.ExecuteNonQuery();

                    }
                }
            }

        }


        public LocationPoint GetRandomLocationPointInGridForNode(string nodeTypeAsString)
        {
            int maximumTries = 1000;
            LocationPoint newPoint = null;
            while ((newPoint == null) && (maximumTries > 0))
            {
                newPoint = GetRandomLocationPointInGrid();
                bool x = this.IsLocationReachableForNode(nodeTypeAsString, newPoint.X, newPoint.Y);
                if (x == false) newPoint = null;
                maximumTries--;
            }
            if (maximumTries == 0)
            {
                throw new Exception("no cell found for this node");
            }

            return newPoint;
        }

        private LocationPoint GetRandomLocationPointInGrid()
        {

            CoUtils cu = new CoUtils();

            int x, y, z;

            x = cu.RandomNumber(0, this.GridWidthInMeters);
            y = cu.RandomNumber(0, this.GridHeightInMeters);
            z = 0;

            LocationPoint l = new LocationPoint();
            l.MandatoryInit(x, y, z);
            return l;
        }

        public int GetCountOfRows()
        {
            if (Cells == null) return 0; else return Cells.GetLength(0);
        }
        public int GetCountOfColumns()
        {
            if (Cells == null) return 0; else return Cells.GetLength(1);
        }

        public GridCell GetCellForLocation(ComputerNode node)
        {
            return GetCellForLocation(node.LocationProfile.LocationCurrent.LocationPoint.X, node.LocationProfile.LocationCurrent.LocationPoint.Y);
        }
        public GridCell GetCellForLocation(int x, int y) // returns the cell that contains the location indicated by x,y
        {
            if ((x > this.GridWidthInMeters) || (y > this.GridHeightInMeters)) return null;

            int i = 0, j = 0;
            if (x <= this.GridWidthInMeters) j = Convert.ToInt32(Math.Floor((double)x / this.CellWidthInMeters));
            if (y <= this.GridHeightInMeters) i = Convert.ToInt32(Math.Floor((double)y / this.CellWidthInMeters));
            if (x == this.GridWidthInMeters) j--;
            if (y == this.GridHeightInMeters) i--;
            return Cells[i, j];

        }

        public void LoadNodesToGrid(List<ComputerNode> nodes)
        {
            foreach (ComputerNode node in nodes)
            {
                if ((node.LocationProfile.LocationHistory == null) || (node.LocationProfile.LocationHistory.Count == 0))
                {
                    int hh = 0;
                }
                else
                {
                    GridCell c = this.GetCellForLocation(node.LocationProfile.LocationHistory[0].LocationPoint.X, node.LocationProfile.LocationHistory[0].LocationPoint.Y);
                    if (c != null)
                    {
                        switch (node.NodeTypeAsString)
                        {
                            case "iot": c.CurrentlyHasIoT = true; break;
                            case "fog": c.CurrentlyHasFogpoint = true; break;
                            case "cloud": c.CurrentlyHasCloudDC = true; break;
                            case "bts": c.CurrentlyHasBTS = true; break;
                        }

                        if ((!c.CanHostCloudDC) && (!c.CanHostFogPoint) && (!c.CanHostIoTNode))
                        {
                            int hh = 0;
                        }
                    }
                }


            }

        }
        public bool IsLocationReachableForNode(string nodeTypeAsString, int x, int y) // check whether a location is reachable for particular node
        {
            GridCell c = GetCellForLocation(x, y);
            bool isReachable = c.IsThisCellReachableForNode(nodeTypeAsString);
            if ((isReachable) && ((c.CellTerrianType == GridCell.TerrianTypeCodes.Water_NotPartOfMapAndNotReachable) || (c.CellTerrianType == GridCell.TerrianTypeCodes.Land_NotPartOfMapAndNotReachable)))
            {
                int hh = 0;
            }
            return isReachable;
        }


        private static void CheckGridForAtleastOneCellForEach(GridCell[,] Cells)
        {
            bool foundForCloud = false;
            bool foundForFog = false;
            bool foundForIoT = false;
            bool isReachable = false;


            for (int i = 0; i < Cells.GetLength(0); i++)
            {
                for (int j = 0; j < Cells.GetLength(1); j++)
                {
                    if ((Cells[i, j].CellTerrianType == GridCell.TerrianTypeCodes.Water_Reachable) || (Cells[i, j].CellTerrianType == GridCell.TerrianTypeCodes.Land_Reachable)) isReachable = true;

                    if (Cells[i, j].CanHostCloudDC) foundForCloud = true;
                    if (Cells[i, j].CanHostFogPoint) foundForFog = true;
                    if (Cells[i, j].CanHostIoTNode) foundForIoT = true;
                }
            }

            if (!isReachable)
            {
                for (int i = 0; i < Cells.GetLength(0); i++)
                {
                    for (int j = 0; j < Cells.GetLength(1); j++)
                    {
                        Cells[i, j].CellTerrianType = GridCell.TerrianTypeCodes.Land_Reachable;
                    }
                }
            }

            if ((foundForIoT == false) || (foundForCloud == false) || (foundForFog == false))

            {
                for (int i = 0; i < Cells.GetLength(0); i++)
                {
                    for (int j = 0; j < Cells.GetLength(1); j++)
                    {
                        if ((Cells[i, j].CellTerrianType == GridCell.TerrianTypeCodes.Land_Reachable) || (Cells[i, j].CellTerrianType == GridCell.TerrianTypeCodes.Water_Reachable))
                        {
                            Cells[i, j].CanHostCloudDC =
                           Cells[i, j].CanHostFogPoint =
                             Cells[i, j].CanHostIoTNode = true;
                        }
                    }
                }
            }


        }


        public static GridOverlay GenerateSimpleSquareGrid(int cellWidth, int widthOfCityInMeters, int heightOfCityInMeters)
        {
            string gridName = "SimpleGrid";
            int gridWidthInMeters = widthOfCityInMeters;
            int gridHeightInMeters = heightOfCityInMeters;
            int cellWidthInMeters = cellWidth;

            int percentOfIoTReachable = 90
                , percentOfCloudReachable = 20
                , percentOfFogReachable = 50
                , percentOfBeingReachable = 100
                , percentOfBeingLand = 85;

            int countOf_X_Cells = gridWidthInMeters / cellWidthInMeters, countOf_Y_Cells = gridHeightInMeters / cellWidthInMeters;
            GridCell[,] cells = new GridCell[countOf_Y_Cells, countOf_X_Cells];
            for (int i = 0; i < cells.GetLength(0); i++)
            {

                for (int j = 0; j < cells.GetLength(1); j++)
                {
                    bool isThisCellOnTheRightestColumn = false;
                    bool isThisCellOnTheBottomRow = false;
                    if ((j + 1) == cells.GetLength(1)) isThisCellOnTheRightestColumn = true;
                    if ((i + 1) == cells.GetLength(0)) isThisCellOnTheBottomRow = true;

                    cells[i, j] = GridCell.CreateRandomCell(j, i, cellWidthInMeters, percentOfIoTReachable, percentOfCloudReachable, percentOfFogReachable, percentOfBeingReachable, percentOfBeingLand, isThisCellOnTheRightestColumn, isThisCellOnTheBottomRow);
                }
            }


            GridOverlay gol = new GridOverlay(gridName, cells, gridWidthInMeters, gridHeightInMeters, cellWidthInMeters);

            return gol;


        }




        public static GridOverlay GenerateGridForIstanbulCity(int cellWidth, int widthOfCityInMeters)
        {
            return null; //zz
        }


        public void WriteCellLogs(SqlConnection sql)
        {
            for (int i = 0; i < Cells.GetLength(0); i++)
            {
                for (int j = 0; j < Cells.GetLength(1); j++)
                {
                    GridCell cell = this.Cells[i, j];
                    cell.CellLogWriteToDB(sql);
                }
            }
        }

    }
    public class GridCell
    {
        public int LeftX, RightX, TopY, BottomY;
        public bool CanHostFogPoint, CanHostCloudDC, CanHostIoTNode;
        public string Description;
        public readonly int CellWidth;
        public int CellIndex_X, CellIndex_Y;
        public bool CurrentlyHasCloudDC = false, CurrentlyHasFogpoint = false, CurrentlyHasIoT = false, CurrentlyHasBTS = false;
        public bool isThisCellOnTheRightestColumn, isThisCellOnTheBottomRow;

        List<CellLogInfo> CellLog = new List<CellLogInfo>();

        public bool IsNodeInThisCell(ComputerNode node)
        {
            int x = node.LocationProfile.LocationCurrent.LocationPoint.X;
            int y = node.LocationProfile.LocationCurrent.LocationPoint.Y;

            if (((x >= this.LeftX) && (x < this.RightX)) || ((this.isThisCellOnTheRightestColumn) && (x == this.RightX)))
            {
                if (((y >= this.TopY) && (y < this.BottomY)) || ((this.isThisCellOnTheBottomRow) && (y == this.BottomY)))
                    return true;
                else
                    return false;
            }
            else
                return false;
        }

        public void CellLogWriteToDB(SqlConnection sql)
        {
            CoUtils cu = new CoUtils();
            if ((sql == null)) return;
            if (sql.State != ConnectionState.Open) sql.Open();
            foreach (var cellLogItem in CellLog)
            {
                using (SqlCommand cmd = new SqlCommand("SP_CellAddnewStep", sql))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.Add("@time", SqlDbType.Int).Value = cellLogItem.Time;
                    cmd.Parameters.Add("@CellRow", SqlDbType.Int).Value = cellLogItem.CellRow;
                    cmd.Parameters.Add("@CellCol", SqlDbType.Int).Value = cellLogItem.CellCol;
                    cmd.Parameters.Add("@CountOfRequest", SqlDbType.Int).Value = cellLogItem.CountOfRequest;
                    cmd.Parameters.Add("@SumSizeOfRequests", SqlDbType.Int).Value = cellLogItem.SumSizeOfRequests;
                    cmd.Parameters.Add("@CountOfIoTNodes", SqlDbType.Int).Value = cellLogItem.CountOfIoTNodes;
                    cmd.Parameters.Add("@CountOfFogNodes", SqlDbType.Int).Value = cellLogItem.CountOfFogNodes;
                    cmd.Parameters.Add("@CountOfCloudNodes", SqlDbType.Int).Value = cellLogItem.CountOfCloudNodes;
                    cmd.Parameters.Add("@SumProcPowerIoT", SqlDbType.Int).Value = cellLogItem.SumProcPowerIoT;
                    cmd.Parameters.Add("@SumProcPowerFog", SqlDbType.Int).Value = cellLogItem.SumProcPowerFog;
                    cmd.Parameters.Add("@SumProcPowerCloud", SqlDbType.Int).Value = cellLogItem.SumProcPowerCloud;
                    cmd.Parameters.Add("@RatioOfIdleCloudHosts", SqlDbType.Float).Value = cellLogItem.RatioOfIdleCloudHosts;
                    cmd.Parameters.Add("@RatioOfIdleFogHosts", SqlDbType.Float).Value = cellLogItem.RatioOfIdleFogHosts;
                    cmd.Parameters.Add("@RatioOfIdleIoTHosts", SqlDbType.Float).Value = cellLogItem.RatioOfIdleIoTHosts;
                    cmd.Parameters.Add("@ListOfIoTNodes", SqlDbType.NVarChar).Value = cellLogItem.ListOfIoTNodes;
                    cmd.Parameters.Add("@isThisCellReachable", SqlDbType.Int).Value = cellLogItem.isThisCellReachable;

                    cmd.Parameters.Add("@Width", SqlDbType.Int).Value = this.CellWidth; ;
                    cmd.Parameters.Add("@LeftX", SqlDbType.Int).Value = this.LeftX;
                    cmd.Parameters.Add("@BottomY", SqlDbType.Int).Value = this.BottomY; ;
                    cmd.Parameters.Add("@TerrianType", SqlDbType.NVarChar).Value = TerrianTypeCodes.GetTerrianTypeAsString(this.CellTerrianType);
                    cmd.Parameters.Add("@CanIoT", SqlDbType.Int).Value = cu.BoolToInt(this.CanHostIoTNode);
                    cmd.Parameters.Add("@CanCloud", SqlDbType.Int).Value = cu.BoolToInt(this.CanHostCloudDC);
                    cmd.Parameters.Add("@CanFog", SqlDbType.Int).Value = cu.BoolToInt(this.CanHostFogPoint);

                    DAL.ExecuteNonQuery(cmd);
                    //cmd.ExecuteNonQuery();
                }
            }



        }

        public void CellLogAddnew(CellLogInfo cellLogItem)
        {
            CellLog.Add(cellLogItem);
        }

        public class CellLogInfo
        {
            public int Time, CellRow, CellCol, CountOfRequest
                     , SumSizeOfRequests, CountOfIoTNodes, CountOfFogNodes, CountOfCloudNodes
                     , SumProcPowerIoT, SumProcPowerFog, SumProcPowerCloud, isThisCellReachable;
            public float RatioOfIdleCloudHosts, RatioOfIdleFogHosts, RatioOfIdleIoTHosts;
            public string ListOfIoTNodes;

            public CellLogInfo(int Time, int CellRow, int CellCol, int CountOfRequest, int SumSizeOfRequests, int CountOfIoTNodes, int CountOfFogNodes, int CountOfCloudNodes, int SumProcPowerIoT, int SumProcPowerFog, int SumProcPowerCloud, float RatioOfIdleCloudHosts, float RatioOfIdleFogHosts, float RatioOfIdleIoTHosts, string ListOfIoTNodes, int isThisCellReachable)
            {
                this.Time = Time;
                this.CellRow = CellRow;
                this.CellCol = CellCol;
                this.CountOfRequest = CountOfRequest;
                this.SumSizeOfRequests = SumSizeOfRequests;
                this.CountOfIoTNodes = CountOfIoTNodes;
                this.CountOfFogNodes = CountOfFogNodes;
                this.CountOfCloudNodes = CountOfCloudNodes;
                this.SumProcPowerIoT = SumProcPowerIoT;
                this.SumProcPowerFog = SumProcPowerFog;
                this.SumProcPowerCloud = SumProcPowerCloud;
                this.RatioOfIdleCloudHosts = RatioOfIdleCloudHosts;
                this.RatioOfIdleFogHosts = RatioOfIdleFogHosts;
                this.RatioOfIdleIoTHosts = RatioOfIdleIoTHosts;
                this.ListOfIoTNodes = ListOfIoTNodes;
                this.isThisCellReachable = isThisCellReachable;
            }
        }

        public GridCell(int cellWidthInMeters, int terrianType, int indexInGrid_X, int indexInGrid_Y, bool canHostFogPoint, bool canHostCloudDC, bool canHostIoTNode, string description, bool isThisCellOnTheRightestColumn, bool isThisCellOnTheBottomRow)
        {
            this.CellIndex_X = indexInGrid_X;
            this.CellIndex_Y = indexInGrid_Y;
            this.CellWidth = cellWidthInMeters;
            this.LeftX = cellWidthInMeters * indexInGrid_X;
            this.RightX = this.LeftX + cellWidthInMeters;
            this.TopY = cellWidthInMeters * indexInGrid_Y;
            this.BottomY = TopY + cellWidthInMeters;
            this.CanHostCloudDC = canHostCloudDC;
            this.CanHostFogPoint = canHostFogPoint;
            this.CanHostIoTNode = canHostIoTNode;
            this.CellTerrianType = terrianType;
            description = description + TerrianTypeCodes.GetTerrianTypeAsString(terrianType);
            this.Description = description;
            this.isThisCellOnTheRightestColumn = isThisCellOnTheRightestColumn;
            this.isThisCellOnTheBottomRow = isThisCellOnTheBottomRow;
        }

        public bool isThisCellNotReachableGenerally()
        {
            if ((this.CellTerrianType == TerrianTypeCodes.Land_NotPartOfMapAndNotReachable) || (this.CellTerrianType == TerrianTypeCodes.Water_NotPartOfMapAndNotReachable))
                return false;
            else
                return true;
        }

        public static GridCell CreateRandomCell(int indexInGrid_X, int indexInGrid_Y, int cellWidth, int percentOfIoTReachable, int percentOfCloudReachable, int percentOfFogReachable, int percentOfBeingReachable, int percentOfBeingLand, bool isThisCellOnTheRightestColumn, bool isThisCellOnTheBottomRow)
        {
            CoUtils cu = new CoUtils();
            bool canHostFogPoint, canHostCloudDC, canHostIoTNode;
            int r;
            r = cu.RandomNumber(0, 100); if (r < percentOfIoTReachable) canHostIoTNode = true; else canHostIoTNode = false;
            r = cu.RandomNumber(0, 100); if (r < percentOfCloudReachable) canHostCloudDC = true; else canHostCloudDC = false;
            r = cu.RandomNumber(0, 100); if (r < percentOfFogReachable) canHostFogPoint = true; else canHostFogPoint = false;


            int terrianType = 0;
            bool isLand = false, isReachable = false;
            r = cu.RandomNumber(0, 100); if (r < percentOfBeingReachable) isLand = true;
            r = cu.RandomNumber(0, 100); if (r < percentOfBeingReachable) isReachable = true;
            if ((isLand) && (isReachable)) terrianType = TerrianTypeCodes.Land_Reachable;
            if ((isLand) && (!isReachable)) terrianType = TerrianTypeCodes.Land_NotPartOfMapAndNotReachable;
            if ((!isLand) && (isReachable)) terrianType = TerrianTypeCodes.Water_Reachable;
            if ((!isLand) && (!isReachable)) terrianType = TerrianTypeCodes.Water_NotPartOfMapAndNotReachable;
            if (!isReachable) canHostCloudDC = canHostFogPoint = canHostIoTNode = false;

            GridCell c = new GridCell(cellWidth, terrianType, indexInGrid_X, indexInGrid_Y, canHostFogPoint, canHostCloudDC, canHostIoTNode, "", isThisCellOnTheRightestColumn, isThisCellOnTheBottomRow);
            return c;
        }
        public bool IsThisCellReachableForNode(string nodeTypeAsString)
        {
            if ((this.CellTerrianType == TerrianTypeCodes.Land_NotPartOfMapAndNotReachable) || (this.CellTerrianType == TerrianTypeCodes.Water_NotPartOfMapAndNotReachable)) return false;
            switch (nodeTypeAsString)
            {
                case "iot": if (this.CanHostIoTNode) return true; else return false;
                case "fog": if (this.CanHostFogPoint) return true; else return false;
                case "cloud": if (this.CanHostCloudDC) return true; else return false;
                case "bts": return true; // bts antennas can be placed anywhere in the map (if that cell is reachable)
            }
            return false;
        }
        public int CellTerrianType; // filled from class TerrianTypeCodes

        public static class TerrianTypeCodes
        {
            public static string GetTerrianTypeAsString(int terrianType)
            {
                switch (terrianType)
                {
                    case 1: return "Land_Reachable";
                    case 2: return "Land_NotPartOfMapAndNotReachable!";
                    case 10: return "Water_Reachable";
                    case 11: return "Water_NotPartOfMapAndNotReachable";
                    default: return "UnknownTerrian!";
                }
            }
            public static int Land_Reachable = 1
                , Land_NotPartOfMapAndNotReachable = 2
                , Water_Reachable = 10
                , Water_NotPartOfMapAndNotReachable = 11;
        }


    }





    /*
    public static LocationPoint getRandomLocationPointBasedOnQuartiles(SimuCfg.Terrain terrain, int quartile)
    {

        CoUtils cu = new CoUtils();

        int x, y, z;
        switch (quartile)
        {
            case 1:
                x = cu.RandomNumber(terrain.GeoXmin, terrain.GeoXmin + (terrain.GeoXmax - terrain.GeoXmin) / 2);
                y = cu.RandomNumber(terrain.GeoYmin, terrain.GeoYmin + (terrain.GeoYmax - terrain.GeoYmin) / 2);
                z = cu.RandomNumber(terrain.GeoZmin, terrain.GeoZmax);
                break;
            case 2:
                x = cu.RandomNumber(terrain.GeoXmin + (terrain.GeoXmax - terrain.GeoXmin) / 2, terrain.GeoXmax);
                y = cu.RandomNumber(terrain.GeoYmin, terrain.GeoYmin + (terrain.GeoYmax - terrain.GeoYmin) / 2);
                z = cu.RandomNumber(terrain.GeoZmin, terrain.GeoZmax);
                break;
            case 3:
                x = cu.RandomNumber(terrain.GeoXmin, terrain.GeoXmin + (terrain.GeoXmax - terrain.GeoXmin) / 2);
                y = cu.RandomNumber(terrain.GeoYmin + (terrain.GeoYmax - terrain.GeoYmin) / 2, terrain.GeoYmax);
                z = cu.RandomNumber(terrain.GeoZmin, terrain.GeoZmax);
                break;
            case 4:
                x = cu.RandomNumber(terrain.GeoXmin + (terrain.GeoXmax - terrain.GeoXmin) / 2, terrain.GeoXmax);
                y = cu.RandomNumber(terrain.GeoYmin + (terrain.GeoYmax - terrain.GeoYmin) / 2, terrain.GeoYmax);
                z = cu.RandomNumber(terrain.GeoZmin, terrain.GeoZmax);
                break;
            default:
                x = cu.RandomNumber(terrain.GeoXmin, terrain.GeoXmax);
                y = cu.RandomNumber(terrain.GeoYmin, terrain.GeoYmax);
                z = cu.RandomNumber(terrain.GeoZmin, terrain.GeoZmax);
                break;
        }
        LocationPoint l = new LocationPoint();
        l.MandatoryInit(x, y, z);
        return l;
    }
    */



    public class SLocation
    {
        public LocationPoint LocationPoint;
        public LocationPoint TargetPoint;
        public int Time;
        public string Date;
        public float CurrentSpeed;
        public float CurrentDirectionAngleInRadians;
        public float Acceleration;

        public SLocation GetACopy()
        {
            SLocation l = new SLocation();
            LocationPoint cl = new LocationPoint();
            cl.MandatoryInit(this.LocationPoint.X, this.LocationPoint.Y, this.LocationPoint.Z);
            LocationPoint tl = new LocationPoint();
            tl.MandatoryInit(this.TargetPoint.X, this.TargetPoint.Y, this.TargetPoint.Z);
            l.MandatoryInit(this.Time, cl,this.CurrentDirectionAngleInRadians,this.Acceleration,tl);
            return l;
        }

        public void MandatoryInit(int _Time, LocationPoint currentLocation, float _CurrentDirectionAngle, float _Accelaration, LocationPoint _TargetPoint)
        {

            this.Time = _Time;
            this.LocationPoint = currentLocation;

            this.CurrentDirectionAngleInRadians = _CurrentDirectionAngle;
            this.Acceleration = _Accelaration;
            if (_TargetPoint == null)
            { _TargetPoint = currentLocation; }
            this.TargetPoint = _TargetPoint;
        }
    }





    private LocationPoint getNextPointUpponMovement_old(out float DirectionAngle)
    {
        //0.calc dist=speed
        //1.line equation from start to target
        //2. calc alpha= declination of the line   :: this is the angle
        //3. calc x=dist *cos alpha and y=dist*sin alpha
        //return new point with above x,y;

        float dist = LocationCurrent.CurrentSpeed;

        float declination;

        //Target.Y =20;         LocationCurrent.LocationPoint.Y =40;
        //Target.X =10;        LocationCurrent.LocationPoint.X =60;
        if (Math.Abs(Target.X - LocationCurrent.LocationPoint.X) != 0)
        {
            if ((Math.Abs(Target.Y - LocationCurrent.LocationPoint.Y) != 0))
            {
                declination = (float)Math.Atan((double)(Target.Y - LocationCurrent.LocationPoint.Y) / (Target.X - LocationCurrent.LocationPoint.X));
            }
            else
            {
                if (Target.X > LocationCurrent.LocationPoint.X)
                {
                    declination = 0;
                }
                else
                {
                    declination = -1 * (float)Math.PI;
                }


            }
        }
        else
        {
            int r = -1;
            if (Target.Y > LocationCurrent.LocationPoint.Y) r = 1;
            declination = r * ((float)Math.PI / 2);
        }
        double c = Math.Cos(declination), s = Math.Sin(declination);
        int xProgress = Convert.ToInt32(Math.Floor(dist * c));
        int yProgress = Convert.ToInt32(Math.Floor(dist * s));

        if ((Target.X > LocationCurrent.LocationPoint.X))
        { xProgress = (int)Math.Abs(xProgress); }
        else
        {
            xProgress = -1 * (int)Math.Abs(xProgress);
        }
        if ((Target.Y > LocationCurrent.LocationPoint.Y)) { yProgress = (int)Math.Abs(yProgress); } else { yProgress = -1 * (int)Math.Abs(yProgress); }

        int newx, newy, newz;
        newx = LocationCurrent.LocationPoint.X + xProgress;
        newy = LocationCurrent.LocationPoint.Y + yProgress;
        newz = Target.Z;




        LocationPoint lopo = new LocationPoint();
        lopo.MandatoryInit(newx, newy, newz);
        //Speed = Math.Abs(xProgress) + Math.Abs(yProgress);//as time unit is ONE then total movement in x and y is the speed
        DirectionAngle = declination;
        return lopo;
    }

}

public class LocationPoint
{
    public int X, Y, Z;
    public void MandatoryInit(int x, int y, int z)
    {
        X = x;
        Y = y;
        Z = z;
    }
}



