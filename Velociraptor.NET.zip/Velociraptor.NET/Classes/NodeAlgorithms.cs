﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

public partial class ComputerNode
{
    void ProcessDataQueues(SimuData  simuDB)
    {
        if (simuDB.SimuConfig.ClusteringAndDataTransmisionAlgorithm == SimuCfg.TransmitAlgorithms.Cell)
            ProcessDataQueues_AlgorithmCell(  simuDB);
        if (simuDB.SimuConfig.ClusteringAndDataTransmisionAlgorithm == SimuCfg.TransmitAlgorithms.Esfandiari)
            ProcessDataQueues_Algorithm_Esfandiari(  simuDB);
        else if (simuDB.SimuConfig.ClusteringAndDataTransmisionAlgorithm == SimuCfg.TransmitAlgorithms.Partovi)
            ProcessDataQueues_Algorithm_Partovi(  simuDB);
        else if ((simuDB.SimuConfig.ClusteringAndDataTransmisionAlgorithm == SimuCfg.TransmitAlgorithms.Maleki) || (simuDB.SimuConfig.ClusteringAndDataTransmisionAlgorithm == SimuCfg.TransmitAlgorithms.Hajvali))
            ProcessDataQueues_Algorithm_Esfandiari ( simuDB);


    }

    void CL_PerformCommonClusteringCycle(List<ComputerNode> NodesList, SimuData simuDB)
    {
        //update NeighborsTable
        //if 1.I have not any CH or 2.My CH is not in my NeighborsTable I need to select  another CH -->run CH selection code
        // else nothing special should be done!
        CL_UpdateNeighborsTable(NodesList, simuDB  );
        if (this.ClusterInfo_Wifi.MyAvailableClusterHeadNodeIDs.Count == 0)// non of my previously chosen cluster-heads are reachable or no cluster-head has ever chosen.
        {
            if (simuDB.SimuConfig.ClusteringAndDataTransmisionAlgorithm == SimuCfg.TransmitAlgorithms.Hajvali)
            {
                bool success = CL_PerformClusterHeadSelection_Hajvali(NodesList, simuDB);
            }
            if (simuDB.SimuConfig.ClusteringAndDataTransmisionAlgorithm == SimuCfg.TransmitAlgorithms.Esfandiari)
            {
                bool success = CL_PerformClusterHeadSelection_Esfandiari(NodesList, simuDB.SimuConfig);
            }
            if (simuDB.SimuConfig.ClusteringAndDataTransmisionAlgorithm == SimuCfg.TransmitAlgorithms.Partovi)
            {
                bool success = CL_PerformClusterHeadSelection_Partovi(NodesList, simuDB.SimuConfig);
            }

            if (simuDB.SimuConfig.ClusteringAndDataTransmisionAlgorithm == SimuCfg.TransmitAlgorithms.Maleki)
            {
                bool success = CL_PerformClusterHeadSelection_Maleki(NodesList, simuDB.SimuConfig);
            }
        }
        else // at least one cluster head from my previously chosen cluster-heads is available
        {
            //nothing to do here!
        }





    }

    class MalekiPredictionLog
    {
        public decimal p1, p2, p3;
    }

    List<MalekiPredictionLog> malekiPredictionLogs = new List<MalekiPredictionLog>();


    void Clustering_Maleki_WriteTrainingRecord(SqlConnection sqlconn, decimal[] InputRecord, decimal outputValue)
    {
        int dsIndex = 0;
        if ((sqlconn == null)) return;
        if (sqlconn.State != ConnectionState.Open) sqlconn.Open();
        using (SqlCommand cmd = new SqlCommand("SP_MalekiPrediction_WriteATrainingRecord", sqlconn))
        {
            cmd.CommandType = CommandType.StoredProcedure;
            for (int i = 0; i < InputRecord.Length; i++)
            {
                cmd.Parameters.Add("@x" + (i + 1).ToString(), SqlDbType.Decimal).Value = InputRecord[i];
            }
            cmd.Parameters.Add("@y", SqlDbType.Decimal).Value = outputValue;
            DAL.ExecuteNonQuery(cmd);
            //cmd.ExecuteNonQuery();
        }
    }

    public static void NodeScheduling_Davami_WriteTrainingRecord(SimuData simuDB, decimal[] InputRecord, decimal outputValue)
    {
        int dsIndex = 0;
        SqlConnection sqlconn = simuDB.dal.getConnectionObject();
        if ((sqlconn == null)) return;
        if (sqlconn.State != ConnectionState.Open) sqlconn.Open();
        using (SqlCommand cmd = new SqlCommand("SP_MalekiPrediction_WriteATrainingRecord", sqlconn))
        {
            cmd.CommandType = CommandType.StoredProcedure;
            for (int i = 0; i < InputRecord.Length; i++)
            {
                cmd.Parameters.Add("@x" + (i + 1).ToString(), SqlDbType.Decimal).Value = InputRecord[i];
            }
            cmd.Parameters.Add("@y", SqlDbType.Decimal).Value = outputValue;
            DAL.ExecuteNonQuery(cmd);
            //cmd.ExecuteNonQuery();
        }
    }




    void WritePredictionDataForBeingClusterHead_Maleki(SqlConnection sqlconn)
    {
        if (this.ClusterInfo_Wifi.MyInfoToShareWithOhers.DoAcceptBeingClusterHead == false) return;
        if (this.HardwareProfile.NodeTypeCode != NodeHardwareProfile.NodeTypes.IoTNode) return;
        int a = CurrentSimulationTime;
        int datalagcount = 21;
        MalekiPredictionLog l = new MalekiPredictionLog();
        CoUtils cu = new CoUtils();
        l.p1 = this.HardwareProfile.PowerSupplyProfile.EnergyCurrent / this.HardwareProfile.PowerSupplyProfile.EnergyStart;
        l.p2 = Convert.ToDecimal(this.ClusterInfo_Wifi.MyInfoToShareWithOhers.CountOfCurrentMembersAsCH / (float)25);
        l.p3 = Convert.ToDecimal(this.ClusterInfo_Wifi.MyInfoToShareWithOhers.Throghtput);

        malekiPredictionLogs.Add(l);

        if (datalagcount > malekiPredictionLogs.Count) return;

        //1. write parameters log to database
        decimal[] dataset = new decimal[1 + datalagcount * 3]; //one for energystart normalized with 100000
        int dsIndex = 0;
        for (int i = malekiPredictionLogs.Count - (datalagcount); i < malekiPredictionLogs.Count; i++)
        {
            dataset[dsIndex] = malekiPredictionLogs[i].p1;
            dsIndex++;
        }
        for (int i = malekiPredictionLogs.Count - (datalagcount); i < malekiPredictionLogs.Count; i++)
        {
            dataset[dsIndex] = malekiPredictionLogs[i].p2;
            dsIndex++;
        }
        for (int i = malekiPredictionLogs.Count - (datalagcount); i < malekiPredictionLogs.Count; i++)
        {
            dataset[dsIndex] = malekiPredictionLogs[i].p3;
            dsIndex++;
        }
        //add energy start to the prediction record
        int EnergyMax = NodeHardwareProfile.HardwarePowerSupply.GetMaxBatteryEnergyOfAllNodes();
        dataset[dsIndex] = Math.Min(this.HardwareProfile.PowerSupplyProfile.EnergyStart, EnergyMax) / (decimal)EnergyMax; //this is constant for each node


        //if we have enough data write a prediction training record for furthur use in training phase
        if (CurrentSimulationTime >= 50)
        {
            decimal outputValueForTraining = (this.HardwareProfile.PowerSupplyProfile.EnergyCurrent / this.HardwareProfile.PowerSupplyProfile.EnergyStart);
            Clustering_Maleki_WriteTrainingRecord(sqlconn, dataset, outputValueForTraining);
        }
        //---------------------------------------------------
        if (CurrentSimulationTime % 10 == 0)
        {
            //use prediction engine
            if ((sqlconn == null)) return;
            if (sqlconn.State != ConnectionState.Open) sqlconn.Open();
            using (SqlCommand cmd = new SqlCommand("SP_MalekiPrediction_WriteTobePredictedRecord", sqlconn))
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@NodeID", SqlDbType.NVarChar).Value = this.NodeID;
                cmd.Parameters.Add("@SimTime", SqlDbType.Int).Value = CurrentSimulationTime;
                for (int i = 0; i <= dsIndex; i++)
                    cmd.Parameters.Add("@x" + (i + 1).ToString(), SqlDbType.Decimal).Value = dataset[i];
                //cmd.ExecuteNonQuery();
                DAL.ExecuteNonQuery(cmd);
            }
        }
        //at the end of each 10 rounds of simulation, we use python to predict values. this happens in SSimulation.PostCycleTasks()


    }



    void Cl_UpdateClusteringInfoToShareWithOtherNodes(SimuData  simuDB)
    {
        SimuCfg simuConfig = simuDB.SimuConfig;

        this.ClusterInfo_Wifi.MyInfoToShareWithOhers.NodeID = this.NodeID;
        this.ClusterInfo_Wifi.MyInfoToShareWithOhers.isNodeAlive = this.isNodeAlive;
        this.ClusterInfo_Wifi.MyInfoToShareWithOhers.Score = -1;// this field should be calculated by te requestor nodes itself.
        this.ClusterInfo_Wifi.MyInfoToShareWithOhers.Speed = this.LocationProfile.LocationCurrent.CurrentSpeed;
        this.ClusterInfo_Wifi.MyInfoToShareWithOhers.DirectionAngle = this.LocationProfile.LocationCurrent.CurrentDirectionAngleInRadians;
        this.ClusterInfo_Wifi.MyInfoToShareWithOhers.CountOfNeighbors = this.ClusterInfo_Wifi.NeighborsTable.Neighbors.Count;
        this.ClusterInfo_Wifi.MyInfoToShareWithOhers.Availability = CalculateNodeAvailability();

        this.ClusterInfo_Wifi.MyInfoToShareWithOhers.ReputationEsfandiari = 0;
        this.ClusterInfo_Wifi.MyInfoToShareWithOhers.Score = 0;
        this.ClusterInfo_Wifi.MyInfoToShareWithOhers.MaximumMembersThreshold_Partovi = 0;

        if (simuConfig.ClusteringAndDataTransmisionAlgorithm == SimuCfg.TransmitAlgorithms.Esfandiari)
        {
            decimal t = CalculateMyReputation_Esfandiari(simuConfig, 5);
            if (t == -1m)
            {
                //error connecting to matlab engine
                t = 0.5m; //default value
            }

            this.ClusterInfo_Wifi.MyInfoToShareWithOhers.ReputationEsfandiari = t;
            this.ClusterInfo_Wifi.MyInfoToShareWithOhers.Score = -1; //esfandiari's Algorithm does not use score value in this way. each node calculates score value for all neighbor nodes. so we do not need this parameter here.
        }
        else if (simuConfig.ClusteringAndDataTransmisionAlgorithm == SimuCfg.TransmitAlgorithms.Partovi)
        {
            decimal t = CalculateMyScore_Partovi(simuDB, 5);
            if (t == -1m)
            {   //error connecting to matlab engine
                t = 0m; //default value
            }

            this.ClusterInfo_Wifi.MyInfoToShareWithOhers.Score = t;
            this.ClusterInfo_Wifi.MyInfoToShareWithOhers.MaximumMembersThreshold_Partovi = CalculateCountOfMembersThreshold_Partovi(simuConfig);

        }
        else if (simuConfig.ClusteringAndDataTransmisionAlgorithm == SimuCfg.TransmitAlgorithms.Maleki)
        {
            this.ClusterInfo_Wifi.MyInfoToShareWithOhers.Score = -1;
            this.ClusterInfo_Wifi.MyInfoToShareWithOhers.MaximumMembersThreshold_Partovi = 0;// CalculateCountOfMembersThreshold_Partovi(simuConfig);
        }





        if (this.ClusterInfo_Wifi.MyInfoToShareWithOhers.CountOfCurrentMembersAsCH > 0)
        {
            this.ClusterInfo_Wifi.MyInfoToShareWithOhers.CurrrentDurationOfBeingCH++;
            this.ClusterInfo_Wifi.MyInfoToShareWithOhers.TotalDurationOfBeingCH++;
        }
        else
        {
            this.ClusterInfo_Wifi.MyInfoToShareWithOhers.CurrrentDurationOfBeingCH = 0;
        }
        this.ClusterInfo_Wifi.MyInfoToShareWithOhers.EnergyMax = this.HardwareProfile.PowerSupplyProfile.EnergyStart;
        this.ClusterInfo_Wifi.MyInfoToShareWithOhers.EnergyRemaining = this.HardwareProfile.PowerSupplyProfile.EnergyCurrent;


        this.ClusterInfo_Wifi.MyInfoToShareWithOhers.Throghtput =
        Convert.ToDecimal(Math.Min
        (simuConfig.networkProfile.DataTransferMaxLimitForScoreCalculation_inKB
        , this.ClusterInfo_Wifi.MyInfoToShareWithOhers.DataTransfered_inKB) / (float)simuConfig.networkProfile.DataTransferMaxLimitForScoreCalculation_inKB);

        float Stability = Cl_CalculateStability();
        int maxNeighborsToCount = 20;
        float NeighborsNormalized = (float)Math.Min(maxNeighborsToCount, this.ClusterInfo_Wifi.MyInfoToShareWithOhers.CountOfNeighbors) / maxNeighborsToCount;
        this.ClusterInfo_Wifi.MyInfoToShareWithOhers.NeighborsStabilityFactorBy_TimeBeingNearFormula = (decimal)Stability;
        this.ClusterInfo_Wifi.MyInfoToShareWithOhers.CountOfNeighborsNormalized = (decimal)NeighborsNormalized;
    }


    decimal Cl_CalculateNodeScore_Maleki(NeighborInfo theNode, int MaxDistance, SimuCfg simuConfig, int retryToUseMatlabEngine)
    {
        //    return 0.1m;

        decimal DistanceNormalized = (decimal)theNode.DistanceToNeighbor / MaxDistance;
        decimal SpeedVectorsAlignment = SpeedVectorsAlignmentWithNode(theNode);


        //  return 0m;
        if (retryToUseMatlabEngine == 0)
        {
            //MessageBox.Show("Exception occured during calling matlab environment!"+Environment.NewLine);
            return 0m;
        }
        try
        {
            decimal EnergyRemainingNormalized = this.HardwareProfile.PowerSupplyProfile.EnergyCurrent / this.HardwareProfile.PowerSupplyProfile.EnergyStart;
            MLApp.MLApp matlab = getMatlabRuntime(5);
            if (matlab == null) return -1;
            matlab.Execute(@"cd C:\Velociraptor\Matlab");
            object result = null;

            matlab.Feval("FIS_Call", 1, out result,
                            (float)this.ClusterInfo_Wifi.MyInfoToShareWithOhers.Availability
                            , (float)this.ClusterInfo_Wifi.MyInfoToShareWithOhers.Throghtput
                            , (float)EnergyRemainingNormalized
                            , (float)SpeedVectorsAlignment
                            , (float)this.ClusterInfo_Wifi.MyInfoToShareWithOhers.NeighborsStabilityFactorBy_TimeBeingNearFormula
                            );


            object[] res = result as object[];
            double fis_result = (double)res[0];
            return (decimal)fis_result;
        }
        catch (Exception e)
        {
            retryToUseMatlabEngine--;
            System.Threading.Thread.Sleep(1500);
            return Cl_CalculateNodeScore_Maleki(theNode, MaxDistance, simuConfig, retryToUseMatlabEngine);
        }
    }

    float Cl_CalculateStability_Maleki()
    {
        float s = 0F;
        int SumOfBeingNearMeForAllNeighbors = 0;
        int maxTime = 30; //60 seconds
        foreach (NeighborInfo nifo in this.ClusterInfo_Wifi.NeighborsTable.Neighbors)
        {
            SumOfBeingNearMeForAllNeighbors += nifo.NeighborBeingNearMeTime;
            maxTime = Math.Max(maxTime, nifo.NeighborBeingNearMeTime);
        }
        if (SumOfBeingNearMeForAllNeighbors == 0)
        {
            return 0;
        }
        else
        {

            float AvgBeingNeighbor = (float)SumOfBeingNearMeForAllNeighbors / this.ClusterInfo_Wifi.NeighborsTable.Neighbors.Count;
            s = AvgBeingNeighbor / (float)maxTime; //normalize
            return s;
        }
    }

    bool CL_PerformClusterHeadSelection_Maleki(List<ComputerNode> NodesList, SimuCfg simConfig)
    {
        int MaximumAllowableClusterHeadMemberCount = simConfig.networkProfile.clusteringWifiProfile.MaximumAllowableClusterHeadMemberCount;

        try
        {
            if (this.ClusterInfo_Wifi.NeighborsTable.Neighbors.Count == 0) return false;
            // set score of all neighbors to -1 ... problem!!! this score is visible by other nodes; but as we run simulation in a sequential manner no problem will occur
            foreach (NeighborInfo nei in this.ClusterInfo_Wifi.NeighborsTable.Neighbors)
                nei.NodeInfo.Score = -1;
            //decide whether to remove previously chosen but not currently accessible cluster heads, or to keep them for a while.
            //if there are cluster-heads in neighborsTable, select the best,annouce it to that node, update myclusterheads list

            List<NeighborInfo> neighborWhichAreClusterHead = this.ClusterInfo_Wifi.NeighborsTable.GetListOfNeighborsWhichAreClusterHead();
            int CountOfNodes = NodesList.Count, MaxDistance = WiFi.RangeToBeConsideredAsNeighbor;

            if (neighborWhichAreClusterHead.Count != 0)
            {           //pick one if number of maximum allowed members not exceeds.
                List<NeighborInfo> NeighborClusterHeadsWhichHasFreeCapacityToHandleMoreMembers = new List<NeighborInfo>();

                foreach (NeighborInfo nifo in neighborWhichAreClusterHead)
                {
                    if ((nifo.NodeInfo.EnergyRemaining == 0) || (nifo.NodeInfo.DoAcceptBeingClusterHead == false)) continue;
                    //avoid overfilled cluster-heads
                    if (nifo.NodeInfo.CountOfCurrentMembersAsCH < MaximumAllowableClusterHeadMemberCount)
                        NeighborClusterHeadsWhichHasFreeCapacityToHandleMoreMembers.Add(nifo);
                }
                if (NeighborClusterHeadsWhichHasFreeCapacityToHandleMoreMembers.Count == 0) //if there are no eligible cluster heads around, we have no choice but to select from over-filled cluster heads
                {
                    List<NeighborInfo> NeighborNodesWhichAreNotClusterHead = new List<NeighborInfo>();
                    foreach (NeighborInfo nifo in this.ClusterInfo_Wifi.NeighborsTable.Neighbors)
                    {
                        if ((nifo.NodeInfo.CountOfCurrentMembersAsCH == 0) && (nifo.NodeInfo.DoAcceptBeingClusterHead))
                        {
                            NeighborNodesWhichAreNotClusterHead.Add(nifo);
                        }
                    }
                    //zz here we should select from other nodes
                    NeighborClusterHeadsWhichHasFreeCapacityToHandleMoreMembers = NeighborNodesWhichAreNotClusterHead;
                }

                foreach (NeighborInfo nei in NeighborClusterHeadsWhichHasFreeCapacityToHandleMoreMembers)
                {
                    nei.NodeInfo.Score = Cl_CalculateNodeScore_Maleki(nei, MaxDistance, simConfig, 5);
                }


            }
            else
            {
                //calculate score for each neighbor, pick best node  according to its score
                List<NeighborInfo> NeighborNodesWhichHasNotClusterHead = new List<NeighborInfo>();
                foreach (NeighborInfo nei in this.ClusterInfo_Wifi.NeighborsTable.Neighbors)
                    if ((nei.NodeInfo.IHaveClusterHead == false) && (nei.NodeInfo.DoAcceptBeingClusterHead)) NeighborNodesWhichHasNotClusterHead.Add(nei);
                if (NeighborNodesWhichHasNotClusterHead.Count == 0) //if no node found in the neighbors which is not attached to a cluster head, we have no other choice but to select our cluster head from all neighbors
                    NeighborNodesWhichHasNotClusterHead = this.ClusterInfo_Wifi.NeighborsTable.Neighbors;
                foreach (NeighborInfo nei in NeighborNodesWhichHasNotClusterHead)
                    nei.NodeInfo.Score = Cl_CalculateNodeScore_Maleki(nei, MaxDistance, simConfig, 5);
            }

            NeighborInfo CandidateCH = this.ClusterInfo_Wifi.NeighborsTable.FindNeighborWithMaximumScore(this);
            if (CandidateCH == null)
            {
                this.ClusterInfo_Wifi.MyInfoToShareWithOhers.ListofMyClusterHeads.Clear();
                this.ClusterInfo_Wifi.MyInfoToShareWithOhers.IHaveClusterHead = false;
            }
            else
            {
                ComputerNode MyNewClusterHead = SimuData.GetNodeByID(CandidateCH.NodeInfo.NodeID, NodesList);
                if (!MyNewClusterHead.isNodeAlive)
                {
                    this.ClusterInfo_Wifi.MyInfoToShareWithOhers.ListofMyClusterHeads.Clear();
                    this.ClusterInfo_Wifi.MyInfoToShareWithOhers.IHaveClusterHead = false;
                }
                else
                {
                    MyNewClusterHead.ClusterInfo_Wifi.AddNodeToListOfThisNodeClusterMembers(this.NodeID); //register this node as the member of the candidate cH

                    this.ClusterInfo_Wifi.MyInfoToShareWithOhers.ListofMyClusterHeads.Add(CandidateCH.NodeInfo.NodeID);
                    this.ClusterInfo_Wifi.MyInfoToShareWithOhers.IHaveClusterHead = true;
                }

            }

            return true;
        }
        catch (Exception eee)
        {

            //    MessageBox.Show(" Error in performing clustering algorithm." + Environment.NewLine + eee.ToString());
            return false;

        }
    }
    private decimal CalculateMyScore_Partovi(SimuData nodestruct, int retryToCUseMatlabEngine)
    {
        SimuCfg simuConfig = nodestruct.SimuConfig;
        //  return 0m;
        if (retryToCUseMatlabEngine == 0)
        {
            //MessageBox.Show("Exception occured during calling matlab environment!"+Environment.NewLine);
            return 0.5m;
        }
        try
        {

            MLApp.MLApp matlab = getMatlabRuntime(5);
            if (matlab == null) return -1;

            double SentDataByNode_TrimmedAndNormalized;
            SentDataByNode_TrimmedAndNormalized = Math.Min(simuConfig.networkProfile.DataTransferMaxLimitForScoreCalculation_inKB, this.ClusterInfo_Wifi.MyInfoToShareWithOhers.DataTransfered_inKB);
            SentDataByNode_TrimmedAndNormalized = SentDataByNode_TrimmedAndNormalized / simuConfig.networkProfile.DataTransferMaxLimitForScoreCalculation_inKB;
            decimal EnergyRemainingNormalized = this.HardwareProfile.PowerSupplyProfile.EnergyCurrent / this.HardwareProfile.PowerSupplyProfile.EnergyStart;

            int maxNeighborsToCount = 20;
            float NeighborsNormalized = (float)Math.Min(maxNeighborsToCount, this.ClusterInfo_Wifi.MyInfoToShareWithOhers.CountOfNeighbors) / maxNeighborsToCount;


            matlab.Execute(@"cd C:\Velociraptor\Partovi\Matlab");
            object result = null;


            matlab.Feval("FIS_Call", 1, out result,
                            (float)this.ClusterInfo_Wifi.MyInfoToShareWithOhers.Availability
                            , this.ClusterInfo_Wifi.MyInfoToShareWithOhers.NeighborsStabilityFactorBy_TimeBeingNearFormula
                            , (float)EnergyRemainingNormalized
                            , NeighborsNormalized
                            , (float)SentDataByNode_TrimmedAndNormalized); //availability,stability,battery,neighbors,traffic
                                                                           // matlab.Feval("FIS_Call", 1, out result, 0.2,0.2,0.8,0.3,0.4);  

            object[] res = result as object[];
            double fis_result = (double)res[0];
            return (decimal)fis_result;
        }
        catch (Exception e)
        {
            retryToCUseMatlabEngine--;
            System.Threading.Thread.Sleep(1500);
            return CalculateMyScore_Partovi(nodestruct, retryToCUseMatlabEngine);
        }


    }

    float Cl_CalculateStability()
    {
        float s = 0F;
        int SumOfBeingNearMeForAllNeighbors = 0;
        int maxTime = 30; //60 seconds
        foreach (NeighborInfo nifo in this.ClusterInfo_Wifi.NeighborsTable.Neighbors)
        {
            SumOfBeingNearMeForAllNeighbors += nifo.NeighborBeingNearMeTime;
            maxTime = Math.Max(maxTime, nifo.NeighborBeingNearMeTime);
        }
        if (SumOfBeingNearMeForAllNeighbors == 0) return 0;
        else
        {
            float AvgBeingNeighbor = (float)SumOfBeingNearMeForAllNeighbors / this.ClusterInfo_Wifi.NeighborsTable.Neighbors.Count;
            s = AvgBeingNeighbor / (float)maxTime; //normalize
            return s;
        }
    }


    private decimal CalculateMyReputation_Esfandiari(SimuCfg simuConfig, int retryToCUseMatlabEngine)
    {
        //  return 0m;
        if (retryToCUseMatlabEngine == 0)
        {
            //MessageBox.Show("Exception occured during calling matlab environment!"+Environment.NewLine);
            return 0m;
        }
        try
        {

            MLApp.MLApp matlab = getMatlabRuntime(5);
            if (matlab == null) return -1;

            double SentDataByNode_TrimmedAndNormalized;
            SentDataByNode_TrimmedAndNormalized = Math.Min(simuConfig.networkProfile.DataTransferMaxLimitForScoreCalculation_inKB, this.ClusterInfo_Wifi.MyInfoToShareWithOhers.DataTransfered_inKB);
            SentDataByNode_TrimmedAndNormalized = SentDataByNode_TrimmedAndNormalized / simuConfig.networkProfile.DataTransferMaxLimitForScoreCalculation_inKB;
            decimal EnergyRemainingNormalized = this.HardwareProfile.PowerSupplyProfile.EnergyCurrent / this.HardwareProfile.PowerSupplyProfile.EnergyStart;
            // Change to the directory where the function is located 
            matlab.Execute(@"cd C:\Velociraptor\2Esfandiari\Matlab");

            // Define the output 
            object result = null;

            // Call the MATLAB function myfunc
            matlab.Feval("FIS_Call", 1, out result, (float)EnergyRemainingNormalized, (float)SentDataByNode_TrimmedAndNormalized, (float)this.ClusterInfo_Wifi.MyInfoToShareWithOhers.Availability); //(energy, data, availability)


            //matlab.Feval("FIS_Call", 1, out result, 0.4,0.4,0.4);


            // Display result 
            object[] res = result as object[];

            Console.WriteLine(res[0]);
            //Console.WriteLine(res[1]);
            // Get user input to terminate program


            double fis_result = (double)res[0];
            return (decimal)fis_result;
        }
        catch (Exception e)
        {
            retryToCUseMatlabEngine--;
            System.Threading.Thread.Sleep(4000);
            return CalculateMyReputation_Esfandiari(simuConfig, retryToCUseMatlabEngine);
        }


    }

    private void ProcessDataQueues_AlgorithmCell(SimuData   simuDB)
    {
        //age datatransfered field to adjust it with more recent network related activities
        this.ClusterInfo_Wifi.MyInfoToShareWithOhers.DataTransfered_inKB = Math.Max(0, this.ClusterInfo_Wifi.MyInfoToShareWithOhers.DataTransfered_inKB - simuDB.SimuConfig.networkProfile.DataTransferAging_inKB);
        CheckInQueuesForPacketsWithTargetOfThisNode(  simuDB);
        DataPacketsQueues.SingleDataPacketQueue NextQueueForOutgoingPackets = new DataPacketsQueues.SingleDataPacketQueue();
        int sendingmediumCode;

        sendingmediumCode = Communication.CommunicationMediumCodes.Cellular3G;
        //first in-node generated packets 
        int countOfPacketsTobeSent = this.DataPacketQueueGenerated.Queue.Count;
        while (this.DataPacketQueueGenerated.Queue.Count > 0)
        {
            DataPacket packet = this.DataPacketQueueGenerated.Queue[0]; //the packets in this list will be removed one by one, so index ZERO is not pointing to a fixed packet
            NextQueueForOutgoingPackets.Queue.Add(packet);
            this.DataPacketQueueGenerated.Queue.RemoveAt(0);
        }
        //second, move cellular out queue packets to NextQueueForOutgoingPackets

        while (this.DataPacketQueues_Cellular3G.QueOut.Queue.Count > 0)
        {
            DataPacket packet = this.DataPacketQueues_Cellular3G.QueOut.Queue[0]; //the packets in this list will be removed one by one, so index ZERO is not pointing to a fixed packet
            NextQueueForOutgoingPackets.Queue.Add(packet);
            this.DataPacketQueues_Cellular3G.QueOut.Queue.RemoveAt(0);
        }

        //third, move Wifi out queue to packets NextQueueForOutgoingPackets
        while (this.DataPacketQueues_Wifi.QueOut.Queue.Count > 0)
        {
            DataPacket packet = this.DataPacketQueues_Wifi.QueOut.Queue[0]; //the packets in this list will be removed one by one, so index ZERO is not pointing to a fixed packet
            NextQueueForOutgoingPackets.Queue.Add(packet);
            this.DataPacketQueues_Wifi.QueOut.Queue.RemoveAt(0);
        }

        //finally, sending packets from NextQueueForOutgoingPackets
        while (NextQueueForOutgoingPackets.Queue.Count > 0)
        {
            DataPacket packet = NextQueueForOutgoingPackets.Queue[0]; //the packets in this list will be removed one by one, so index ZERO is not pointing to a fixed packet
            ComputerNode FinalTargetNode = SimuData.GetNodeByID(packet.TargetNodeID, simuDB.Nodes);
            ComputerNode CellularInfra = simuDB.Cellular3GInfrastructureAbstractNode;
            Communication.TransmitPacket(CurrentSimulationTime,
                packet.Priority,
                NextQueueForOutgoingPackets,
                CellularInfra.DataPacketQueues_Cellular3G.QueIn
                , simuDB
                , this
                , packet
                , CellularInfra
                , "", Communication.CommunicationMediumCodes.Cellular3G
                , simuDB);

            if (countOfPacketsTobeSent < 0) _thisStepActionForPackets += countOfPacketsTobeSent.ToString() + " packets transfered";

        }
    }

    private void ProcessDataQueues_Algorithm_Esfandiari(SimuData   simuDB)
    {
        //age datatransfered field to adjust it with more recent network related activities
        this.ClusterInfo_Wifi.MyInfoToShareWithOhers.DataTransfered_inKB = Math.Max(0, this.ClusterInfo_Wifi.MyInfoToShareWithOhers.DataTransfered_inKB - simuDB.SimuConfig.networkProfile.DataTransferAging_inKB);

        CheckInQueuesForPacketsWithTargetOfThisNode(   simuDB);


        //Note: 
        // if there is a wifi ch available, we try to send ALL outgoing packets  through wifi to the cluster-head (including packets in generatedpacketsqueue in-queue of wifi and cellular)
        // else (no available wifi cluster-head) ALL out-going packets should be send through cellular (including packets in in-queue of wifi and cellular)
        //      except for packets of wifi outgoing queue which their target node is an immediate wifi neighbor; these packets should be sent through wifi
        DataPacketsQueues.SingleDataPacketQueue NextQueueForOutgoingPackets = new DataPacketsQueues.SingleDataPacketQueue();
        int sendingmediumCode;

        if (ClusterInfo_Wifi.MyAvailableClusterHeadNodeIDs.Count > 0)
        {
            sendingmediumCode = Communication.CommunicationMediumCodes.WiFi;
        }
        else
        {
            sendingmediumCode = Communication.CommunicationMediumCodes.Cellular3G;
        }

        //first in-node generated packets 
        int countOfPacketsTobeSent = this.DataPacketQueueGenerated.Queue.Count;
        while (this.DataPacketQueueGenerated.Queue.Count > 0)
        {
            DataPacket packet = this.DataPacketQueueGenerated.Queue[0]; //the packets in this list will be removed one by one, so index ZERO is not pointing to a fixed packet
            NextQueueForOutgoingPackets.Queue.Add(packet);
            this.DataPacketQueueGenerated.Queue.RemoveAt(0);
        }




        //second, move cellular out queue packets to NextQueueForOutgoingPackets

        while (this.DataPacketQueues_Cellular3G.QueOut.Queue.Count > 0)
        {
            DataPacket packet = this.DataPacketQueues_Cellular3G.QueOut.Queue[0]; //the packets in this list will be removed one by one, so index ZERO is not pointing to a fixed packet
            NextQueueForOutgoingPackets.Queue.Add(packet);
            this.DataPacketQueues_Cellular3G.QueOut.Queue.RemoveAt(0);
        }

        //third, move Wifi out queue to packets NextQueueForOutgoingPackets
        while (this.DataPacketQueues_Wifi.QueOut.Queue.Count > 0)
        {
            DataPacket packet = this.DataPacketQueues_Wifi.QueOut.Queue[0]; //the packets in this list will be removed one by one, so index ZERO is not pointing to a fixed packet
            NextQueueForOutgoingPackets.Queue.Add(packet);
            this.DataPacketQueues_Wifi.QueOut.Queue.RemoveAt(0);
        }

        //finally, sending packets from NextQueueForOutgoingPackets
        while (NextQueueForOutgoingPackets.Queue.Count > 0)
        {
            DataPacket packet = NextQueueForOutgoingPackets.Queue[0]; //the packets in this list will be removed one by one, so index ZERO is not pointing to a fixed packet
            ComputerNode FinalTargetNode = SimuData.GetNodeByID(packet.TargetNodeID, simuDB.Nodes);

            bool x = this.ClusterInfo_Wifi.NeighborsTable.isNeighbor(packet.TargetNodeID);
            if (x)
            {
                //packet can be sent directly to the neighbor node (it is in neighbor range)
                this.ClusterInfo_Wifi.MyInfoToShareWithOhers.DataTransfered_inKB += packet.SizeInKB;
                Communication.TransmitPacket(CurrentSimulationTime, packet.Priority, NextQueueForOutgoingPackets, FinalTargetNode.DataPacketQueues_Wifi.QueIn, simuDB, this, packet, FinalTargetNode, "", Communication.CommunicationMediumCodes.WiFi, simuDB);
            }
            else
            {
                bool shouldBeSentByCellular = false;
                //packet target is not within wifi direct range, so it should be sent to cluster-head (if there is any) or to cellular infrastructure
                if (ClusterInfo_Wifi.MyAvailableClusterHeadNodeIDs.Count > 0)
                {
                    //send the packet to my cluster-head
                    ComputerNode TargetClusterHead = SimuData.GetNodeByID(ClusterInfo_Wifi.MyAvailableClusterHeadNodeIDs[0], simuDB.Nodes);

                    if (!(packet.Trace.IndexOf(TargetClusterHead.NodeID) >= 0)) // to prevent wicked circles for packets
                    {
                        this.ClusterInfo_Wifi.MyInfoToShareWithOhers.DataTransfered_inKB += packet.SizeInKB;
                        Communication.TransmitPacket(CurrentSimulationTime,
                                            packet.Priority,
                                            NextQueueForOutgoingPackets,
                                            TargetClusterHead.DataPacketQueues_Wifi.QueIn
                                            , simuDB
                                            , this
                                            , packet
                                            , TargetClusterHead
                                            , "", Communication.CommunicationMediumCodes.WiFi
                                            , simuDB);
                        if (countOfPacketsTobeSent < 0) _thisStepActionForPackets += countOfPacketsTobeSent.ToString() + " packets transfered";

                    }
                    else
                    {
                        shouldBeSentByCellular = true;
                    }


                }
                else { shouldBeSentByCellular = true; }
                if (shouldBeSentByCellular)
                {
                    //packet should be sent by using cellular
                    ComputerNode CellularInfra = simuDB.Cellular3GInfrastructureAbstractNode;
                    Communication.TransmitPacket(CurrentSimulationTime,
                        packet.Priority,
                        NextQueueForOutgoingPackets,
                        CellularInfra.DataPacketQueues_Cellular3G.QueIn
                        , simuDB
                        , this
                        , packet
                        , CellularInfra
                        , "", Communication.CommunicationMediumCodes.Cellular3G
                        , simuDB);

                    if (countOfPacketsTobeSent < 0) _thisStepActionForPackets += countOfPacketsTobeSent.ToString() + " packets transfered";
                }

            }



        }





    }

    private void ProcessDataQueues_Algorithm_Partovi(SimuData   simuDB)
    {
        //age datatransfered field to adjust it with more recent network related activities
        this.ClusterInfo_Wifi.MyInfoToShareWithOhers.DataTransfered_inKB = Math.Max(0, this.ClusterInfo_Wifi.MyInfoToShareWithOhers.DataTransfered_inKB - simuDB.SimuConfig.networkProfile.DataTransferAging_inKB);

        CheckInQueuesForPacketsWithTargetOfThisNode(   simuDB);


        //Note: 
        // if there is a wifi ch available, we try to send ALL outgoing packets  through wifi to the cluster-head (including packets in generatedpacketsqueue in-queue of wifi and cellular)
        // else (no available wifi cluster-head) ALL out-going packets should be send through cellular (including packets in in-queue of wifi and cellular)
        //      except for packets of wifi outgoing queue which their target node is an immediate wifi neighbor; these packets should be sent through wifi
        DataPacketsQueues.SingleDataPacketQueue NextQueueForOutgoingPackets = new DataPacketsQueues.SingleDataPacketQueue();
        int sendingmediumCode;

        if (ClusterInfo_Wifi.MyAvailableClusterHeadNodeIDs.Count > 0)
        {
            sendingmediumCode = Communication.CommunicationMediumCodes.WiFi;
        }
        else
        {
            sendingmediumCode = Communication.CommunicationMediumCodes.Cellular3G;
        }

        //first in-node generated packets 
        int countOfPacketsTobeSent = this.DataPacketQueueGenerated.Queue.Count;
        while (this.DataPacketQueueGenerated.Queue.Count > 0)
        {
            DataPacket packet = this.DataPacketQueueGenerated.Queue[0]; //the packets in this list will be removed one by one, so index ZERO is not pointing to a fixed packet
            NextQueueForOutgoingPackets.Queue.Add(packet);
            this.DataPacketQueueGenerated.Queue.RemoveAt(0);
        }




        //second, move cellular out queue packets to NextQueueForOutgoingPackets

        while (this.DataPacketQueues_Cellular3G.QueOut.Queue.Count > 0)
        {
            DataPacket packet = this.DataPacketQueues_Cellular3G.QueOut.Queue[0]; //the packets in this list will be removed one by one, so index ZERO is not pointing to a fixed packet
            NextQueueForOutgoingPackets.Queue.Add(packet);
            this.DataPacketQueues_Cellular3G.QueOut.Queue.RemoveAt(0);
        }

        //third, move Wifi out queue to packets NextQueueForOutgoingPackets
        while (this.DataPacketQueues_Wifi.QueOut.Queue.Count > 0)
        {
            DataPacket packet = this.DataPacketQueues_Wifi.QueOut.Queue[0]; //the packets in this list will be removed one by one, so index ZERO is not pointing to a fixed packet
            NextQueueForOutgoingPackets.Queue.Add(packet);
            this.DataPacketQueues_Wifi.QueOut.Queue.RemoveAt(0);
        }

        //finally, sending packets from NextQueueForOutgoingPackets
        while (NextQueueForOutgoingPackets.Queue.Count > 0)
        {
            DataPacket packet = NextQueueForOutgoingPackets.Queue[0]; //the packets in this list will be removed one by one, so index ZERO is not pointing to a fixed packet
            ComputerNode FinalTargetNode = SimuData.GetNodeByID(packet.TargetNodeID, simuDB.Nodes);

            bool x = this.ClusterInfo_Wifi.NeighborsTable.isNeighbor(packet.TargetNodeID);
            if (x)
            {
                //packet can be sent directly to the neighbor node (it is in neighbor range)
                this.ClusterInfo_Wifi.MyInfoToShareWithOhers.DataTransfered_inKB += packet.SizeInKB;
                Communication.TransmitPacket(CurrentSimulationTime, packet.Priority, NextQueueForOutgoingPackets, FinalTargetNode.DataPacketQueues_Wifi.QueIn, simuDB, this, packet, FinalTargetNode, "", Communication.CommunicationMediumCodes.WiFi, simuDB);
            }
            else
            {
                bool shouldBeSentByCellular = false;
                //packet target is not within wifi direct range, so it should be sent to cluster-head (if there is any) or to cellular infrastructure
                if (ClusterInfo_Wifi.MyAvailableClusterHeadNodeIDs.Count > 0)
                {
                    //send the packet to my cluster-head
                    ComputerNode TargetClusterHead = SimuData.GetNodeByID(ClusterInfo_Wifi.MyAvailableClusterHeadNodeIDs[0], simuDB.Nodes);

                    if (!(packet.Trace.IndexOf(TargetClusterHead.NodeID) >= 0)) // to prevent wicked circles for packets
                    {
                        this.ClusterInfo_Wifi.MyInfoToShareWithOhers.DataTransfered_inKB += packet.SizeInKB;
                        Communication.TransmitPacket(CurrentSimulationTime,
                                            packet.Priority,
                                            NextQueueForOutgoingPackets,
                                            TargetClusterHead.DataPacketQueues_Wifi.QueIn
                                            , simuDB
                                            , this
                                            , packet
                                            , TargetClusterHead
                                            , "", Communication.CommunicationMediumCodes.WiFi
                                            , simuDB);
                        if (countOfPacketsTobeSent < 0) _thisStepActionForPackets += countOfPacketsTobeSent.ToString() + " packets transfered";

                    }
                    else
                    {
                        shouldBeSentByCellular = true;
                    }


                }
                else { shouldBeSentByCellular = true; }
                if (shouldBeSentByCellular)
                {
                    //packet should be sent by using cellular
                    ComputerNode CellularInfra = simuDB.Cellular3GInfrastructureAbstractNode;
                    Communication.TransmitPacket(CurrentSimulationTime,
                        packet.Priority,
                        NextQueueForOutgoingPackets,
                        CellularInfra.DataPacketQueues_Cellular3G.QueIn
                        , simuDB
                        , this
                        , packet
                        , CellularInfra
                        , "", Communication.CommunicationMediumCodes.Cellular3G
                        , simuDB);

                    if (countOfPacketsTobeSent < 0) _thisStepActionForPackets += countOfPacketsTobeSent.ToString() + " packets transfered";
                }

            }



        }





    }




    bool CL_PerformClusterHeadSelection_Partovi(List<ComputerNode> NodesList, SimuCfg simConfig)
    {
        try
        {
            if (this.ClusterInfo_Wifi.NeighborsTable.Neighbors.Count == 0) return false;
            // set score of all neighbors to -1 ... problem!!! this score is visible by other nodes; but as we run simulation in a sequential manner no problem will occur
            foreach (NeighborInfo nei in this.ClusterInfo_Wifi.NeighborsTable.Neighbors)
            {
                nei.NodeInfo.Score = -1;
            }
            //decide whether to remove previously chosen but not currently accessible cluster heads, or to keep them for a while.
            //if there are cluster-heads in neighborsTable, select the best,annouce it to that node, update myclusterheads list

            List<NeighborInfo> neighborWhichAreClusterHead = this.ClusterInfo_Wifi.NeighborsTable.GetListOfNeighborsWhichAreClusterHead();
            int CountOfNodes = NodesList.Count, MaxDistance = WiFi.RangeToBeConsideredAsNeighbor;

            if (neighborWhichAreClusterHead.Count != 0)
            {           //pick one if number of maximum allowed members not exceeds.
                List<NeighborInfo> NeighborClusterHeadsWhichHasFreeCapacityToHandleMoreMembers = new List<NeighborInfo>();

                foreach (NeighborInfo nifo in neighborWhichAreClusterHead)
                {
                    if (!nifo.NodeInfo.isNodeAlive) continue;
                    //avoid overfilled cluster-heads
                    if (nifo.NodeInfo.CountOfCurrentMembersAsCH < nifo.NodeInfo.MaximumMembersThreshold_Partovi)
                    {

                        NeighborClusterHeadsWhichHasFreeCapacityToHandleMoreMembers.Add(nifo);
                    }
                }
                if (NeighborClusterHeadsWhichHasFreeCapacityToHandleMoreMembers.Count == 0) //if there are no eligible cluster heads around, we have no choice but to select from over-filled cluster heads
                {
                    List<NeighborInfo> NeighborNodesWhichAreNotClusterHead = new List<NeighborInfo>();
                    foreach (NeighborInfo nifo in this.ClusterInfo_Wifi.NeighborsTable.Neighbors)
                    {
                        if (nifo.NodeInfo.CountOfCurrentMembersAsCH == 0)
                        {
                            NeighborNodesWhichAreNotClusterHead.Add(nifo);
                        }
                    }
                    //zz here we should select from other nodes
                    NeighborClusterHeadsWhichHasFreeCapacityToHandleMoreMembers = NeighborNodesWhichAreNotClusterHead;
                }

                foreach (NeighborInfo nei in NeighborClusterHeadsWhichHasFreeCapacityToHandleMoreMembers)
                {
                    nei.NodeInfo.Score = Cl_GetNodeScore_Partovi(nei, CountOfNodes, MaxDistance);
                }


            }
            else
            {
                //calculate score for each neighbor, pick best node  according to its score
                List<NeighborInfo> NeighborNodesWhichHasNotClusterHead = new List<NeighborInfo>();
                foreach (NeighborInfo nei in this.ClusterInfo_Wifi.NeighborsTable.Neighbors)
                {
                    if (nei.NodeInfo.IHaveClusterHead == false) NeighborNodesWhichHasNotClusterHead.Add(nei);

                }
                if (NeighborNodesWhichHasNotClusterHead.Count == 0) //if no node found in the neighbors which is not attached to a cluster head, we have no other choice but to select our cluster head from all neighbors
                {
                    NeighborNodesWhichHasNotClusterHead = this.ClusterInfo_Wifi.NeighborsTable.Neighbors;
                }

                foreach (NeighborInfo nei in NeighborNodesWhichHasNotClusterHead)
                {
                    nei.NodeInfo.Score = Cl_GetNodeScore_Partovi(nei, CountOfNodes, MaxDistance);
                }
            }

            NeighborInfo CandidateCH = this.ClusterInfo_Wifi.NeighborsTable.FindNeighborWithMaximumScore(this);
            if (CandidateCH == null)
            {
                this.ClusterInfo_Wifi.MyInfoToShareWithOhers.ListofMyClusterHeads.Clear();
                this.ClusterInfo_Wifi.MyInfoToShareWithOhers.IHaveClusterHead = false;
            }
            else
            {
                ComputerNode MyNewClusterHead = SimuData.GetNodeByID(CandidateCH.NodeInfo.NodeID, NodesList);
                if (!MyNewClusterHead.isNodeAlive)
                {
                    this.ClusterInfo_Wifi.MyInfoToShareWithOhers.ListofMyClusterHeads.Clear();
                    this.ClusterInfo_Wifi.MyInfoToShareWithOhers.IHaveClusterHead = false;
                }
                else
                {
                    MyNewClusterHead.ClusterInfo_Wifi.AddNodeToListOfThisNodeClusterMembers(this.NodeID); //register this node as the member of the candidate cH

                    this.ClusterInfo_Wifi.MyInfoToShareWithOhers.ListofMyClusterHeads.Add(CandidateCH.NodeInfo.NodeID);
                    this.ClusterInfo_Wifi.MyInfoToShareWithOhers.IHaveClusterHead = true;
                }

            }

            return true;
        }
        catch (Exception eee)
        {

            //    MessageBox.Show(" Error in performing clustering algorithm." + Environment.NewLine + eee.ToString());
            return false;

        }
    }


    decimal Cl_CalculateScore_Esfandiari(NeighborInfo theNode, int CountOfAllNodes, int MaxDistance)
    {
        //score= w1*Distance + w2*SpeedVEctorsAlignment+ w3*CountOfNeighbors +w4*Reputation
        decimal w1 = 0.25m, w2 = 0.25m, w3 = 0.1m, w4 = 0.4m;
        decimal DistanceNormalized = (decimal)theNode.DistanceToNeighbor / MaxDistance;
        decimal CountOfNeighborsNormalized = Math.Min(1, (decimal)theNode.NodeInfo.CountOfNeighbors / CountOfAllNodes);
        decimal Reputation = theNode.NodeInfo.ReputationEsfandiari;
        decimal SpeedVectorsAlignment = SpeedVectorsAlignmentWithNode(theNode);

        decimal ScoreFor_theNode = w4 * Reputation - w1 * DistanceNormalized - w2 * SpeedVectorsAlignment - w3 * CountOfNeighborsNormalized;
        return ScoreFor_theNode;
    }

    decimal Cl_GetNodeScore_Partovi(NeighborInfo theNode, int CountOfAllNodes, int MaxDistance)
    {
        return theNode.NodeInfo.Score;// ScoreFor_theNode;
    }


    int CalculateCountOfMembersThreshold_Partovi(SimuCfg simuconfig)
    {
        //setting allowed number of members dynamically
        int MAM = simuconfig.networkProfile.clusteringWifiProfile.MaximumAllowableClusterHeadMemberCount;
        int NCH = this.ClusterInfo_Wifi.MyAvailableClusterHeadNodeIDs.Count;
        double NNCH = ((double)Math.Min(MAM, NCH)) / MAM;

        int MaxIntervalTime = simuconfig.simulationMaxStep;
        double Ec = (double)this.HardwareProfile.PowerSupplyProfile.EnergyCurrent;
        double Es = (double)this.HardwareProfile.PowerSupplyProfile.EnergyStart;
        double BatteryRemainingPercent = 100 * Ec / Es;
        int EffectiveTime = Math.Min(MaxIntervalTime, CurrentSimulationTime) + 1;

        double xF = 0, yF = 0, VLen = 0, angleDegree = 0, angleRadian = 0;

        CoUtils cu = new CoUtils();
        cu.GeometeryCalculateDeclinationForTwoGivenPoints(0, EffectiveTime, 100, BatteryRemainingPercent, out xF, out yF, out VLen, out angleDegree, out angleRadian);
        double NA = (Math.Abs(angleDegree) / 90); //Normalized Angle
        double EDE = NA;// * BatteryUsagePercent;  //EDE is Energy Drop Effect

        double DF = 0.3 * NNCH + 0.7 * EDE; // DF is Decreasing Factor
        int NT = Convert.ToInt32(Math.Floor(MAM * (1 - DF)));
        if (NT < 15)
        {
            NT = NT;
        }
        return NT;
    }

    bool CL_PerformClusterHeadSelection_Hajvali(List<ComputerNode> NodesList, SimuData nodeStructure)
    {
        try
        {

            if (this.ClusterInfo_Wifi.NeighborsTable.Neighbors.Count == 0) return false;
            // set score of all neighbors to -1 ... problem!!! this score is visible by other nodes; but as we run simulation in a sequential manner no problem will occur
            foreach (NeighborInfo nei in this.ClusterInfo_Wifi.NeighborsTable.Neighbors)
            {
                nei.NodeInfo.Score = -1;
            }
            int MaximumAllowableClusterHeadMemberCount = nodeStructure.SimuConfig.networkProfile.clusteringWifiProfile.MaximumAllowableClusterHeadMemberCount;
            //decide whether to remove previously chosen but not currently accessible cluster heads, or to keep them for a while.
            //if there are cluster-heads in neighborsTable, select the best,annouce it to that node, update myclusterheads list

            List<NeighborInfo> NeighborFogClusterHeads = this.ClusterInfo_Wifi.NeighborsTable.GetListOfNeighborsWithSpecificType(nodeStructure, NodeInfoForClustering.NodeTypes_Fog, true);
            int CountOfNodes = NodesList.Count, MaxDistance = WiFi.RangeToBeConsideredAsNeighbor;

            if (NeighborFogClusterHeads.Count != 0)
            {
                List<NeighborInfo> NeighborClusterHeadsWhichHasFreeCapacityToHandleMoreMembers = new List<NeighborInfo>();

                foreach (NeighborInfo nifo in NeighborFogClusterHeads)
                {
                    if (!nifo.NodeInfo.isNodeAlive) continue;
                    //avoid overfilled cluster-heads
                    if (nifo.NodeInfo.CountOfCurrentMembersAsCH <= MaximumAllowableClusterHeadMemberCount)
                    {
                        NeighborClusterHeadsWhichHasFreeCapacityToHandleMoreMembers.Add(nifo);
                    }
                }
                if (NeighborClusterHeadsWhichHasFreeCapacityToHandleMoreMembers.Count == 0) //if there are no eligible cluster heads around, we have no choice but to select from over-filled cluster heads
                {
                    NeighborClusterHeadsWhichHasFreeCapacityToHandleMoreMembers = NeighborFogClusterHeads;
                }

                foreach (NeighborInfo nei in NeighborClusterHeadsWhichHasFreeCapacityToHandleMoreMembers)
                {
                    nei.NodeInfo.Score = Cl_CalculateScore_Hajvali(nodeStructure, nei, CountOfNodes, MaxDistance);
                }
            }
            else
            {
                //calculate score for each neighbor, pick best node  according to its score
                List<NeighborInfo> Neighbor_IoT_Nodes = this.ClusterInfo_Wifi.NeighborsTable.GetListOfNeighborsWithSpecificType(nodeStructure, NodeInfoForClustering.NodeTypes_IoT, false);
                List<NeighborInfo> Neighbor_IoT_ClusterHeads = new List<NeighborInfo>();
                foreach (NeighborInfo nei in Neighbor_IoT_Nodes)
                {
                    if (nei.NodeInfo.IHaveClusterHead == false) Neighbor_IoT_ClusterHeads.Add(nei);
                }
                List<NeighborInfo> Neighbor_IoT_NodesToSelectAsCH = new List<NeighborInfo>();
                if (Neighbor_IoT_ClusterHeads.Count == 0) //if no node found in the neighbors which is not attached to a cluster head, we have no other choice but to select our cluster head from all neighbors
                {
                    Neighbor_IoT_NodesToSelectAsCH = Neighbor_IoT_Nodes;
                }
                else
                {

                    Neighbor_IoT_NodesToSelectAsCH = Neighbor_IoT_ClusterHeads;
                }


                foreach (NeighborInfo nei in Neighbor_IoT_NodesToSelectAsCH)
                {
                    nei.NodeInfo.Score = Cl_CalculateScore_Hajvali(nodeStructure, nei, CountOfNodes, MaxDistance);
                }
            }

            NeighborInfo CandidateCH = this.ClusterInfo_Wifi.NeighborsTable.FindNeighborWithMaximumScore(this);
            if (CandidateCH == null)
            {
                this.ClusterInfo_Wifi.MyInfoToShareWithOhers.ListofMyClusterHeads.Clear();
                this.ClusterInfo_Wifi.MyInfoToShareWithOhers.IHaveClusterHead = false;
            }
            else
            {
                ComputerNode MyNewClusterHead = SimuData.GetNodeByID(CandidateCH.NodeInfo.NodeID, nodeStructure.Nodes);
                if (!MyNewClusterHead.isNodeAlive)
                {
                    this.ClusterInfo_Wifi.MyInfoToShareWithOhers.ListofMyClusterHeads.Clear();
                    this.ClusterInfo_Wifi.MyInfoToShareWithOhers.IHaveClusterHead = false;
                }
                else
                {
                    MyNewClusterHead.ClusterInfo_Wifi.AddNodeToListOfThisNodeClusterMembers(this.NodeID); //register this node as the member of the candidate cH

                    this.ClusterInfo_Wifi.MyInfoToShareWithOhers.ListofMyClusterHeads.Add(CandidateCH.NodeInfo.NodeID);
                    this.ClusterInfo_Wifi.MyInfoToShareWithOhers.IHaveClusterHead = true;
                }
            }


            return true;
        }
        catch (Exception eee)
        {

            //    MessageBox.Show(" Error in performing clustering algorithm." + Environment.NewLine + eee.ToString());
            return false;

        }


    }

    decimal Cl_CalculateScore_Hajvali(SimuData nodeStructure, NeighborInfo theNode, int CountOfAllNodes, int MaxDistance)
    {
        //AvgMIPS:Avg processing power
        //Energy: Remaining Energy
        
        //Stability: stability of being near other nodes
        //CountOfAvailableResources: Count Of Available Resources

        ComputerNode subjectNode = SimuData.GetNodeByID(theNode.NodeInfo.NodeID, nodeStructure.Nodes);
        List<ComputerNode> TargetNodes = null;
        if (subjectNode.InFog_Fixed_OwnerFogPoint != null)
            TargetNodes = subjectNode.InFog_Fixed_OwnerFogPoint.MemberNodes;
        else if (subjectNode.InCloud_Fixed_OwnerCluster != null)
            TargetNodes = subjectNode.InCloud_Fixed_OwnerCluster.MemberNodes;
        decimal AvgMIPS = 0;
        int CountOfAvailableResources = 0;
        if (TargetNodes != null)
        {
            decimal MIPS = 0;
            foreach (var Node in TargetNodes) MIPS += Node.HardwareProfile.ComputerHardwareProfile.CPUProfile.CPUCurrentMIPS_hardware;
            AvgMIPS = MIPS / TargetNodes.Count;
            CountOfAvailableResources = TargetNodes.Count;
        }
        else
        {
            AvgMIPS = subjectNode.HardwareProfile.ComputerHardwareProfile.CPUProfile.CPUCurrentMIPS_hardware;
            CountOfAvailableResources = 0;
        }

        decimal Stability = subjectNode.ClusterInfo_Wifi.MyInfoToShareWithOhers.NeighborsStabilityFactorBy_TimeBeingNearFormula;
        decimal Energy= subjectNode.HardwareProfile.PowerSupplyProfile.EnergyCurrent / subjectNode.HardwareProfile.PowerSupplyProfile.EnergyStart;
        //AvgMIPS
        //CountOfAvailableResources
        
        decimal N_CountOfAvailableResources = (decimal)CountOfAvailableResources / (SimuData.FindBiggestCluster(nodeStructure.Clusters)).MemberNodes.Count;
        decimal N_AvgMIPS = (decimal)AvgMIPS / (SimuData.FindNodeWithMaxComputationPower(nodeStructure.Nodes)).HardwareProfile.ComputerHardwareProfile.CPUProfile.CPUCurrentMIPS_hardware;


        //score= w1*Distance + w2*SpeedVEctorsAlignment+ w3*CountOfNeighbors +w4*Reputation
        decimal w1 = 0.25m, w2 = 0.25m, w3 = 0.25m, w4 = 0.25m;

        decimal ScoreFor_theNode;
        ScoreFor_theNode = w4 * Stability - w1 * Energy - w2 * N_AvgMIPS - w3 * N_CountOfAvailableResources;
        /*
    decimal DistanceNormalized = (decimal)theNode.DistanceToNeighbor / MaxDistance;
    decimal CountOfNeighborsNormalized = Math.Min(1, (decimal)theNode.NodeInfo.CountOfNeighbors / CountOfAllNodes);
    decimal Reputation = theNode.NodeInfo.ReputationEsfandiari;
    decimal SpeedVectorsAlignment = SpeedVectorsAlignmentWithNode(theNode);

      ScoreFor_theNode = w4 * Reputation - w1 * DistanceNormalized - w2 * SpeedVectorsAlignment - w3 * CountOfNeighborsNormalized;
    */
        return ScoreFor_theNode;
    }
    bool CL_PerformClusterHeadSelection_Esfandiari(List<ComputerNode> NodesList, SimuCfg simConfig)
    {
        try
        {
            if (this.ClusterInfo_Wifi.NeighborsTable.Neighbors.Count == 0) return false;
            // set score of all neighbors to -1 ... problem!!! this score is visible by other nodes; but as we run simulation in a sequential manner no problem will occur
            foreach (NeighborInfo nei in this.ClusterInfo_Wifi.NeighborsTable.Neighbors)
            {
                nei.NodeInfo.Score = -1;
            }
            int MaximumAllowableClusterHeadMemberCount = simConfig.networkProfile.clusteringWifiProfile.MaximumAllowableClusterHeadMemberCount;
            //decide whether to remove previously chosen but not currently accessible cluster heads, or to keep them for a while.
            //if there are cluster-heads in neighborsTable, select the best,annouce it to that node, update myclusterheads list

            List<NeighborInfo> neighborWhichAreClusterHead = this.ClusterInfo_Wifi.NeighborsTable.GetListOfNeighborsWhichAreClusterHead();
            int CountOfNodes = NodesList.Count, MaxDistance = WiFi.RangeToBeConsideredAsNeighbor;

            if (neighborWhichAreClusterHead.Count != 0)
            {           //pick one if number of maximum allowed members not exceeds.
                List<NeighborInfo> NeighborClusterHeadsWhichHasFreeCapacityToHAndleMoreMembers = new List<NeighborInfo>();

                foreach (NeighborInfo nifo in neighborWhichAreClusterHead)
                {
                    if (!nifo.NodeInfo.isNodeAlive) continue;
                    //avoid overfilled cluster-heads
                    if (nifo.NodeInfo.CountOfCurrentMembersAsCH <= MaximumAllowableClusterHeadMemberCount)
                    {
                        NeighborClusterHeadsWhichHasFreeCapacityToHAndleMoreMembers.Add(nifo);
                    }
                }
                if (NeighborClusterHeadsWhichHasFreeCapacityToHAndleMoreMembers.Count == 0) //if there are no eligible cluster heads around, we have no choice but to select from over-filled cluster heads
                {
                    NeighborClusterHeadsWhichHasFreeCapacityToHAndleMoreMembers = neighborWhichAreClusterHead;
                }

                foreach (NeighborInfo nei in NeighborClusterHeadsWhichHasFreeCapacityToHAndleMoreMembers)
                {
                    nei.NodeInfo.Score = Cl_CalculateScore_Esfandiari(nei, CountOfNodes, MaxDistance);
                }
            }
            else
            {
                //calculate score for each neighbor, pick best node  according to its score
                List<NeighborInfo> NeighborNodesWhichHasNotClusterHead = new List<NeighborInfo>();
                foreach (NeighborInfo nei in this.ClusterInfo_Wifi.NeighborsTable.Neighbors)
                {
                    if (nei.NodeInfo.IHaveClusterHead == false) NeighborNodesWhichHasNotClusterHead.Add(nei);
                }
                if (NeighborNodesWhichHasNotClusterHead.Count == 0) //if no node found in the neighbors which is not attached to a cluster head, we have no other choice but to select our cluster head from all neighbors
                {
                    NeighborNodesWhichHasNotClusterHead = this.ClusterInfo_Wifi.NeighborsTable.Neighbors;
                }

                foreach (NeighborInfo nei in NeighborNodesWhichHasNotClusterHead)
                {
                    nei.NodeInfo.Score = Cl_CalculateScore_Esfandiari(nei, CountOfNodes, MaxDistance);
                }
            }

            NeighborInfo CandidateCH = this.ClusterInfo_Wifi.NeighborsTable.FindNeighborWithMaximumScore(this);
            if (CandidateCH == null)
            {
                this.ClusterInfo_Wifi.MyInfoToShareWithOhers.ListofMyClusterHeads.Clear();
                this.ClusterInfo_Wifi.MyInfoToShareWithOhers.IHaveClusterHead = false;
            }
            else
            {
                ComputerNode MyNewClusterHead = SimuData.GetNodeByID(CandidateCH.NodeInfo.NodeID, NodesList);
                if (!MyNewClusterHead.isNodeAlive)
                {
                    this.ClusterInfo_Wifi.MyInfoToShareWithOhers.ListofMyClusterHeads.Clear();
                    this.ClusterInfo_Wifi.MyInfoToShareWithOhers.IHaveClusterHead = false;
                }
                else
                {
                    MyNewClusterHead.ClusterInfo_Wifi.AddNodeToListOfThisNodeClusterMembers(this.NodeID); //register this node as the member of the candidate cH

                    this.ClusterInfo_Wifi.MyInfoToShareWithOhers.ListofMyClusterHeads.Add(CandidateCH.NodeInfo.NodeID);
                    this.ClusterInfo_Wifi.MyInfoToShareWithOhers.IHaveClusterHead = true;
                }
            }
            return true;
        }
        catch (Exception eee)
        {

            //    MessageBox.Show(" Error in performing clustering algorithm." + Environment.NewLine + eee.ToString());
            return false;

        }
    }


}

