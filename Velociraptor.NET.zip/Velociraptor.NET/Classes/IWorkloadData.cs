﻿namespace Velociraptor.Classes
{
    public interface IWorkloadData
    {
        long CountOfEdges { get; set; }
        long CountOfJobs { get; set; }
        long CountOfServers { get; set; }
        long CountOfTasks { get; set; }
        long ExecOnCloudParallel { get; set; }
        long ExecOnCloudSerial { get; set; }
        long ExecOnFogParallel { get; set; }
        long ExecOnFogSerial { get; set; }
        long SumJobSize { get; set; }
        double WorkloadScore { get; set; }
    }
}