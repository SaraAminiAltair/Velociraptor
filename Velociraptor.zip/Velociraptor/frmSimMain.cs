﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;

using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;
using System.Xml.Serialization;
using System.Diagnostics;

namespace SimuPro
{
    public partial class frmSimMain : Form
    {
        Form mainFormForBack;
        SSimulation internal_sim;
        SimulationConfiguration _simulationConfig = SimulationConfiguration.ExperimentOneSpecs(900000); //zz ra raa
       // SimulationConfiguration _simulationConfig = SimulationConfiguration.ExperimentTwoSpecs(600000); //zz ra raa
       // SimulationConfiguration _simulationConfig = SimulationConfiguration.ExperimentOneSpecs(600000); //zz ra raa






        SSimulation getSimObject()
        {
            if ((internal_sim == null) || ((internal_sim.isFinished)))
            {
                internal_sim = new SSimulation(_simulationConfig);
                internal_sim.InitTextboxes(txtLog, txtLogSingleActDetails);
                return internal_sim;
            }
            //it is not null and it is not finished (may be currently running or may be it has never been started)
            if (internal_sim.isSimulationRunning)
            {
                return internal_sim;
            }
            MessageBox.Show("Something is not right!");
            return null;
        }

        public frmSimMain(Form mainForm)
        {
            InitializeComponent();
        }

        Thread threadMainForSimulation;

        private void btnStartTestSim_Click(object sender, EventArgs e)
        {
        }

        private void frmSimMain_FormClosed(object sender, FormClosedEventArgs e)
        {
            try
            {
                mainFormForBack.Visible = true;
            }
            catch (Exception)
            {


            }

        }





        


        private void frmSimMain_Load(object sender, EventArgs e)
        {
            //this.WindowState = FormWindowState.Maximized;
        }
        private void btnStartTestSim_Click_1(object sender, EventArgs e)
        {
            //useMatlabFuzzy();
            btnStartTestSim.Visible = false;
            SSimulation s = getSimObject();
            if (s == null) return;
            try
            { //maxSteps = Convert.ToInt32("110"); 
            }
            catch (Exception) { }
            s.SimulationRun(txtLogSingleActDetails, true);
        }

        private void btnStopSimulation_Click_1(object sender, EventArgs e)
        {

            if (internal_sim == null) { MessageBox.Show("No Simulation"); }
            if ((internal_sim.isSimulationRunning) && (internal_sim.isFinished != false))
            {
                internal_sim.SimulationFullStop();
                internal_sim = null;
            }
        }


        private void btnSimContinue_Click(object sender, EventArgs e)
        {
            try
            {
                getSimObject().SimulationContinue();
            }
            catch (Exception ee)
            {
                MessageBox.Show("Error in accessing simulation object");
            }

        }

        private void btnSimPause_Click(object sender, EventArgs e)
        {
            try
            {
                getSimObject().SimulationPause();
            }
            catch (Exception ee)
            {
                MessageBox.Show("Error in accessing simulation object");
            }
          
        }

    }
}
