﻿ namespace SimuPro
{
    partial class frmSimMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmSimMain));
            this.txtLog = new System.Windows.Forms.TextBox();
            this.txtLogSingleActDetails = new System.Windows.Forms.TextBox();
            this.btnStartTestSim = new System.Windows.Forms.Button();
            this.btnSimPause = new System.Windows.Forms.Button();
            this.btnSimContinue = new System.Windows.Forms.Button();
            this.btnStopSimulation = new System.Windows.Forms.Button();
            this.bgWorker = new System.ComponentModel.BackgroundWorker();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // txtLog
            // 
            this.txtLog.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.txtLog.ForeColor = System.Drawing.Color.White;
            this.txtLog.Location = new System.Drawing.Point(22, 337);
            this.txtLog.Margin = new System.Windows.Forms.Padding(4);
            this.txtLog.Multiline = true;
            this.txtLog.Name = "txtLog";
            this.txtLog.ReadOnly = true;
            this.txtLog.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtLog.Size = new System.Drawing.Size(1020, 615);
            this.txtLog.TabIndex = 7;
            // 
            // txtLogSingleActDetails
            // 
            this.txtLogSingleActDetails.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.txtLogSingleActDetails.ForeColor = System.Drawing.Color.White;
            this.txtLogSingleActDetails.Location = new System.Drawing.Point(22, 202);
            this.txtLogSingleActDetails.Margin = new System.Windows.Forms.Padding(4);
            this.txtLogSingleActDetails.Multiline = true;
            this.txtLogSingleActDetails.Name = "txtLogSingleActDetails";
            this.txtLogSingleActDetails.ReadOnly = true;
            this.txtLogSingleActDetails.Size = new System.Drawing.Size(656, 127);
            this.txtLogSingleActDetails.TabIndex = 9;
            // 
            // btnStartTestSim
            // 
            this.btnStartTestSim.AutoSize = true;
            this.btnStartTestSim.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btnStartTestSim.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnStartTestSim.FlatAppearance.BorderSize = 0;
            this.btnStartTestSim.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnStartTestSim.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.btnStartTestSim.ForeColor = System.Drawing.Color.White;
            this.btnStartTestSim.Location = new System.Drawing.Point(22, 112);
            this.btnStartTestSim.Margin = new System.Windows.Forms.Padding(4);
            this.btnStartTestSim.Name = "btnStartTestSim";
            this.btnStartTestSim.Size = new System.Drawing.Size(124, 65);
            this.btnStartTestSim.TabIndex = 17;
            this.btnStartTestSim.Text = "Start";
            this.btnStartTestSim.UseVisualStyleBackColor = false;
            this.btnStartTestSim.Click += new System.EventHandler(this.btnStartTestSim_Click_1);
            // 
            // btnSimPause
            // 
            this.btnSimPause.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.btnSimPause.Location = new System.Drawing.Point(170, 133);
            this.btnSimPause.Margin = new System.Windows.Forms.Padding(4);
            this.btnSimPause.Name = "btnSimPause";
            this.btnSimPause.Size = new System.Drawing.Size(118, 44);
            this.btnSimPause.TabIndex = 20;
            this.btnSimPause.Text = "Pause ";
            this.btnSimPause.UseVisualStyleBackColor = true;
            this.btnSimPause.Click += new System.EventHandler(this.btnSimPause_Click);
            // 
            // btnSimContinue
            // 
            this.btnSimContinue.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.btnSimContinue.Location = new System.Drawing.Point(310, 131);
            this.btnSimContinue.Margin = new System.Windows.Forms.Padding(4);
            this.btnSimContinue.Name = "btnSimContinue";
            this.btnSimContinue.Size = new System.Drawing.Size(154, 46);
            this.btnSimContinue.TabIndex = 19;
            this.btnSimContinue.Text = "Continue";
            this.btnSimContinue.UseVisualStyleBackColor = true;
            this.btnSimContinue.Click += new System.EventHandler(this.btnSimContinue_Click);
            // 
            // btnStopSimulation
            // 
            this.btnStopSimulation.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.btnStopSimulation.Location = new System.Drawing.Point(498, 133);
            this.btnStopSimulation.Margin = new System.Windows.Forms.Padding(4);
            this.btnStopSimulation.Name = "btnStopSimulation";
            this.btnStopSimulation.Size = new System.Drawing.Size(140, 42);
            this.btnStopSimulation.TabIndex = 18;
            this.btnStopSimulation.Text = "Stop";
            this.btnStopSimulation.UseVisualStyleBackColor = true;
            this.btnStopSimulation.Click += new System.EventHandler(this.btnStopSimulation_Click_1);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(798, 33);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(186, 217);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 25;
            this.pictureBox1.TabStop = false;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.label2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.label2.Location = new System.Drawing.Point(700, 303);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(398, 26);
            this.label2.TabIndex = 24;
            this.label2.Text = "Advanced IoT, Fog and Cloud Simulator";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.label1.Location = new System.Drawing.Point(744, 240);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(317, 63);
            this.label1.TabIndex = 23;
            this.label1.Text = "Velociraptor";
            // 
            // frmSimMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.ClientSize = new System.Drawing.Size(1152, 979);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtLogSingleActDetails);
            this.Controls.Add(this.txtLog);
            this.Controls.Add(this.btnStartTestSim);
            this.Controls.Add(this.btnStopSimulation);
            this.Controls.Add(this.btnSimPause);
            this.Controls.Add(this.btnSimContinue);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frmSimMain";
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Velociraptor";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.frmSimMain_FormClosed);
            this.Load += new System.EventHandler(this.frmSimMain_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.TextBox txtLog;
        private System.Windows.Forms.TextBox txtLogSingleActDetails;
        private System.ComponentModel.BackgroundWorker bgWorker;
        private System.Windows.Forms.Button btnStartTestSim;
        private System.Windows.Forms.Button btnSimPause;
        private System.Windows.Forms.Button btnSimContinue;
        private System.Windows.Forms.Button btnStopSimulation;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
    }
}