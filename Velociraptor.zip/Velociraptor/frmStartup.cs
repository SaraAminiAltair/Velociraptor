﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SimuPro
{
    public partial class Startup : Form
    {
        frmSimMain frmSimulation;
        public Startup()
        {
            InitializeComponent();
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Visible = false;
            
                frmSimulation = new frmSimMain(this);
            frmSimulation.Show();
        }

        private void label3_Click(object sender, EventArgs e)
        {
            
        }

        private void Startup_Load(object sender, EventArgs e)
        {

            button1_Click(this, null);
            this.Visible = false;
        }

        private void button3_Click(object sender, EventArgs e)
        {

        }

        private void calc_Click(object sender, EventArgs e)
        {
            int X1, X2, Y1, Y2;
            double Teta, Atan;
            try
            {
                X1=Convert.ToInt32( x1.Text);
                Y1=Convert.ToInt32( y1.Text);

                X2 = Convert.ToInt32(x2.Text);
                Y2 = Convert.ToInt32(y2.Text);

                double kasr = (double)(Y2 - Y1) / (X2 - X1);
                double VectorDegreeInRadians = Math.Atan2(Y2, X2);
                double VectorDegreeInNormal = (VectorDegreeInRadians * 180 / 3.14151692);
                rad.Text = VectorDegreeInRadians.ToString();
                degree.Text = VectorDegreeInNormal.ToString();

                double vectorLength=Math.Sqrt(Math.Pow((Y2-Y1),2)+ Math.Pow((X2-X1), 2));
                double xF = vectorLength * Math.Cos(VectorDegreeInRadians);
                double yF = vectorLength * Math.Sin(VectorDegreeInRadians);

                xfactor.Text = xF.ToString();
                yfactor.Text = yF.ToString();

            }
            catch (Exception)
            {

            }
        }
    }
}
