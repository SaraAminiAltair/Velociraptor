﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

public class SimulationNodeStructure
{
    public Terrain terrain;
    public List<ComputerNode> Nodes = new List<ComputerNode>();
    public List<ComputerNode> IoTNodes = new List<ComputerNode>();
    public List<FogProvider> FogProviders = new List<FogProvider>();
    public List<CloudProvider> CloudProviders = new List<CloudProvider>();
    public List<FogPoint> FogPoints = new List<FogPoint>();
    public List<DataCenter> DataCenters = new List<DataCenter>();
    public List<Cluster> Clusters = new List<Cluster>();
    public DataPacketsQueues.SingleDataPacketQueue DroppedPackets = new DataPacketsQueues.SingleDataPacketQueue();
    public DataPacketsQueues.SingleDataPacketQueue SuccessfullyTransferedPackets = new DataPacketsQueues.SingleDataPacketQueue();

    public DataPacketsQueues.SingleDataPacketQueue AllGeneratedPackets = new DataPacketsQueues.SingleDataPacketQueue();
    public List<ComputerNode> DeadNodes = new List<ComputerNode>();
    SqlConnection SqlConnForLoggingDatabase;
    private int BaseLineCpuCloudFogMIPS = -1, BaseLineCpuCloudMIPS = -1, BaseLineCpuFogMIPS = -1, BaseLineCpuIoTMIPS = -1;
    public SimulationConfiguration SimuConfig;
    public ComputerNode Cellular3GInfrastructureAbstractNode = new ComputerNode();
    public int PacketIDLastGenerated = 0;


    public static ComputerNode GetNodeByID(string NodeID, List<ComputerNode> ListOfNodes)
    {
        
        foreach (ComputerNode n in ListOfNodes) if (n.NodeID == NodeID) return n;
        return null;
    }

    public ComputerNode GetRandomNode(bool onlyFromIoTNodes , string NodeID_to_Except) 
    {
        CoUtils cu = new CoUtils();
        bool found = false;
        List<ComputerNode> theNodeSet= Nodes; //all nodes
        if (onlyFromIoTNodes) theNodeSet = IoTNodes;

        while (!found)
        {
            int i = cu.RandomNumber(0, theNodeSet.Count-1);
            if ((theNodeSet[i].NodeID !=NodeID_to_Except )&&(theNodeSet[i].isNodeAlive))
            {
                return theNodeSet[i];
            }
        }
        return null;  
    }
    public CpuAndBandwidthBaseLines GetBaseLines()
    {
        int CpuBaseLineFogAndCloud = GetAverageCpuMipsInAllFogAndCloudNodes(false);
        int CpuBaseLineCloud = GetAverageCpuMipsInAllCloudNodes(false);
        int CpuBaseLineFog = GetAverageCpuMipsInAllFogPoints(false);
        int CpuBaseLineIoT = GetAverageCpuMipsInAllIoTNodes(false);
        int BaseLineBandwidthCloud, BaseLineBandwidthFogCloud, BaseLineBandwidthFog, BaseLineBandwidthIoT;
        BaseLineBandwidthCloud = BaseLineBandwidthFogCloud = BaseLineBandwidthFog = BaseLineBandwidthIoT = 2; //2 MB per Second
        CpuAndBandwidthBaseLines baselines = new CpuAndBandwidthBaseLines();
        baselines.MandatoryInit(CpuBaseLineFogAndCloud, CpuBaseLineCloud, CpuBaseLineFog, CpuBaseLineIoT, BaseLineBandwidthCloud, BaseLineBandwidthFogCloud, BaseLineBandwidthFog, BaseLineBandwidthIoT);

        return baselines;
    }
    public SimulationNodeStructure(SqlConnection _SqlConnForLoggingDatabase)
    {
        SqlConnForLoggingDatabase = _SqlConnForLoggingDatabase;
      


       
    }


    void CreateCellularAbstractInfra(SqlConnection _SqlConnForLoggingDatabase,double ProbablityOfCellularInfrastructureLossPacket_InsideSystem)
    {
        NodeHardwareProfile hwp = new NodeHardwareProfile();
        int DeviceCode = NodeHardwareProfile.DeviceCodes.CellularBTS;
        hwp.MandatoryInit(DeviceCode, NodeHardwareProfile.HardwarePowerSupply.Typical(DeviceCode) ,NodeHardwareProfile.HardwareComputer.Typical(DeviceCode),NodeHardwareProfile.GetDeviceNameBaseOnDeviceCode(DeviceCode), ProbablityOfCellularInfrastructureLossPacket_InsideSystem);
        SLocationProfile loc = new SLocationProfile();
    
        loc.MandatoryInit(0, true, 0, this.terrain, SLocationProfile.getRandomLocationPoint(this.terrain, 1));
        SNodeRolesProfile role = new SNodeRolesProfile();
        SNodeRolesProfile.NodeRoleRecord rolereco = new SNodeRolesProfile.NodeRoleRecord();
        rolereco.MandatoryInit(0, SNodeRolesProfile.NodeRoleCodes.RelayData);
        role.AddNewRole(rolereco);

        ComputerNode node = new ComputerNode();
        Cellular3GInfrastructureAbstractNode.ComputerNode_MandatoryInit(SqlConnForLoggingDatabase, "CellularInfrastructure", hwp, loc, role,this.SimuConfig);
    }

    public class FogProvider
    {
        public string FogProviderID;
        public List<string> MemberFogPointIDs = new List<string>();
    }


    public class FogPoint
    {
        public FogProvider ownerFogProvider;
        public string FogPointID;
        public SLocationPoint Location;

        public List<ComputerNode> MemberNodes = new List<ComputerNode>();
    }
    public class CloudProvider
    {
        public string CloudProviderID;

        public List<string> MemberDataCenterIDs = new List<string>();
    }



    public int GetAverageCpuMipsInAllFogAndCloudNodes(bool ForceRecalculate)
    {
        if (!((ForceRecalculate) || (BaseLineCpuCloudFogMIPS == -1))) return BaseLineCpuCloudFogMIPS;

        int s = 0;
        int c = 0;
        foreach (ComputerNode node in this.Nodes)
        {
            s = s + node.HardwareProfile.ComputerHardwareProfile.CPUProfile.CPUMaxMIPS;
            c++;
        }
        if ((s == 0) || (c == 0)) return 1;
        int avg = Convert.ToInt32(Math.Ceiling((double)s / c));
        BaseLineCpuCloudFogMIPS = avg;
        return BaseLineCpuCloudFogMIPS;
    }
    public int GetAverageCpuMipsInAllIoTNodes(bool ForceRecalculate)
    {
        if (!((ForceRecalculate) || (BaseLineCpuIoTMIPS == -1))) return BaseLineCpuIoTMIPS;

        int s = 0;
        int c = 0;
        foreach (ComputerNode node in this.IoTNodes)
        {
            s = s + node.HardwareProfile.ComputerHardwareProfile.CPUProfile.CPUMaxMIPS;
            c++;
        }
        if ((s == 0) || (c == 0)) return 1;
        this.BaseLineCpuIoTMIPS = Convert.ToInt32(Math.Ceiling((double)s / c));

        return BaseLineCpuIoTMIPS;
    }
    public int GetAverageCpuMipsInAllFogPoints(bool ForceRecalculate)
    {
        if (!((ForceRecalculate) || (BaseLineCpuFogMIPS == -1))) return BaseLineCpuFogMIPS;

        int s = 0;
        int c = 0;
        foreach (FogPoint fogpoint in FogPoints)
        {

            foreach (ComputerNode node in fogpoint.MemberNodes)
            {
                s = s + node.HardwareProfile.ComputerHardwareProfile.CPUProfile.CPUMaxMIPS;
                c++;
            }
        }

        if ((s == 0) || (c == 0)) return 1;
        this.BaseLineCpuFogMIPS = Convert.ToInt32(Math.Ceiling((double)s / c));
        return BaseLineCpuFogMIPS;
    }
    public int GetAverageCpuMipsInAllCloudNodes(bool ForceRecalculate)
    {
        if (!((ForceRecalculate) || (BaseLineCpuCloudMIPS == -1))) return BaseLineCpuCloudMIPS;

        int s = 0;
        int c = 0;
        foreach (Cluster cluster in Clusters)
        {
            foreach (ComputerNode node in cluster.MemberNodes)
            {

                s = s + node.HardwareProfile.ComputerHardwareProfile.CPUProfile.CPUMaxMIPS;
                c++;
            }
        }
        if ((s == 0) || (c == 0)) return 1;
        this.BaseLineCpuCloudMIPS = Convert.ToInt32(Math.Ceiling((double)s / c));

        return BaseLineCpuCloudMIPS;
    }
    public class DataCenter
    {
        public CloudProvider ownerCloudProvider;

        public string DataCenterID;
        public SLocationPoint Location;

        public List<Cluster> MemberClusters = new List<Cluster>();
    }

    public class Cluster
    {
        public DataCenter ownerDataCenter;

        public string ClusterID;
        public List<ComputerNode> MemberNodes = new List<ComputerNode>();
    }


    private static string getARandomName(bool useNumberAtEnd)
    {
        CoUtils cu = new CoUtils();
        try
        {
            string[] n = { "TraveloSystems", "Jackolicom", "Cyphocom", "Naxodoc", "Lomocom", "Yachta", "Jeronicomp", "Utalita", "Comtroniz", "Alabamacom", "Niniocom", "Clouderino", "zuffolonic" };
            string s = n[cu.RandomNumber(0, n.Length - 1)];
            if (useNumberAtEnd) s = s + cu.RandomNumber(2);
            return s;
        }
        catch (Exception)
        {
            return "Tatojan";
        }

    }

    public static SimulationNodeStructure RandomGenerateNodeStructure(TextBox reportbox, SqlConnection _SqlConnForLoggingDatabase, SimulationConfiguration simuConfig)
    {
        CoUtils cu = new CoUtils();
        SimulationNodeStructure s = new SimulationNodeStructure(_SqlConnForLoggingDatabase);
        s.terrain = new Terrain(simuConfig.terrainSpec);
        s.SimuConfig = simuConfig;

        s.CreateCellularAbstractInfra(_SqlConnForLoggingDatabase,s.SimuConfig.networkProfile.networkFailureModel.ProbablityOfCellularInfrastructureLossPacket_InsideSystem);
        {//-------------------------------------------------------------------IoT Nodes---------------------------------------------------------------
 
            List<ComputerNode> res = new List<ComputerNode>();
            Dictionary<int, int> portion = new Dictionary<int, int>();
            portion.Add(NodeHardwareProfile.DeviceCodes.iphoneX, Convert.ToInt32(simuConfig.ioTSpec.CountOfIoTNodes * 0.4));
            portion.Add(NodeHardwareProfile.DeviceCodes.samsungS8, Convert.ToInt32(simuConfig.ioTSpec.CountOfIoTNodes * 0.4));
            portion.Add(NodeHardwareProfile.DeviceCodes.RPi2OnBattery, Convert.ToInt32(simuConfig.ioTSpec.CountOfIoTNodes * 0.09));
            portion.Add(NodeHardwareProfile.DeviceCodes.iPad4, Convert.ToInt32(simuConfig.ioTSpec.CountOfIoTNodes * 0.11));

            int accel, speed, speedmax;
            SLocationProfile loc;
            SNodeRolesProfile role;
            NodeHardwareProfile hwp;
            int nodeDataGenerationStatus = 0;

            foreach (var item in portion)
            {
                int devCode = item.Key;
                int count = item.Value;
                for (int i = 0; i < count; i++)
                {


                    hwp = NodeHardwareProfile.TypicalGenerate(devCode, NodeHardwareProfile.NodeTypes.IoTNode, s.SimuConfig.networkProfile);

                    accel = 0;
                    loc = new SLocationProfile();
                    loc.MandatoryInit(0, true, accel, s.terrain, SLocationProfile.getRandomLocationPoint(s.terrain, SLocationProfile.getQuartile(i, count)));
                    role = new SNodeRolesProfile();
                    SNodeRolesProfile.NodeRoleRecord rolereco = new SNodeRolesProfile.NodeRoleRecord();
                    rolereco.MandatoryInit(0, nodeDataGenerationStatus);
                    role.AddNewRole(rolereco);
                    string nodeid = cu.RandomString(2, false) + cu.RandomNumber(3).ToString();
                    ComputerNode node = new ComputerNode();
                    node.ComputerNode_MandatoryInit(_SqlConnForLoggingDatabase, nodeid, hwp, loc, role, s.SimuConfig);
                    res.Add(node);
                }
            }

            s.IoTNodes = res;

        }
        //-------------------------------------------------------------------End of IoT Nodes---------------------------------------------------------------

        //-------------------------------------------------------------------Cloud and Fog Nodes---------------------------------------------------------------
        int CountOfCloudProviders = Math.Max(1, cu.RandomNumber(simuConfig.cloudSpec.MinCountOfCloudProviders, simuConfig.cloudSpec.MaxCountOfCloudProviders));
        List<string> cloudNames = new List<string>();
        for (int i = 0; i < CountOfCloudProviders; i++)
        {
            string name = "";
            while ((name == "") || (cloudNames.IndexOf(name) >= 0)) name = "CP_" + getARandomName(true);
            cloudNames.Add(name);
            CloudProvider cp = new CloudProvider();
            cp.CloudProviderID = name;
            s.CloudProviders.Add(cp);
        }
        foreach (CloudProvider cloudProvider in s.CloudProviders)
        {
            int Count = Math.Max(1, cu.RandomNumber(simuConfig.cloudSpec.MinCountOfCloudProvidersDataCenters, simuConfig.cloudSpec.MaxCountOfCloudProvidersDataCenters));
            for (int i = 0; i < Count; i++)
            {
                string name = "DC_" + (i).ToString() + "_of_" + cloudProvider.CloudProviderID;
                DataCenter dc = new DataCenter();
                dc.DataCenterID = name;
                dc.ownerCloudProvider = cloudProvider;
                dc.Location = SLocationProfile.getRandomLocationPoint(s.terrain, SLocationProfile.getQuartile(i, Count));
                s.DataCenters.Add(dc);
                cloudProvider.MemberDataCenterIDs.Add(dc.DataCenterID);
            }
        }

        foreach (DataCenter dc in s.DataCenters)
        {
            int Count = Math.Max(1, cu.RandomNumber(simuConfig.cloudSpec.MinCountOfClustersInDataCenter, simuConfig.cloudSpec.MaxCountOfClustersInDataCenter));
            for (int i = 0; i < Count; i++)
            {
                string name = "Clst_" + i.ToString() + "_of_" + dc.DataCenterID;
                Cluster cluster = new Cluster();
                cluster.ClusterID = name;
                cluster.ownerDataCenter = dc;


                s.Clusters.Add(cluster);
                dc.MemberClusters.Add(cluster);
            }
        }
        int[] devcodesForCloudDataCenter = { NodeHardwareProfile.DeviceCodes.serverAMDRyzen9, NodeHardwareProfile.DeviceCodes.serverCorei9_9900, NodeHardwareProfile.DeviceCodes.serverAMDRyzenThreadripper };
        int[] devcodesForFogPoints = { NodeHardwareProfile.DeviceCodes.serverCorei9_9900, NodeHardwareProfile.DeviceCodes.serverCorei7_8086 };
        int TotalMachinesInCloud = 0;
        for (int z = 0; z < s.Clusters.Count; z++)
        {
            Cluster cluster = s.Clusters[z];
            string ss = "Creating Cloud cluster number " + (z + 1).ToString() + " of " + s.Clusters.Count.ToString();


            int Count = Math.Max(1, cu.RandomNumber(simuConfig.cloudSpec.MinCountOfNodesInDCCluster, simuConfig.cloudSpec.MaxCountOfNodesInDCCluster));
            for (int i = 0; i < Count; i++)
            {
                NodeHardwareProfile hwp = NodeHardwareProfile.TypicalGenerate(devcodesForCloudDataCenter[cu.RandomNumber(0, devcodesForCloudDataCenter.Length - 1)], NodeHardwareProfile.NodeTypes.Host_InCloudDataCenter, s.SimuConfig.networkProfile);
                int accel = 0;
                string nodeid = "N_" + i.ToString() + "_of_" + cluster.ClusterID;
                SLocationPoint currentLoc = cluster.ownerDataCenter.Location;
                SLocationProfile loc = new SLocationProfile();
                loc.MandatoryInit(0, true, accel, s.terrain, currentLoc);
                SNodeRolesProfile nodeRolesprofile = new SNodeRolesProfile();
                SNodeRolesProfile.NodeRoleRecord rolereco;


                rolereco = new SNodeRolesProfile.NodeRoleRecord();
                rolereco.MandatoryInit(0, SNodeRolesProfile.NodeRoleCodes.PerformSchedulingOnSelftAndOtherNodes);
                nodeRolesprofile.AddNewRole(rolereco);

                rolereco = new SNodeRolesProfile.NodeRoleRecord();
                rolereco.MandatoryInit(0, SNodeRolesProfile.NodeRoleCodes.OfferResourcesForScheduling);
                nodeRolesprofile.AddNewRole(rolereco);




                ComputerNode node = new ComputerNode();
                node.ComputerNode_MandatoryInit(_SqlConnForLoggingDatabase, nodeid, hwp, loc, nodeRolesprofile,s.SimuConfig);
                cluster.MemberNodes.Add(node);
                s.Nodes.Add(node);
                string rep = Environment.NewLine + "Node " + i.ToString() + " of " + Count.ToString() + " added.";
                rep = ss + rep;
                reportbox.Invoke(new Action(() => reportbox.Text = rep));
                TotalMachinesInCloud++;
            }
        }


        //Creating Fog Providers
        int countOfFogProviders = Math.Max(1, cu.RandomNumber(simuConfig.fogSpec.MinCountOfFogProviders, simuConfig.fogSpec.MaxCountOfFogProviders));
        List<string> fogProviderNames = new List<string>();
        for (int i = 0; i < countOfFogProviders; i++)
        {
            string name = "";
            while ((name == "") || (fogProviderNames.IndexOf(name) >= 0))
            {
                name = getARandomName(true);
            }

            fogProviderNames.Add(name);
            FogProvider fp = new FogProvider();
            fp.FogProviderID = name;

            s.FogProviders.Add(fp);
        }



        foreach (FogProvider fogpro in s.FogProviders)
        {
            int Count = Math.Max(1, cu.RandomNumber(simuConfig.fogSpec.MinCountOfFogProviderFogPoint, simuConfig.fogSpec.MaxCountOfFogProviderFogPoint));
            for (int i = 0; i < Count; i++)
            {
                string name = "FP_" + (i).ToString() + "_of_" + fogpro.FogProviderID;
                FogPoint fp = new FogPoint();
                fp.FogPointID = name;
                fp.ownerFogProvider = fogpro;
                fp.Location = SLocationProfile.getRandomLocationPoint(s.terrain, SLocationProfile.getQuartile(i, Count));
                s.FogPoints.Add(fp);
                fogpro.MemberFogPointIDs.Add(fp.FogPointID);
            }
        }




        for (int z = 0; z < s.FogPoints.Count; z++)
        {
            FogPoint fogpoint = s.FogPoints[z];
            string ss = "Working on FogPoint " + z.ToString() + " of " + s.FogPoints.Count.ToString();
            int Count = Math.Max(1, cu.RandomNumber(simuConfig.fogSpec.MinCountOfNodesInFogPointCluster, simuConfig.fogSpec.MaxCountOfNodesInFogPointCluster));
            for (int i = 0; i < Count; i++)
            {
                NodeHardwareProfile hwp = NodeHardwareProfile.TypicalGenerate(devcodesForFogPoints[cu.RandomNumber(0, devcodesForFogPoints.Length - 1)], NodeHardwareProfile.NodeTypes.Host_InFogPoint, s.SimuConfig.networkProfile);
                int accel = 0;
                string nodeid = "N_" + i.ToString() + "_of_" + fogpoint.FogPointID;
                SLocationProfile loc = new SLocationProfile();
                loc.MandatoryInit(0, true, accel, s.terrain, fogpoint.Location); //zz may need new constructor
                SNodeRolesProfile role = new SNodeRolesProfile();
                SNodeRolesProfile.NodeRoleRecord rolereco = new SNodeRolesProfile.NodeRoleRecord();

                rolereco.MandatoryInit(0, SNodeRolesProfile.NodeRoleCodes.PerformSchedulingOnSelftAndOtherNodes);
                role.AddNewRole(rolereco);//performs scheduling
                rolereco = new SNodeRolesProfile.NodeRoleRecord();
                rolereco.MandatoryInit(0, SNodeRolesProfile.NodeRoleCodes.OfferResourcesForScheduling);
                role.AddNewRole(rolereco);//performs scheduling

                ComputerNode node = new ComputerNode();
                node.ComputerNode_MandatoryInit(_SqlConnForLoggingDatabase, nodeid, hwp, loc, role,s.SimuConfig);
                fogpoint.MemberNodes.Add(node);
                s.Nodes.Add(node);
                string rep = ss + Environment.NewLine + "node " + i.ToString() + " of " + Count + "added.";
                reportbox.Invoke(new Action(() => reportbox.Text = rep));
            }
        }
        //-----------------

        //zz location of datacenters and fogpoints


        return s;

    }






}

public class CpuAndBandwidthBaseLines
{
    public void MandatoryInit(int _CPUFogCloudBaseLineMips, int _CPUCloudMachineBaseLineMips, int _CPUFogMachineBaseLineMips, int _CPUIoTMachineBaseLineMips, int _BandwidthInCloudBaseLine, int _BandwidthCloudFogBaseLine, int _BandwidthFogBaseLine, int _BandwidthIoTBaseLine)
    {
        CPUFogCloudBaseLineMips = _CPUFogCloudBaseLineMips;
        CPUCloudMachineBaseLineMips = _CPUCloudMachineBaseLineMips;
        CPUFogMachineBaseLineMips = _CPUFogMachineBaseLineMips;
        CPUIoTMachineBaseLineMips = _CPUIoTMachineBaseLineMips;
        BandwidthInCloudBaseLine = _BandwidthInCloudBaseLine;
        BandwidthCloudFogBaseLine = _BandwidthCloudFogBaseLine;
        BandwidthFogBaseLine = _BandwidthFogBaseLine;
        BandwidthIoTBaseLine = _BandwidthIoTBaseLine;
    }

    public int CPUFogCloudBaseLineMips, CPUCloudMachineBaseLineMips, CPUFogMachineBaseLineMips, CPUIoTMachineBaseLineMips, BandwidthInCloudBaseLine, BandwidthCloudFogBaseLine, BandwidthFogBaseLine, BandwidthIoTBaseLine;
}


