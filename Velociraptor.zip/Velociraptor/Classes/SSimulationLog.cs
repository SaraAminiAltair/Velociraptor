﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

 
   public class SSimulationLog
    {
    public static void LogNodeDetailData(ComputerNode node)
    {

    }
    public static void LogJobDetailData(Job job)
    {

    }

    public static void FlushLogsToFile(string filename)
    {

    }
    public static void FlushLogsToDB(string connString)
    {

    }
}
 
