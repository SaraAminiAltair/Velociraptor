﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Serialization;

public class SSimulation
{
    bool doLogOnDatabase;
    public List<Job> JobsCurrent = null;
    public bool isTerrainInited = false;
    public bool isJobsGenerated = false;
    public CoUtils cu = new CoUtils();
    public zRaponDB DAL = new zRaponDB();
    SimulationNodeStructure nodesStructure;




    public string Log = "";
    Thread threadMainForSimulation;
    Thread threadJobCreation;

    public bool isSimulationRunning = false, isJobGenerationRunning = false;
    private ManualResetEvent resetEvent = new ManualResetEvent(true);
    

    TextBox LogAcc, LogSingle;
    int SimulaitonTime = 0;
    public bool isFinished = false;
    public SimulationConfiguration simulationConfig;
    public SSimulation(SimulationConfiguration _simulationConfig)
    {
        this.nodesStructure = new SimulationNodeStructure(DAL.getConnectionObject());
        simulationConfig = _simulationConfig;
    }


    public void SimulationRun(TextBox reportBox, bool _doLogonDatabase)
    {
        doLogOnDatabase = _doLogonDatabase;
        if (this.isSimulationRunning)
        {
            return;
        }
      

        if (!isTerrainInited)
        {
            var watch = Stopwatch.StartNew();
            List<Task> tasks = new List<Task>();
            var t = Task.Factory.StartNew(() =>
            {
                GenerateRandomTerrainAndNodes(reportBox, true,simulationConfig);
            });
            tasks.Add(t);
            Task.Factory.ContinueWhenAll(tasks.ToArray(),
                  result =>
                  {
                      var time = watch.ElapsedMilliseconds;
                      InitAndRunSimWorker();
                  });
        }
        else
        {
            InitAndRunSimWorker();
        }
    }

    void InitAndRunSimWorker()
    {
        SimulaitonTime = 0;

        threadMainForSimulation = new Thread(simWorker);
        threadMainForSimulation.IsBackground = true;
        threadMainForSimulation.Start();
    }

    private void simWorker()
    {
        if (!isJobsGenerated)
        {
            GenerateRandomJobsworker();
        }
        isSimulationRunning = true;
        for (int i = 1; i <= simulationConfig.simulationMaxStep; i++)
        {
            
            PerformCycle();
            SimulaitonTime++;

            resetEvent.WaitOne();
        }
        PerformLogs();

        for (int i=0;i<nodesStructure.Nodes.Count;i++)
        {
            ComputerNode node = nodesStructure.Nodes[i];
            bool x1 = node.DataPacketQueues_Cellular3G.AreAllQueuesEmpty();
            bool x2 = node.DataPacketQueues_Wifi.AreAllQueuesEmpty();
            bool x3=(node.DataPacketQueueGenerated.Queue.Count>0);
            if (x3)
            {
               // MessageBox.Show("A Node found with non-empty queues ");
            }
        }


        int SimID = FinalizeSimulation();
        return;

    }
    void PerformLogs()
    {
        SqlConnection conn = DAL.getConnectionObject();
        int i = 1;
        delWriteLog(false, "Simulation finished. Writting logs to the database");
        foreach (ComputerNode node in nodesStructure.Nodes)
        {
            node.Log_NodeSteps(conn);
            delWriteLog(true, string.Format("Logging node {0} of {1}", i.ToString(), nodesStructure.Nodes.Count.ToString()));
            i++;
            //zz other loggings here
        }
        delWriteLog(false, string.Format("Logging finished."));
        delWriteLog(true, string.Format("Logging finished."));


    }

    private void PerformCycle()
    {
        Cellular.DispachAllPacketsFromAbstractNode(this.DAL.getConnectionObject(), this.nodesStructure, this.SimulaitonTime);
        foreach (ComputerNode node in this.nodesStructure.Nodes)
        {
            node.DoOneStepOfMainLoop(nodesStructure, SimulaitonTime, this.DAL.getConnectionObject());
        }
       
        delWriteLog(true, ("Current Simulation Step " + SimulaitonTime.ToString() + " of " + simulationConfig.simulationMaxStep.ToString()));
    }



    public void InitTextboxes(TextBox _LogAcc, TextBox _LogSingle)
    {
        LogAcc = _LogAcc;
        LogSingle = _LogSingle;
    }
    void delWriteLog(bool isDetailForSingleAct, string msg)
    {

        try
        {
            if (isDetailForSingleAct)
            {
                LogSingle.Invoke(new WriteOnLogDelegate(WriteOnLog), true, msg);

            }
            else
            {
                LogAcc.Invoke(new WriteOnLogDelegate(WriteOnLog), false, msg);

            }
        }
        catch (Exception)
        {


        }

    }

    private delegate void WriteOnLogDelegate(bool isDetailForSingleAct, string msg);
    void WriteOnLog(bool isDetailForSingleAct, string msg)
    {
        try
        {


            if (isDetailForSingleAct)
            {
                LogSingle.Text = msg;
            }
            else
            {
                LogAcc.Text += Environment.NewLine + msg;
            }
        }
        catch (Exception)
        {

            throw;
        }
    }







    public void GenerateJobsInNewThread()
    {


        threadJobCreation = new Thread(GenerateRandomJobsworker);
        threadJobCreation.IsBackground = true;
        threadJobCreation.Start();
    }



    public void SerializeNow(List<Job> Jobs, string FilePath)
    {
        XmlSerializer x = new XmlSerializer(typeof(List<Job>));
        TextWriter writer = new StreamWriter(FilePath);
        x.Serialize(writer, Jobs);
        writer.Close();
        writer.Dispose();
    }
    public List<Job> DeSerializeNow(string FilePath)
    {
        var mySerializer = new XmlSerializer(typeof(List<Job>));
        var myFileStream = new FileStream(FilePath, FileMode.Open);
        List<Job> obj = (List<Job>)mySerializer.Deserialize(myFileStream);
        myFileStream.Close();
        myFileStream.Dispose();
        return obj;
    }

    public void SimulationFullStop()
    {
        if (isSimulationRunning)
        {
            try
            {

                int SimID = FinalizeSimulation();
                threadMainForSimulation.Join();
                threadMainForSimulation.Abort();
            }
            catch (Exception)
            {
            }
        }
    }
    int FinalizeSimulation()
    {
        try

        {

            int SimID = -1;
            if (doLogOnDatabase)
            {
                this.isSimulationRunning = false;
                SqlConnection conn = DAL.getConnectionObject();
                if (conn.State != ConnectionState.Open) conn.Open();
                using (SqlCommand cmd = new SqlCommand("SP_Finalize", conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.Add("@Date", SqlDbType.NVarChar).Value = cu.getCurrentPersianDateFull();
                    cmd.Parameters.Add("@Time", SqlDbType.NVarChar).Value = cu.getCurrentTime_24Format_WithSeconds();

                    var SimulationID = cmd.Parameters.Add("@ReturnVal", SqlDbType.Int);
                    SimulationID.Direction = ParameterDirection.ReturnValue;
                    cmd.ExecuteNonQuery();
                    SimID = Convert.ToInt32(SimulationID.Value);
                }
                string m = "";
                if (SimulaitonTime == simulationConfig.simulationMaxStep)
                {
                    m = "Simulation finished successfully";
                }
                else
                {
                    m = "Simulation stopped by the user.";

                }
                delWriteLog(false, m + Environment.NewLine + "Simulation ID in the database is " + SimID.ToString());
            }
            else
            {
                delWriteLog(false, "Simulation finished");
            }
            return SimID;
        }
        catch (Exception e)
        {
        //    MessageBox.Show("Error ocurred in finalizing simulation" + Environment.NewLine + Environment.NewLine + e.ToString());
            threadMainForSimulation.Abort();
            return -1;
        }
    }
    public void SimulationPause()
    {
        try
        {
            this.resetEvent.Reset();
            // threadMainForSimulation.Abort();
            //delWriteLog(true, "");
            delWriteLog(false, "simulation paused by the user.");
        }
        catch (Exception)
        {
        }
    }
    public void SimulationContinue()
    {
        try
        {
            this.resetEvent.Set();

            delWriteLog(false, "simulation resumed by the user.");
        }
        catch (Exception)
        {
        }
    }
    public void GeneratingJobsStop()
    {
        try
        {
            threadJobCreation.Abort();
            delWriteLog(true, "");
            delWriteLog(false, "Job Generation stopped by the user.");
        }
        catch (Exception)
        {
        }
    }

    public void JobsSaveToFile(string filename)
    {
        if (JobsCurrent != null)
        {
            SerializeNow(JobsCurrent, filename);
        //    MessageBox.Show("All jobs were saved to the file.");
        }
        else
        {
            MessageBox.Show("No job is generated yet.");
        }
    }

    public void JobsLoadFromFile(string filename)
    {
        try
        {
            List<Job> ss = DeSerializeNow(filename);
            JobsCurrent = ss;
            MessageBox.Show("Jobs loaded from file");


        }
        catch (FileNotFoundException ee)
        {
            MessageBox.Show("File not found.");
        }
        catch (Exception eee)
        {
            MessageBox.Show("Error occured:" + Environment.NewLine + eee.ToString());

        }
    }



    private void GenerateRandomTerrainAndNodes(TextBox reportBox, bool dologOnTextboxes, SimulationConfiguration simulationConfig)
    {
        try
        {
            nodesStructure.Nodes = null;
            string msg;
            msg = string.Format(Environment.NewLine + "Initializing simulation engine" + Environment.NewLine);
            delWriteLog(false, msg);

            nodesStructure= SimulationNodeStructure.RandomGenerateNodeStructure(reportBox,  DAL.getConnectionObject(),simulationConfig);
            delWriteLog(false, "------ Nodes Configuration -----");
            msg = string.Format("IoT nodes: {0}" + "", nodesStructure.IoTNodes.Count);
            delWriteLog(false, msg);
            delWriteLog(false, string.Format("Cloud providers: {0}" + "", nodesStructure.CloudProviders.Count));
            delWriteLog(false, string.Format("Datacenters: {0}" + "", nodesStructure.DataCenters.Count));
            delWriteLog(false, string.Format("Clusters: {0}" + "", nodesStructure.Clusters.Count));
            delWriteLog(false, string.Format("Fog providers: {0}" + "", nodesStructure.FogProviders.Count));
            delWriteLog(false, string.Format("Fog points: {0}" + "", nodesStructure.FogPoints.Count));
            
            nodesStructure.Nodes = nodesStructure.Nodes.Concat(nodesStructure.IoTNodes).ToList();
            delWriteLog(false, string.Format("Fog/Cloud hosts: {0}" + "", nodesStructure.Nodes.Count));
            delWriteLog(false, "----------------------------------");
            isTerrainInited = true;
        }

        catch (Exception e)
        {
            MessageBox.Show("Error occured" + Environment.NewLine + e.ToString());
            isTerrainInited = false;
        }

    }



    private void GenerateRandomJobsworker()
    {
        if (!isTerrainInited)
        {
            MessageBox.Show("First you should initialize the environment.");
            return;
        }
        try
        {
           
            Job.RequirementProfileForTasks trp = new Job.RequirementProfileForTasks();
            trp.RequirementProfileForTasks_Init(simulationConfig.jobGenerationProfile.TasksCPUNeedMin, simulationConfig.jobGenerationProfile.TasksCPUNeedMax, simulationConfig.jobGenerationProfile.TasksMemNeedMin, simulationConfig.jobGenerationProfile.TasksMemNeedMax, simulationConfig.jobGenerationProfile.TasksStorageNeedMin, simulationConfig.jobGenerationProfile.TasksStorageNeedMax, simulationConfig.jobGenerationProfile.NeededResourceTypes, simulationConfig.jobGenerationProfile.MaxCountOfResourcesEachTaskMayNeed, simulationConfig.jobGenerationProfile.TimeDeadlineFinalPercentageFromTaskSize, simulationConfig.jobGenerationProfile.TimeDeadLinePreferedPercentageFromTaskSize);
            Job.RequirementProfileForEdges erp = new Job.RequirementProfileForEdges();
            erp.RequirementProfileForEdges_Init(simulationConfig.jobGenerationProfile.Connectivity, simulationConfig.jobGenerationProfile.EdgeWeightMin, simulationConfig.jobGenerationProfile.EdgeWeightMax);
            List<Job> Jobs = new List<Job>();
            int JobID = 0;
            string msg = string.Format("creating job dags" + Environment.NewLine);
            delWriteLog(false, msg);
            for (int i = 0; i < simulationConfig.jobGenerationProfile.CountOfDags; i++)
            {
                int CountOfTasksInDAG = Convert.ToInt32(cu.RandomNumber(simulationConfig.jobGenerationProfile.CountOfTasksInDagMin, simulationConfig.jobGenerationProfile.CountOfTasksInDagMax));
                string UserIDOwner = cu.RandomString(1, false) + cu.RandomNumber(3);
                ComputerNode NodeSubmittedFrom = nodesStructure.Nodes[cu.RandomNumber(0, nodesStructure.Nodes.Count - 1)];
                int timeSubmission = 0; timeSubmission++;
                msg = String.Format("Creating job dag "+i.ToString()+" of "+ simulationConfig.jobGenerationProfile.CountOfDags.ToString() + Environment.NewLine + "with {0} nodes...", CountOfTasksInDAG);
                delWriteLog(true, msg);
                timeSubmission = cu.RandomNumber(0, simulationConfig.simulationMaxStep);
                Job job = Job.GenerateRandomDAG(JobID, CountOfTasksInDAG, trp, erp, timeSubmission, UserIDOwner, NodeSubmittedFrom, cu.getCurrentPersianDateFull(), DAL.getConnectionObject());
                job.CalculateDagSuppInfo(this.nodesStructure, DAL.getConnectionObject());
                if (job != null)
                {
                    Jobs.Add(job);
                    NodeSubmittedFrom.JobQue_AddtoWaitQueue(job);
                    msg = string.Format("Job Id:{0} with {1} nodes and {2} edges has been created", job.JobID, job.Tasks.Count, job.Edges.Count);
                    delWriteLog(false, msg);
                }
                JobID++;
            }
            msg = "";
            delWriteLog(true, msg);
            msg = string.Format("Total {0} job(s) has been created.", Jobs.Count);
            delWriteLog(false, msg);
            JobsCurrent = Jobs;
            JobsSaveToFile("Dags__" + cu.getCurrentPersianDateFull().Replace('/','-') + "__" + cu.getCurrentTime_24Format_WithSeconds().Replace(':', '-') + ".xml");

            isJobsGenerated = true;
        }
        catch (Exception ee)
        {
            MessageBox.Show("Error occured" + Environment.NewLine + ee.ToString());
            isTerrainInited = false;
        }


    }








}

