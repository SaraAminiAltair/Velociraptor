﻿ 
// Data Access Layer Core Class (Base Class)
//  October 2009 ( ABAN 1388)
//  Soror Design and Development Co.
using System;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;
using System.Web;
 
using System.Collections;


/// <summary>
/// Summary description for DBClassDALcore
/// </summary>
public class zRaponDB
{

    protected SqlConnection Connection;

    public zRaponDB()
    {
        Connection = new SqlConnection(getAppConnStr());
        Connection.Open();
    }

    public string getAppConnStr()
    {// return ("Data Source=192.168.1.100;Integrated Security=SSPI;Initial Catalog=Ecommerce; ");
      //  string cnString = ConfigurationManager.ConnectionStrings[ConnStrNameinWebConfigFile].ConnectionString;
      string cnString = @"Server=127.0.0.1;Database=SimuPro;User ID=SimuProIIS;Password=motogodsinemo10249972$jpark";
        /*
         * <add name="RaponConnection" connectionString="Server=localhost\SSiMac;Database=SimuPro;User ID=SimuProIIS;Password=motogodsinemo10249972$jpark" providerName="System.Data.SqlClient"/>
         */
        return cnString;

    }


    public String getField(DataTable dt,int RowIndex,string FieldName)
    {
        try
        {

            if (dt.Rows[RowIndex][FieldName] == null) return "";
        return (dt.Rows[RowIndex][FieldName].ToString());

        }
        catch (Exception e)
        {
            throw e;
        }
    }

    public string getCurrentConnStr()
    {
        return Connection.ConnectionString;
    }
    

    public SqlConnection getConnectionObject()
    {
        return Connection;
    }
    public DataSet GetDataSet(string Query)
    {
        if (Query.IndexOf("delete", StringComparison.CurrentCultureIgnoreCase) >= 0) return null;
        if (Query.IndexOf("drop", StringComparison.CurrentCultureIgnoreCase) >= 0) return null;
        if (Query.IndexOf("insert", StringComparison.CurrentCultureIgnoreCase) >= 0) return null;
        if (Query.IndexOf("update", StringComparison.CurrentCultureIgnoreCase) >= 0) return null;
        Exception e = new Exception();
        // any exception will be writed to e object
        SqlDataAdapter Adapter = new SqlDataAdapter(Query, Connection);
        DataSet ItemDataSet = new DataSet();
        try
        {
            if (Connection.State != ConnectionState.Open) Connection.Open();
            Adapter.Fill(ItemDataSet, "Table0");
            Connection.Close();
            e = null;
        }
        catch (SqlException e1)
        { // write Error To log DB ERROR!
            e = e1;
            ItemDataSet = null;
        }
        catch (Exception e2)
        {
            ItemDataSet = null;
        }
        return ItemDataSet;
    }

    public DataSet getTable(string _table, string _colname, string _criteria)
    {
        if (_criteria == "") { _criteria = " 1=1"; }
        string qry = "select " + _colname + " from " + _table + " where " + _criteria;
        DataSet tmpDs = GetDataSet(qry);
        return tmpDs;
    }

    public bool IsUniqueValue(int value, string tableName, string fieldName)
    {
        string qry = "select " + fieldName + " from " + tableName + " where " + fieldName + "=" + value.ToString() + "";
        DataSet tmpDataSet = GetDataSet(qry);

        if ((tmpDataSet.Tables[0].Rows.Count == 0)) { tmpDataSet = null; return true; } else { tmpDataSet = null; return false; }
    }

    public bool IsUniqueValue(string value, string tableName, string fieldName)
    {
        zRaponSecurity sc = new zRaponSecurity();
        if (value.IndexOf("delete", StringComparison.CurrentCultureIgnoreCase) >= 0) return false;
        if (value.IndexOf("drop", StringComparison.CurrentCultureIgnoreCase) >= 0) return false;
        if (value.IndexOf("insert", StringComparison.CurrentCultureIgnoreCase) >= 0) return false;
        if (value.IndexOf("update", StringComparison.CurrentCultureIgnoreCase) >= 0) return false; ;

        value = sc.MakeInjectionSafeString(value);

        string qry = "select " + fieldName + " from " + tableName + " where " + fieldName + "='" + value + "'";
        DataSet tmpDataSet = GetDataSet(qry);

        if ((tmpDataSet.Tables[0].Rows.Count == 0)) { tmpDataSet = null; return true; } else { tmpDataSet = null; return false; }
    }

    public bool ExecuteQuery(string DBquery)
    {
        if (DBquery.IndexOf("drop", StringComparison.CurrentCultureIgnoreCase) >= 0) return false;

        try
        {
            SqlCommand Command = new SqlCommand(DBquery, Connection);
            if (Connection.State != ConnectionState.Open) Connection.Open();
            Command.ExecuteNonQuery();
            Connection.Close();
            return (true);
        }
        catch (SqlException Sqlexc)
        {
            // write Error to Log
            return (false);
        }


    }
}






