﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for SNodeActsProfile
/// </summary>
public class SNodeRolesProfile
{
    public List<int> CurrentActiveRoles;

    public List<NodeRoleRecord> NodeRolesHistory;

    public SNodeRolesProfile()
    {
        CurrentActiveRoles = new List<int>();
        NodeRolesHistory = new List<NodeRoleRecord>();
    }





    public class NodeRoleRecord
    {
        public int RoleCode; //from NodeRoleCodes class
        public int StartTime = 0;
        public int EndTime = -1;

        public void MandatoryInit(int startTime, int roleCode) //roleCode from class NodeRoleCodes
        {
            RoleCode = roleCode;
            StartTime = startTime;
        }
    }



    public void AddNewRole(NodeRoleRecord nrr)
    {
        int oldin = -1;
        try { oldin = CurrentActiveRoles.IndexOf(nrr.RoleCode); if (oldin >= 0) return; } catch (Exception e) { }
        CurrentActiveRoles.Add(nrr.RoleCode);
        NodeRolesHistory.Add(nrr);

    }
    public void AvailableRoleRemoveRole(NodeRoleRecord nrr)
    {
        int oldin = -1;
        try { oldin = CurrentActiveRoles.IndexOf(nrr.RoleCode); if (oldin >= 0) return; } catch (Exception e) { }
        CurrentActiveRoles.Remove(nrr.RoleCode);
        //----
        NodeRoleRecord t;
        for (int i = 0; i < NodeRolesHistory.Count; i++)
        {
            t = NodeRolesHistory[i];
            if ((t.RoleCode == nrr.RoleCode) && (t.EndTime == -1))
            {
                t.EndTime = nrr.EndTime;
                NodeRolesHistory[i] = t;
                return;
            }

        }



    }
    public static class NodeRoleCodes
    {
        public const int
            RelayData = 3,
            OfferResourcesForScheduling = 4,
            PerformSchedulingOnSelftAndOtherNodes = 5,
            ClusterHead = 6;




        public static string getActName(int RoleCode)
        {
            switch (RoleCode)
            {
                case RelayData:
                    return "RelayData";
                case OfferResourcesForScheduling:
                    return "OfferResourcesForScheduling"; // schedule tasks on itself
                case PerformSchedulingOnSelftAndOtherNodes:
                    return "PerformSchedulingOnOtherNodes";
                case ClusterHead:
                    return "ClusterHead";

            }
            return "";
        }

    }
}