﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

public class SMovementModel
{

    public static SLocationPoint GenerateNewLocation(int SimulationTime, Terrain terrain, double TargetMaxDistanceFromCurrent, SLocationPoint CurrentLocation)
    {
        int x= CurrentLocation.X, y=CurrentLocation.Y, z;
        CoUtils cu = new CoUtils();
        double distance = TargetMaxDistanceFromCurrent + 5;
        while (distance > TargetMaxDistanceFromCurrent)
        {
            int lim = Convert.ToInt32((2 / 3) * TargetMaxDistanceFromCurrent);
            int Xmin, Xmax, Ymin, Ymax;
            Xmin = Math.Max(terrain.GeoXmin, (CurrentLocation.X - lim));
            Xmax = Math.Min(terrain.GeoXmax, (CurrentLocation.X + lim));
            lim = Convert.ToInt32((2 / 3) * TargetMaxDistanceFromCurrent);
            Ymin = Math.Max(terrain.GeoYmin, (CurrentLocation.Y - lim));
            Ymax = Math.Min(terrain.GeoYmax, (CurrentLocation.Y + lim));

            x = cu.RandomNumber(Xmin, Xmax);
            y = cu.RandomNumber(Ymin, Ymax);
            distance = Math.Sqrt(x * x + y * y);
        }
        z = terrain.GetGeoZforXY(x, y);

        SLocationPoint TargetLocation = new SLocationPoint();
           TargetLocation.MandatoryInit (x, y, z);
        return TargetLocation;


    }



    public static void MoveNode(SLocationProfile currentLocation, SLocationPoint TargetLocaiton)
    {
        double speed, dirAngle, acceleration;
    }
}