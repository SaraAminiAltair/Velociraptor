﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Windows.Forms;

/// <summary>
/// Summary description for SHardwareComm
/// </summary>
public class Communication
{
    public string MAC;
    public bool isEnabled = false;

    public Communication()

    {

    }

    public static void TransmitPacket(int SimulationTime, int priority, DataPacketsQueues.SingleDataPacketQueue QueueFrom, DataPacketsQueues.SingleDataPacketQueue QueueTo, SimulationNodeStructure nodeStructure, ComputerNode ThisNode, DataPacket packet, ComputerNode targetNode, string notePrefix, int communicationMediumCode, SqlConnection sqlConn)
    {

        ThisNode.CountOfReceivedRequests++;
        ThisNode.ClusterInfo_Wifi.MyInfoToShareWithOhers.CountOfReceivedRequests = ThisNode.CountOfReceivedRequests;


        packet.TTL--;
        if (packet.TTL == 0)
        {


            packet.PacketChangeState(SimulationTime, packet.Priority, packet.CommunicationMediumCodeCurrent, DataPacket.PacketStatusCodes.Dropped, "Dropped because of" + " TTL is zero", packet.CurrntNodeID, packet.CurrntNodeID, QueueFrom, nodeStructure.DroppedPackets, sqlConn);
            return;
        }

        if (!targetNode.isNodeAlive)
        {

            packet.PacketChangeState(SimulationTime, packet.Priority, packet.CommunicationMediumCodeCurrent, DataPacket.PacketStatusCodes.Dropped, "Dropped because " + " target node is dead", packet.CurrntNodeID, packet.CurrntNodeID, QueueFrom, nodeStructure.DroppedPackets, sqlConn);
            return;

        }

        //------------------------------------------------------APPLYING FAILURE MODEL------------------------------------------------------
        //low-power data loss, speed based failures, and distance based packet loss are not considered. 
        //node inherent malfunction in network transfer is modeled.
        //node crash/recovery is not modeled.
        //note that as the probablity of failure has the notion of Union, we use plus operator to sum the probablities
        //First: Network failure
        SimulationConfiguration.NetworkProfile.NetworkFailureModel failureModel = nodeStructure.SimuConfig.networkProfile.networkFailureModel;
        double packetLostProbablity = 0;
        string netName = CommunicationMediumCodes.GetCommunicationMediumText(communicationMediumCode);
        switch (communicationMediumCode)
        {
            case CommunicationMediumCodes.Cellular3G:
                packetLostProbablity = failureModel.ProbablityOfCellularLostPacket;
                break;
            case CommunicationMediumCodes.WiFi:
                packetLostProbablity = failureModel.ProbablityOfWifiLostPacket;
                break;
            case CommunicationMediumCodes.Bluetooth:
                packetLostProbablity = failureModel.ProbablityOfBluetoothLostPacket;
                break;
        }
        //Second: Node inherent failure
        packetLostProbablity += ThisNode.HardwareProfile.NodePacketLossProbablityDueToMalfuntionInHWorSW;

        //Finally: Apply random factor
        double p = (new CoUtils()).RandomNumber(0.0, 0.9999);
        if (p <= packetLostProbablity)
        {
            ThisNode.ActionForPackets += "Lost packet due to internal network failure or environmental impacts. ";
            packet.PacketStatusCode = DataPacket.PacketStatusCodes.Lost;
            packet.PacketChangeState(SimulationTime, packet.Priority, packet.CommunicationMediumCodeCurrent, packet.PacketStatusCode, "Lost because network(" + netName + ") failure. This maybe because of network or maybe the node network hardware error.", ThisNode.NodeID, targetNode.NodeID, QueueFrom, nodeStructure.DroppedPackets, sqlConn);
            return;
        }

        //--------------------------------------------------------------------------------------------------------------------------------------



        int sendOrReceiveCode = 1; //1 for send and 2 for receive
        //energy send
        {
            NodeHardwareProfile.HardwarePowerSupply.EnergyUsageNote energyeNote = new NodeHardwareProfile.HardwarePowerSupply.EnergyUsageNote();
            energyeNote.Cause = "Send," + CommunicationMediumCodes.GetCommunicationMediumText(communicationMediumCode) + "," + notePrefix + ",info:" + packet.GetInfo();
            energyeNote.EnergyAmountUsed = CalcuateEnergyRequiredToSendReceivePacket_inJouls(packet, communicationMediumCode, sendOrReceiveCode);
            energyeNote.Time = SimulationTime;
            ThisNode.HardwareProfile.PowerSupplyProfile.ConsumeEnergy(energyeNote);
        }
        //energy receive
        {
            sendOrReceiveCode = 2;// for receive
            NodeHardwareProfile.HardwarePowerSupply.EnergyUsageNote energyeNote = new NodeHardwareProfile.HardwarePowerSupply.EnergyUsageNote();
            energyeNote.Cause = "Receive," + CommunicationMediumCodes.GetCommunicationMediumText(communicationMediumCode) + "," + notePrefix + ",info:" + packet.GetInfo();
            energyeNote.EnergyAmountUsed = CalcuateEnergyRequiredToSendReceivePacket_inJouls(packet, communicationMediumCode, sendOrReceiveCode);
            energyeNote.Time = SimulationTime;
            targetNode.HardwareProfile.PowerSupplyProfile.ConsumeEnergy(energyeNote);
        }
        ThisNode.CountOfSuccessfullyTransferedRequests++;
        ThisNode.ClusterInfo_Wifi.MyInfoToShareWithOhers.CountOfSuccessfullyTransferedRequests = ThisNode.CountOfSuccessfullyTransferedRequests;
        packet.Trace += "," + targetNode.NodeID;
        packet.PacketChangeState(SimulationTime, priority, communicationMediumCode, DataPacket.PacketStatusCodes.InTravel, "", ThisNode.NodeID, targetNode.NodeID, QueueFrom, QueueTo, sqlConn);

    }
    public static decimal CalcuateEnergyRequiredToSendReceivePacket_inJouls(DataPacket packet, int communicationMediumCode, int sendOrReceive)
    {
        //sendOrReceive==1    ->  means send
        //sendOrReceive==2    ->  means receive
        //  based on Kalic Energy Model
        // Reference: https://ieeexplore.ieee.org/document/6240745
        //* On WiFi:         for one MB=> download or upload takes 2.6 Jouls                    bitrate => download: 2 MB / s, upload: 2 MB / s
        //* On 3G:          for one MB=> download takes 5.4 Jouls, upload takes 11.6 Jouls     bitrate => download: 0.9 MB / s, upload: 0.17 MB / s
        //* On BlueTooth:   for one MB=> download takes 4 Jouls  and upload  takes 2.7Jouls     bitrate => download 0.12 MB / s, upload 0.14 MB / s


        decimal EnergyWeight = 0;
        switch (communicationMediumCode)
        {
            case CommunicationMediumCodes.Cellular3G:
                if (sendOrReceive == 1)//send energy
                    EnergyWeight = 11.6m;
                else EnergyWeight = 5.4m;
                break;
            case CommunicationMediumCodes.Bluetooth:
                if (sendOrReceive == 1)//send energy
                    EnergyWeight = 2.7m;
                else EnergyWeight = 4m;
                break;
            case CommunicationMediumCodes.WiFi: //send and receive energy weight are equal in wifi
                EnergyWeight = 2.6m;

                break;
        }
        decimal requiredEnergy = (decimal)((((decimal) packet.SizeInKB) / 1024.0m) * EnergyWeight); //packet size should be in Mega Bytes
        return requiredEnergy;
    }

    public static class CommunicationMediumCodes
    {
        public const int WiFi = 1, Ethernet = 2, Bluetooth = 3, Cellular3G = 4;
        public static string GetCommunicationMediumText(int CommunicationMediumCode)
        {
            switch (CommunicationMediumCode)
            {
                case WiFi:
                    return "WiFi";
                case Ethernet:
                    return "Ethernet";
                case Bluetooth:
                    return "Bluetooth";
                case Cellular3G:
                    return "Cellular3G";
            }
            return "UNKNOWN";
        }
    }

    public int GetEuclideanDistance(ComputerNode FirstNode, ComputerNode SecondNode)
    {
        int x1, x2, y1, y2, z1, z2;
        x1 = FirstNode.LocationProfile.LocationCurrent.LocationPoint.X;
        x2 = SecondNode.LocationProfile.LocationCurrent.LocationPoint.X;
        y1 = FirstNode.LocationProfile.LocationCurrent.LocationPoint.Y;
        y2 = SecondNode.LocationProfile.LocationCurrent.LocationPoint.Y;
        z1 = FirstNode.LocationProfile.LocationCurrent.LocationPoint.Z;
        z2 = SecondNode.LocationProfile.LocationCurrent.LocationPoint.Z;

        double x = Math.Sqrt(Math.Pow((x1 - x2), 2) + Math.Pow((y1 - y2), 2) + Math.Pow((z1 - z2), 2));
        return (Convert.ToInt32(x));
    }





}


public class WiFi : Communication
{
    public static int RangeToBeConsideredAsNeighbor = 150; // meters

    public WiFi()
    {
        //
        // TODO: Add constructor logic here
        //
    }

    public NeighborsTable GetNeighborsTable(ComputerNode thisNode, List<ComputerNode> ListOfNodes)
    {
        NeighborsTable nt = new NeighborsTable();
        nt.NodeID = thisNode.NodeID;
        foreach (ComputerNode subjectNode in ListOfNodes)
        {
            if (subjectNode.NodeID == thisNode.NodeID) continue;
            int d = GetEuclideanDistance(thisNode, subjectNode);
            if (d <= RangeToBeConsideredAsNeighbor)
            {
                NeighborInfo nifo = new NeighborInfo();
                nifo.DistanceToNeighbor = d;
                NodeInfoForClustering neighborInfoForClustering = subjectNode.ClusterInfo_Wifi.MyInfoToShareWithOhers.GetCopy();
                nifo.NodeInfo = neighborInfoForClustering;
                nt.Neighbors.Add(nifo);
            }
        }


        return nt;
    }





}




public class Ethernet : Communication
{
    public Ethernet()
    {
        //
        // TODO: Add constructor logic here
        //
    }
}

public class Cellular : Communication
{
    public static void DispachAllPacketsFromAbstractNode(SqlConnection sqlConn, SimulationNodeStructure nodeStruct, int simTime)
    {
        ComputerNode AbstractCellularInfraNode = nodeStruct.Cellular3GInfrastructureAbstractNode;
        DataPacketsQueues.SingleDataPacketQueue AbstractCellularInfraQueueIn = AbstractCellularInfraNode.DataPacketQueues_Cellular3G.QueIn;
        while (AbstractCellularInfraQueueIn.Queue.Count > 0)
        {
            //if target node is a member of a cluster-head, then the packet should be sent to its cluster head, otherwise the packet should be direclty delivered to target node.
            //currently only direct-throughcellular will be used (there are some limitations for example fog and cloud servers are not directly reachable through cellular
            DataPacket packet = AbstractCellularInfraQueueIn.Queue[0];
            ComputerNode TargetNode = SimulationNodeStructure.GetNodeByID(packet.TargetNodeID, nodeStruct.Nodes);
            Communication.TransmitPacket(simTime,
                                        packet.Priority, AbstractCellularInfraQueueIn  //from queue
                                        , TargetNode.DataPacketQueues_Cellular3G.QueIn //to queue
                                        , nodeStruct
                                        , AbstractCellularInfraNode //sender is the infra
                                        , packet
                                        , TargetNode
                                        , ""
                                        , Communication.CommunicationMediumCodes.Cellular3G
                                        , sqlConn);

        }
    }

}

public class Bluetooth : Communication
{

}

public class DataPacket
{
    public int SizeInKB;
    public string OriginNodeID, TargetNodeID, CurrntNodeID;
    public int CreationTime;
    public int TTL;
    public int CommunicationMediumCodeCurrent;// from CommunicationMediumCodes class
    public int PacketStatusCode = PacketStatusCodes.InQueueOriginalSender;
    public int LastStatusTime;
    public int PacketID_inDB;
    public int PacketID;
    public int Priority;
    public int FinishTime;
    public string Trace = "";//as a csv string. This shows the travel path of the packet.
    public string GetInfo()
    {
        string s = "SizeInKB:" + SizeInKB.ToString();
        s = s + ",status:" + PacketStatusCodes.GetStatusCodeText(this.PacketStatusCode);
        s = s + ",TTL" + TTL.ToString();
        s = s + ",CommunicationMediumCurrent" + Communication.CommunicationMediumCodes.GetCommunicationMediumText(this.CommunicationMediumCodeCurrent);
        s = s + ",OriginNodeID" + this.OriginNodeID;
        s = s + ",TargetNodeID" + this.TargetNodeID;
        s = s + ",CurrntNodeID" + this.CurrntNodeID;
        s = s + ",CreationTime" + this.CreationTime;
        s = s + ",Priority" + this.Priority;

        return s;
    }



    public void PacketChangeState(int simulationTime, int priority, int currentMediumCode, int packetNewState, string note, string SenderNodeID, string ReceiverNodeID, DataPacketsQueues.SingleDataPacketQueue CurrentQueue, DataPacketsQueues.SingleDataPacketQueue TargetQueue, SqlConnection sql)
    {
        if ((packetNewState == PacketStatusCodes.Dropped) || (packetNewState == PacketStatusCodes.DeliveredSuccess) || (packetNewState == PacketStatusCodes.DeliveredWithErr) || (packetNewState == PacketStatusCodes.Lost))
        {
            this.FinishTime = simulationTime;
        }
        int oldState = this.PacketStatusCode;
        this.PacketStatusCode = packetNewState;
        this.LastStatusTime = simulationTime;
        this.CommunicationMediumCodeCurrent = currentMediumCode;
        this.CurrntNodeID = ReceiverNodeID;
        CurrentQueue.Queue.Remove(this);
        TargetQueue.Queue.Add(this);
        this.Priority = priority;

        try
        {


            if ((sql == null)) return;
            if (sql.State != ConnectionState.Open) sql.Open();
            using (SqlCommand cmd = new SqlCommand("SP_PacketStateChange", sql))
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@Time", SqlDbType.Int).Value = simulationTime;
                cmd.Parameters.Add("@PacketID", SqlDbType.Int).Value = this.PacketID;
                cmd.Parameters.Add("@PacketID_inDB", SqlDbType.Int).Value = this.PacketID_inDB;
                cmd.Parameters.Add("@CurrentNetworkMedium", SqlDbType.NVarChar).Value = Communication.CommunicationMediumCodes.GetCommunicationMediumText(currentMediumCode);
                cmd.Parameters.Add("@NodeIDSent", SqlDbType.NVarChar).Value = SenderNodeID;
                cmd.Parameters.Add("@NodeIDOrigin", SqlDbType.NVarChar).Value = this.OriginNodeID;
                cmd.Parameters.Add("@NodeIDTarget", SqlDbType.NVarChar).Value = this.TargetNodeID;
                cmd.Parameters.Add("@NodeIDReceive", SqlDbType.NVarChar).Value = ReceiverNodeID;
                cmd.Parameters.Add("@PacketStatusNew", SqlDbType.NVarChar).Value = PacketStatusCodes.GetStatusCodeText(packetNewState);
                cmd.Parameters.Add("@PacketStatusOld", SqlDbType.NVarChar).Value = PacketStatusCodes.GetStatusCodeText(oldState);
                cmd.Parameters.Add("@Priority", SqlDbType.Int).Value = this.Priority;
                cmd.Parameters.Add("@TTL", SqlDbType.Int).Value = this.TTL;
                cmd.Parameters.Add("@Note", SqlDbType.NVarChar).Value = note;
                cmd.Parameters.Add("@Trace", SqlDbType.NVarChar).Value = this.Trace;





                cmd.ExecuteNonQuery();

            }
        }
        catch (Exception e)
        {
            System.Threading.Thread.Sleep(4000);
            //MessageBox.Show("Error in Logging Packet State Change." + Environment.NewLine + Environment.NewLine + e.ToString());

        }
    }
    public void DataPacket_MandatoryInit(ComputerNode OriginNode, int packetID, int priority, int _SizeInMB, string _TargetNodeID, int _CreationTime, int _TTL, SqlConnection SqlConn)  // _CommunicationMediumCodeOfOrigin is from SHardwareComm.CommunicationMediumCodes class
    {
        this.SizeInKB = _SizeInMB;
        this.OriginNodeID = this.CurrntNodeID = OriginNode.NodeID;
        this.TargetNodeID = _TargetNodeID;
        this.TTL = _TTL;
        this.CreationTime = _CreationTime;
        this.PacketID = packetID;
        this.Priority = priority;
        try
        {


            if ((SqlConn == null)) return;
            if (SqlConn.State != ConnectionState.Open) SqlConn.Open();
            using (SqlCommand cmd = new SqlCommand("SP_PacketInit", SqlConn))
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@PacketID", SqlDbType.Int).Value = this.PacketID;
                cmd.Parameters.Add("@OwnerNodeID", SqlDbType.NVarChar).Value = this.OriginNodeID;
                cmd.Parameters.Add("@TargetNodeID", SqlDbType.NVarChar).Value = this.TargetNodeID;
                cmd.Parameters.Add("@CreationTime", SqlDbType.Int).Value = this.CreationTime;
                cmd.Parameters.Add("@TTL", SqlDbType.Int).Value = this.TTL;
                cmd.Parameters.Add("@Priority", SqlDbType.Int).Value = this.Priority;
                cmd.Parameters.Add("@SizeInKB", SqlDbType.Int).Value = this.SizeInKB;


                var PacketID_InDB = cmd.Parameters.Add("@ReturnVal", SqlDbType.Int);
                PacketID_InDB.Direction = ParameterDirection.ReturnValue;
                cmd.ExecuteNonQuery();
                this.PacketID_inDB = Convert.ToInt32(PacketID_InDB.Value);
            }
        }
        catch (Exception e)
        {
            System.Threading.Thread.Sleep(4000);

   //         MessageBox.Show("Error in Logging Packet Initialization" + Environment.NewLine + Environment.NewLine + e.ToString());

        }
    }


    public static class PacketStatusCodes
    {
        public static int InQueueOriginalSender = 0, InTravel = 1,

          Dropped = 2,
          Lost = 3,
          DeliveredSuccess = 4,
          DeliveredWithErr = 5;

        public static String GetStatusCodeText(int statusCode)
        {

            switch (statusCode)
            {
                case 0:
                    return "InQueueOriginalSender";

                case 1:
                    return "InTravel";

                case 2:
                    return "Dropped";
                case 3:
                    return "Lost";
                case 4:
                    return "DeliveredSuccess";
                case 5:
                    return "DeliveredWithErr";
            }
            return "UNKNOWN";
        }
    }



}

