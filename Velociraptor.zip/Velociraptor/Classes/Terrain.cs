﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

public class Terrain
{
    public int GeoXmin, GeoXmax, GeoYmin, GeoYmax, GeoZmin, GeoZmax;
    public int SpeedMaxAllowed, SpeedMinAllowed;
    public Terrain(SimulationConfiguration.TerrainSpec spec)
    {
        this.GeoXmin = spec.GeoXmin;
        this.GeoXmax = spec.GeoXmax;
        this.GeoYmin = spec.GeoYmin;
        this.GeoYmax = spec.GeoYmax;
        this.GeoZmin = spec.GeoZmin;
        this.GeoZmax = spec.GeoZmax;
        this.SpeedMaxAllowed = spec.SpeedMaxAllowed;
        this.SpeedMinAllowed = spec.SpeedMinAllowed;

    }

    public int GetGeoZforXY(int x, int y)
    {
        return ((new CoUtils()).RandomNumber(GeoZmin, GeoZmax));
    }
}
