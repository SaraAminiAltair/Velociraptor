﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for SNodeHardwareProfile
/// </summary>
public class NodeHardwareProfile
{
    //comm devices should be set as isenabled=true if desired.

    public int NodeTypeCode; //from class NodeTypes
    public List<Communication> NetworkHardwaresProfile;
    public HardwareComputer ComputerHardwareProfile;
    public HardwarePowerSupply PowerSupplyProfile;


    public double NodePacketLossProbablityDueToMalfuntionInHWorSW = 0;
    public string NodeDeviceName;//e.g. "iPhone XS"


    public Communication getCommDevice(int commDeviceType) //from Communication.CommunicationMediumCodes
    {

        Communication n = new WiFi(); //as default case
        switch (commDeviceType)
        {

            case Communication.CommunicationMediumCodes.WiFi:
                n = new WiFi();
                break;
            case Communication.CommunicationMediumCodes.Cellular3G:
                n = new Cellular();
                break;
            case Communication.CommunicationMediumCodes.Bluetooth:
                n = new Bluetooth();
                break;
            case Communication.CommunicationMediumCodes.Ethernet:
                n = new Ethernet();
                break;
        }
        foreach (Communication c in NetworkHardwaresProfile)
        {
            //if (c.GetType() == typeof())
            if (c.GetType() == n.GetType())
            {
                return c;
            }


        }
        return NetworkHardwaresProfile[0];

    }

    public void MandatoryInit(int nodeTypeCode, HardwarePowerSupply _PowerSupply, HardwareComputer _Computer, string _NodeDeviceName, double nodePacketLossProbablityDueToMalfuntionInHWorSW)
    {
        this.NodePacketLossProbablityDueToMalfuntionInHWorSW = NodePacketLossProbablityDueToMalfuntionInHWorSW;
        NodeDeviceName = _NodeDeviceName;
        NodeTypeCode = nodeTypeCode;
        PowerSupplyProfile = _PowerSupply;
        ComputerHardwareProfile = _Computer;
        NetworkHardwaresProfile = new List<Communication>();
        NetworkHardwaresProfile.Add(new Bluetooth());
        NetworkHardwaresProfile.Add(new WiFi());
        NetworkHardwaresProfile.Add(new Ethernet());
        NetworkHardwaresProfile.Add(new Cellular());

    }



    public static class NodeTypes
    {
        public static int IoTNode = 1
            , Host_InFogPoint = 2
            , Host_InCloudDataCenter = 3
            , Host_InSingleIsland = 4;


        public static string getNodeTypeAsText(int _NodeTypeCode)
        {
            switch (_NodeTypeCode)
            {
                case 1:
                    return "IoTNode";
                case 2:
                    return "Host_InFogPoint";
                case 3:
                    return "Host_InCloudDataCenter";
                case 4:
                    return "Host_InSingleIsland";

            }
            return "?";
        }

    }



    public class HardwareComputer
    {

        public CPU CPUProfile;
        public HardwareStorage StorageProfile;
        public int Ram_free;//in MB

        public void MandatoryInit(CPU _CPU, int _RAM, HardwareStorage _Storage)
        {
            CPUProfile = _CPU;
            StorageProfile = _Storage;
            Ram_free = _RAM;
        }
        public class CPU
        {
            public class WorkSlotMap
            {
                private int CpuMips;
                public void SetCpuMips(int cpuMips)
                {
                    CpuMips = cpuMips;
                }
                public List<WorkSlot> Slots;
                public bool IsSlotAvailable(int startTime, Int64 millionInstructions, out int beforeGapTime, out int afterGapTime)
                {
                    beforeGapTime = -1;//No BEFORE busy-slot
                    afterGapTime = -1;//No AFTER busy-slot
                    //perfect fit
                    return true;

                }

                private int CalculateReservedTimeLengthForTaskExecution(Job.DagInnerNode theTask, int startTime)
                {
                    double TL = Math.Ceiling((double)theTask.CpuNeed_Claimed / CpuMips);
                    double tolerance = startTime - Math.Min(startTime + TL + (TL * 0.1), theTask.TimeDeadlineFinal);
                    TL = TL + tolerance; //Tasklength with conservative tolerance 
                    int TaskLength = Convert.ToInt32(TL);
                    return TaskLength;

                }
                public bool AddToWorkSlotMap(Job.DagInnerNode theTask, int startTime, int ReservationTypeCode//from SlotReservationType
                     )
                {
                    int beforeGap = -2, afterGap = -2; // -2 means not calculated yet
                    bool x = IsSlotAvailable(startTime, theTask.CpuNeed_Claimed, out beforeGap, out afterGap);
                    if (!x) return false;
                    WorkSlot ws = new WorkSlot();
                    ws.SlotStatus = WorkSlot.SlotStatusCodes.Reserved;
                    ws.TheTask = theTask;
                    ws.TimeStart = startTime;
                    ws.TimeEnd = startTime + CalculateReservedTimeLengthForTaskExecution(theTask, startTime);
                    Slots.Add(ws);
                    return true;
                }


                public class WorkSlot
                {
                    public int TimeStart, TimeEnd;
                    public Job.DagInnerNode TheTask;
                    public int SlotStatus;//from Class WorkSlot.SlotStatusCodes
                    public int SlotReservationType;//from Class WorkSlot.SlotReservationTypes
                    public class SlotStatusCodes
                    {
                        public static readonly Int16 TaskDone = 1, Reserved = 2, Cancelled = 3;
                    }
                    public class SlotReservationTypes
                    {
                        public static readonly Int16 Determined = 1, SoftReserve = 2;
                    }
                }

            }

            public WorkSlotMap CPUWorkSlotMap = new WorkSlotMap();




            public int CPUMinMIPS, CPUMaxMIPS, CPUCurrentMIPS_hardware;
            bool supportFlexibleFrequency;
            public bool isIdle = false;
            public void MandatoriInit(int _CPUMinMIPS, int _CPUMaxMIPS, bool _supportFlexibleFrequency)
            {
                supportFlexibleFrequency = _supportFlexibleFrequency;
                CPUMinMIPS = _CPUMinMIPS;
                CPUMaxMIPS = _CPUMaxMIPS;
                CPUCurrentMIPS_hardware = _CPUMaxMIPS;
            }
        }
        public class HardwareStorage
        {
            // For Hard Disk Drive
            public float HDDFree;//,  HDD_hardware; //in MB   
            public float HDDReadPerSec, HDDWritePerSec;//in MB
                                                       // For SSD
            public float SDDFree, SDD_hardware; //in MB
            public float SDDReadPerSec, SDDWritePerSec;//in MB

            public float NVMeFree, NVMe_hardware; //in MB
            public float NVMeReadPerSec, NVMeWritePerSec;//in MB

            //for Memory Card
            public float MMCFree, MMC_hardware; //in MB
            public float MMCReadPerSec, MMCWritePerSec;//in MB
            public void MandatoryInit(float _HDDFree, float _SDDFree, float _MMCFree, float _NVMeFree)
            {
                HDDFree = _HDDFree;
                SDDFree = _SDDFree;
                MMCFree = _MMCFree;
                NVMeFree = _NVMeFree;

            }
            public string getStorageHardwareAsText()
            {
                return string.Format("HDD:{0},SDD:{1},MMC:{2},NVMe:{3}", HDDFree.ToString(), SDDFree.ToString(), MMCFree.ToString(), NVMeFree.ToString());
            }
        }
        public static HardwareComputer Typical(int DeviceCode)
        {

            int cpumips = 1;
            int storageHDD = 0;
            int storageMMC = 0;
            int storageSDD = 0;
            int storageNVMe = 0;

            int ram = 1;
            switch (DeviceCode)
            {
                case DeviceCodes.CellularBTS://this information is not important for CellulatBTS
                    cpumips = 18200;
                    storageSDD = 16 * 1024; //16 GB
                    ram = 1024;//1GB
                    break;

                case DeviceCodes.iphone5:
                    cpumips = 18200;
                    storageSDD = 16 * 1024; //16 GB
                    ram = 1024;//1GB
                    break;
                case DeviceCodes.iPad4:
                    cpumips = 75000;
                    ram = 1024;//1GB
                    storageSDD = 64 * 1024; //16 GB
                    break;
                case DeviceCodes.samsungS6:
                    cpumips = 21000;
                    ram = 3 * 1024;//3 GB
                    storageSDD = 32 * 1024; //16 GB
                    break;
                case DeviceCodes.iphone8:
                    cpumips = 24000;
                    ram = 3 * 1024;//3GB
                    storageSDD = 64 * 1024; //16 GB


                    break;
                case DeviceCodes.samsungS8:
                    cpumips = 29000;
                    ram = 4 * 1024;//4 GB
                    storageSDD = 64 * 1024; //16 GB

                    break;
                case DeviceCodes.iphoneX:
                    cpumips = 70000;
                    ram = 3 * 1024;//3 GB
                    storageSDD = 64 * 1024; //16 GB

                    break;
                case DeviceCodes.RPi2OnBattery:
                case DeviceCodes.RPi2OnGrid:

                    ram = 1024;//1 GB
                    cpumips = 9700;
                    storageMMC = 16 * 1024; //16 GB

                    break;

                case DeviceCodes.serverCorei7_8086:
                    cpumips = 221000;
                    ram = 16 * 1024;//1 GB
                    storageSDD = 4 * 1024 * 1024; //8 TB

                    break;
                case DeviceCodes.serverCorei9_9900:
                    cpumips = 412000;
                    ram = 64 * 1024;//64 GB
                    storageSDD = 8 * 1024 * 1024; //8 TB
                    storageNVMe = 512 * 1024;//512 GB
                    break;
                case DeviceCodes.serverAMDRyzen9:
                    cpumips = 749700;
                    ram = 96 * 1024;//96 GB
                    storageSDD = 32 * 1024 * 1024; //32 TB
                    storageNVMe = 2 * 1024 * 1024;//2 TB
                    break;
                case DeviceCodes.serverAMDRyzenThreadripper:
                    cpumips = 2356000;
                    ram = 512 * 1024;//512 GB
                    storageSDD = 1028 * 1024 * 1024; //1028 TB
                    storageNVMe = 32 * 1024 * 1024;//8 TB
                    break;
            }


            HardwareStorage storage = new HardwareStorage();
            storage.MandatoryInit(storageHDD, storageSDD, storageMMC, storageNVMe);
            CPU cpu = new CPU();
            cpu.MandatoriInit(cpumips, cpumips, false);
            HardwareComputer c = new HardwareComputer();
            c.MandatoryInit(cpu, ram, storage);
            return c;

        }
    }
    public class HardwarePowerSupply
    {
        public static class PowerSupplyType
        {
            public static int Battery = 1
                , Grid = 2
                , SolarWithBattery = 3;
            public static string getPowerSupplyTypeAsText(int PowerSuplyTypeCode)
            {
                switch (PowerSuplyTypeCode)
                {
                    case 1: return "Battery";
                    case 2: return "Grid";
                    case 3: return "SolarWithBattery";
                }
                return "?";
            }
        }

        public int PowerType; //should set according to class "PowerSupplyType"

        public decimal EnergyCurrent;
        public decimal EnergyStart;
        public List<EnergyUsageNote> EnergyConsumptionLog = new List<EnergyUsageNote>();

        public class EnergyUsageNote
        {
            public decimal EnergyAmountUsed;
            public int Time;
            public string Cause;
        }


        public void ConsumeEnergy(EnergyUsageNote energyUsageNote)
        {
            EnergyConsumptionLog.Add(energyUsageNote);
            if (this.PowerType == PowerSupplyType.Battery)
            {
              decimal  _EnergyCurrent = Math.Max(0, EnergyCurrent - energyUsageNote.EnergyAmountUsed);//device will be turned off when nodes check the current energy
                

                EnergyCurrent = _EnergyCurrent;
                //zz write to Database??
            }

        }

        public void MandatoryInit(int powerSupplyType, decimal energyStart)
        {
            PowerType = powerSupplyType;
            EnergyStart = EnergyCurrent = energyStart;
        }

        public static HardwarePowerSupply Typical(int DeviceCode)
        {
            int powertype = PowerSupplyType.Battery;
            decimal startEnergy = 39.600m;
            switch (DeviceCode)
            {


                
                case DeviceCodes.iphone5:
                    startEnergy = 5400;
                    break;
                case DeviceCodes.iPad4:
                    startEnergy = 153000;
                    break;
                case DeviceCodes.samsungS6:
                    startEnergy = 34000;
                    break;
                case DeviceCodes.iphone8:
                    startEnergy = 24000;
                    break;
                case DeviceCodes.samsungS8:
                    startEnergy = 41000;
                    break;
                case DeviceCodes.iphoneX:
                    startEnergy = 37000;
                    break;
                case DeviceCodes.RPi2OnBattery:
                    startEnergy = 5400;
                    break;
                case DeviceCodes.RPi2OnGrid:
                case DeviceCodes.serverCorei7_8086:
                case DeviceCodes.serverCorei9_9900:
                case DeviceCodes.serverAMDRyzen9:
                case DeviceCodes.serverAMDRyzenThreadripper:
                case DeviceCodes.CellularBTS:
                    powertype = PowerSupplyType.Grid;
                    startEnergy = 1000000;
                    break;
            }

            HardwarePowerSupply ps = new HardwarePowerSupply();
            ps.MandatoryInit(powertype, startEnergy);
            return ps;
        }

    }



    public static NodeHardwareProfile TypicalGenerate(int DeviceCode, int NodeTypeCode, SimulationConfiguration.NetworkProfile netProfile)
    {
        NodeHardwareProfile hwp = new NodeHardwareProfile();

        // node inherent network malfunction probablity  (probablity of being flawed)
        double probPacketLossForFlawedNodes = 0;
        double p = (new CoUtils()).RandomNumber(0, 1);
        if (p <= netProfile.networkFailureModel.ProbablityOfNodesHasInherentNetworkMalfunction) probPacketLossForFlawedNodes = netProfile.networkFailureModel.ProbablityOfNodeWithMalfunctioningNetworkInterfaceLossesPackets;
        //
        hwp.MandatoryInit(NodeTypeCode, HardwarePowerSupply.Typical(DeviceCode), HardwareComputer.Typical(DeviceCode), GetDeviceNameBaseOnDeviceCode(DeviceCode), probPacketLossForFlawedNodes);
        return hwp;
    }

    public static string GetDeviceNameBaseOnDeviceCode(int deviceCode)
    {
        string deviceName = "";
        switch (deviceCode)
        {
            case DeviceCodes.CellularBTS:
                deviceName = "CellularBTS";
                break;

            case DeviceCodes.iphone5:
                deviceName = "iPhone5";
                break;
            case DeviceCodes.iPad4:
                deviceName = "iPad4";
                break;
            case DeviceCodes.samsungS6:
                deviceName = "SamsungS6";
                break;
            case DeviceCodes.iphone8:
                deviceName = "iPhone8";
                break;
            case DeviceCodes.samsungS8:
                deviceName = "samsungS8";
                break;
            case DeviceCodes.iphoneX:
                deviceName = "iPhoneX";
                break;
            case DeviceCodes.RPi2OnBattery:
                deviceName = "RPi2OnBattery";
                break;
            case DeviceCodes.RPi2OnGrid:
                deviceName = "RPi2OnGrid";
                break;
            case DeviceCodes.serverCorei7_8086:
                deviceName = "serverCorei7_8086";
                break;
            case DeviceCodes.serverCorei9_9900:
                deviceName = "serverCorei9_9900";
                break;
            case DeviceCodes.serverAMDRyzen9:
                deviceName = "serverAMDRyzen9";
                break;
            case DeviceCodes.serverAMDRyzenThreadripper:
                deviceName = "serverAMDRyzenThreadripper";
                break;

        }
        return deviceName;
    }

    public static class DeviceCodes
    {
        public const int CellularBTS = 1000;
        public const int iphone5 = 1, samsungS6 = 2, iphone8 = 3, samsungS8 = 4, iphoneX = 5;
        public const int iPad4 = 101;
        public const int serverCorei7_8086 = 20, serverCorei9_9900 = 21;
        public const int serverAMDRyzen9 = 22, serverAMDRyzenThreadripper = 23;

        public const int RPi2OnBattery = 40, RPi2OnGrid = 41;



    }



}