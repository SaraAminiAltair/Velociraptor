﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


public class SimulationConfiguration
{

    public int cpuBaseLineMIPS;
    public CloudSpec cloudSpec;
    public FogSpec fogSpec;
    public IoTSpec ioTSpec;
    public TerrainSpec terrainSpec;
    public JobGenerationSpec jobGenerationProfile;
    public int simulationMaxStep;
    public NetworkProfile networkProfile;
    public     int TransmitAlgorithm; //from class TransmitAlgorithms
    public class NetworkProfile
    {
        public int PercentOfNodesWhichGenerateDataInEachStep;
        public int CountOfPacketsToBeGeneratedByNode;
        public int PacketSizeMin_inKB, PacketSizeMax_inKB;
        public int TTL_of_Start = 10;// in TCP/IP it usually assumed: TTL=64
        public int PriorityMin, PriorityMax;
        public NetworkFailureModel networkFailureModel = new NetworkFailureModel();
        public int DataTransferMaxLimitForScoreCalculation_inKB;//in Mega Bytes. Used for normalization in score calculation algorithm
        public int DataTransferAging_inKB = 50;// In Kilo Bytes. Amount to decrease (aging) from the data transered field of node (which is used for score calculation)
        public ClusteringWifiProfile clusteringWifiProfile = new ClusteringWifiProfile();
        public class NetworkFailureModel
        {
            //reference for these values can be obtained from 
            //      D. Baltrunas, A. Elmokashfi, A. Kvalbein and Ö. Alay, "Investigating packet loss in mobile broadband networks under mobility," 2016 IFIP Networking Conference (IFIP Networking) and Workshops, Vienna, 2016, pp. 225-233, doi: 10.1109/IFIPNetworking.2016.7497225.
            //      doi: 10.1109/IFIPNetworking.2016.7497225
            public double ProbablityOfWifiLostPacket = 0.04;
            public double ProbablityOfCellularLostPacket = 0.15;
            public double ProbablityOfBluetoothLostPacket = 0.03;

            public double ProbablityOfCellularInfrastructureLossPacket_InsideSystem;
            public double ProbablityOfNodesHasInherentNetworkMalfunction;
            public double ProbablityOfNodeWithMalfunctioningNetworkInterfaceLossesPackets;

        }

        public class ClusteringWifiProfile
        {

            public int MaximumAllowableClusterHeadMemberCount = 5;

        }



    }

    SimulationConfiguration(int _SimulationMaxStep,int _TransmitAlgorithm, int _CpuBaseLineMIPS, CloudSpec _cloudSpec, FogSpec _fogSpec, IoTSpec _ioTSpec, TerrainSpec _terrainSpec, JobGenerationSpec _jobGenerationProfile, NetworkProfile _networkprofile)
    {
        this.networkProfile = _networkprofile;
        this.cpuBaseLineMIPS = _CpuBaseLineMIPS;
        this.cloudSpec = _cloudSpec; fogSpec = _fogSpec;
        this.ioTSpec = _ioTSpec;
        this.terrainSpec = _terrainSpec;
        this.jobGenerationProfile = _jobGenerationProfile;
        this.simulationMaxStep = _SimulationMaxStep;
        this.TransmitAlgorithm = _TransmitAlgorithm;
    }


    public class TerrainSpec
    {
        public int GeoXmin, GeoXmax, GeoYmin, GeoYmax, GeoZmin, GeoZmax;
        public int SpeedMaxAllowed, SpeedMinAllowed;
    }

    public class JobGenerationSpec
    {
        public int CountOfDags;
        public int CountOfTasksInDagMin, CountOfTasksInDagMax;
        public int TasksCPUNeedMin, TasksCPUNeedMax, TasksMemNeedMin, TasksMemNeedMax, TasksStorageNeedMin, TasksStorageNeedMax, MaxCountOfResourcesEachTaskMayNeed;
        public double Connectivity;
        public double TimeDeadlineFinalPercentageFromTaskSize, TimeDeadLinePreferedPercentageFromTaskSize;
        public int EdgeWeightMin, EdgeWeightMax;
        public int[] NeededResourceTypes;
    }

    public class FogSpec
    {
        public int MinCountOfFogProviders, MaxCountOfFogProviders;
        public int MinCountOfFogProviderFogPoint, MaxCountOfFogProviderFogPoint;
        public int MinCountOfNodesInFogPointCluster, MaxCountOfNodesInFogPointCluster;

    }
    public class CloudSpec
    {
        public int MinCountOfCloudProviders, MaxCountOfCloudProviders;
        public int MinCountOfCloudProvidersDataCenters, MaxCountOfCloudProvidersDataCenters;
        public int MinCountOfClustersInDataCenter, MaxCountOfClustersInDataCenter;
        public int MinCountOfNodesInDCCluster, MaxCountOfNodesInDCCluster;

    }

    public class IoTSpec
    {
        public int CountOfIoTNodes;


    }


    public static class TransmitAlgorithms
        {
        public static int esf = 1, DFSCA = 2, SBCA = 3, WCA = 4, Cell = 5,Parto=6;
        }

    public static SimulationConfiguration ExperimentOneSpecs(int CpuBaseLineMIPS)
    {
        TerrainSpec terrainSpec = new TerrainSpec();        CloudSpec cloudSpec = new CloudSpec();        FogSpec fogSpec = new FogSpec();        IoTSpec ioTSpec = new IoTSpec();        JobGenerationSpec jobGenerationSpec = new JobGenerationSpec();

        int TransmitAlgorithm = TransmitAlgorithms.Parto;
        int SimulationSteps = 500;//   steps
        ioTSpec.CountOfIoTNodes = 50;
        
        terrainSpec.GeoXmax =170;                      terrainSpec.GeoZmax = 0; terrainSpec.GeoXmin = 0; terrainSpec.GeoYmin = 0; terrainSpec.GeoZmin = 0;
        terrainSpec.GeoYmax = 170;
        terrainSpec.SpeedMaxAllowed = 3;
        terrainSpec.SpeedMinAllowed = 2;
        
        NetworkProfile networkProfile = new NetworkProfile();
         networkProfile.clusteringWifiProfile.MaximumAllowableClusterHeadMemberCount = 30;
        networkProfile.PacketSizeMax_inKB = 5 * 1024;//  mega bytes
        networkProfile.PacketSizeMin_inKB = 4*1024;//   kilo byte
        networkProfile.CountOfPacketsToBeGeneratedByNode = 8;// no of packets 
        networkProfile.PercentOfNodesWhichGenerateDataInEachStep = 80;
        networkProfile.TTL_of_Start = 10;
        networkProfile.PriorityMin = 0;
        networkProfile.PriorityMax = 0;
        networkProfile.DataTransferMaxLimitForScoreCalculation_inKB = 100 * 1024; // 100  Mega bytes

        networkProfile.networkFailureModel.ProbablityOfCellularLostPacket = 0.09;
        networkProfile.networkFailureModel.ProbablityOfWifiLostPacket = 0.001;
        networkProfile.networkFailureModel.ProbablityOfNodesHasInherentNetworkMalfunction = 0.02;
        networkProfile.networkFailureModel.ProbablityOfNodeWithMalfunctioningNetworkInterfaceLossesPackets = 0.01;
        networkProfile.networkFailureModel.ProbablityOfCellularInfrastructureLossPacket_InsideSystem = 0.04;

       

        cloudSpec.MaxCountOfCloudProviders = 1;
        cloudSpec.MinCountOfCloudProviders = 1;
        cloudSpec.MaxCountOfCloudProvidersDataCenters = 1;
        cloudSpec.MinCountOfCloudProvidersDataCenters = 1;
        cloudSpec.MaxCountOfClustersInDataCenter = 1;
        cloudSpec.MinCountOfClustersInDataCenter = 1;
        cloudSpec.MaxCountOfNodesInDCCluster = 1;
        cloudSpec.MinCountOfNodesInDCCluster = 1;

        fogSpec.MaxCountOfFogProviderFogPoint = 1;
        fogSpec.MinCountOfFogProviderFogPoint = 1;
        fogSpec.MaxCountOfNodesInFogPointCluster = 1;
        fogSpec.MinCountOfNodesInFogPointCluster = 1;
        fogSpec.MaxCountOfFogProviders = 1;
        fogSpec.MinCountOfFogProviders = 1;


        jobGenerationSpec.CountOfDags = 1;
        jobGenerationSpec.CountOfTasksInDagMin = 2;
        jobGenerationSpec.CountOfTasksInDagMax = 3;
        jobGenerationSpec.TasksCPUNeedMin = Convert.ToInt32(Math.Ceiling((float)CpuBaseLineMIPS / 6)); // MI  a task is at least one second on baseline cpu
        jobGenerationSpec.TasksCPUNeedMax = CpuBaseLineMIPS * 200;// MI
        jobGenerationSpec.TasksMemNeedMin = 20;// MB
        jobGenerationSpec.TasksMemNeedMax = 4000;// MB
        jobGenerationSpec.TasksStorageNeedMin = 1;  // MB
        jobGenerationSpec.TasksStorageNeedMax = 400;// MB
        jobGenerationSpec.MaxCountOfResourcesEachTaskMayNeed = 2;
        jobGenerationSpec.Connectivity = 0.4;
        jobGenerationSpec.EdgeWeightMin = 2; //MB
        jobGenerationSpec.EdgeWeightMax = 80;//MB
        jobGenerationSpec.TimeDeadlineFinalPercentageFromTaskSize = 100;
        jobGenerationSpec.TimeDeadLinePreferedPercentageFromTaskSize = 80;
        int[] resTypes = { 110, 120, 125, 133, 155, 12, 22, 86 };
        jobGenerationSpec.NeededResourceTypes = resTypes;



        SimulationConfiguration simuConfig = new SimulationConfiguration(SimulationSteps,TransmitAlgorithm, CpuBaseLineMIPS, cloudSpec, fogSpec, ioTSpec, terrainSpec, jobGenerationSpec, networkProfile);
        return simuConfig;
    }



}
