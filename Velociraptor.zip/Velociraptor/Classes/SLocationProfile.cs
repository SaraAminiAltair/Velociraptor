﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for SLocationProfile
/// </summary>
public class SLocationProfile
{
    CoUtils cu = new CoUtils();
    public SLocation LocationCurrent;
    public List<SLocation> LocationHistory;
    public SLocationPoint Target;

    public int SpeedMax, SpeedMin;
    double reachTargetThreshold =10;
    public bool canMove;



    public int DistanceFromTarget;


    public static double DistanceTwoPoints(SLocationPoint d1, SLocationPoint d2)
    {
        double dist = Math.Sqrt(Math.Pow(Math.Abs(d1.X - d2.X), 2) + Math.Pow(Math.Abs(d1.Y - d2.Y), 2) + Math.Pow(Math.Abs(d1.Z - d2.Z), 2));
        return dist;
    }
    private bool TargetReached(double margin)
    {

        this.DistanceFromTarget = Convert.ToInt32(DistanceTwoPoints(Target, LocationCurrent.LocationPoint));
        if (this.DistanceFromTarget <= margin) return true; else return false;
    }
    public string MoveOneStep(Terrain terrain, int simulationTime)
    {
        string r = "";
        if (!canMove) return r;
        if (Target == null)
        {
            SLocationPoint p = getRandomLocationPoint(terrain, cu.RandomNumber(0, 5));
            Target = p;
            LocationCurrent.CurrentSpeed = cu.RandomNumber(SpeedMin, SpeedMax);// ;
            r = "NoTarget,NewTargetSelected,";
        }


        if (TargetReached(reachTargetThreshold))
        {
            r = r + "TargetReached,";
            bool x = WaitHere();
            if (!x)
            {
                SLocationPoint p = getRandomLocationPoint(terrain, cu.RandomNumber(0, 4));
                LocationCurrent.CurrentSpeed = cu.RandomNumber(SpeedMin, SpeedMax);// ;
                Target = p;

                r = r + "NewTargetSelected,";
            }
            else
            {
                r = r + "WaitingAtTarget"; LocationCurrent.CurrentSpeed = 0;
            }

        }
        float Speed = LocationCurrent.CurrentSpeed;
        float DirectionAngle = 0;
        SLocationPoint newLocPoint = getNextPointUpponMovement(out DirectionAngle);
        SLocation newLoc = new SLocation();

        newLoc.MandatoryInit(simulationTime, newLocPoint, DirectionAngle, LocationCurrent.Acceleration, Target);
        newLoc.CurrentSpeed = LocationCurrent.CurrentSpeed;
        r = r + " Moving Toward Target ";
        LocationHistory.Add(newLoc);
        LocationCurrent = newLoc;

        return r;
    }
    bool WaitHere()
    {
        if (cu.RandomNumber(0, 100) < 40) return false;// no need to wait, start right for next target
        else return true;
    }

    private SLocationPoint getNextPointUpponMovement(out float DirectionAngleInRadians)
    {
        float dist = LocationCurrent.CurrentSpeed;
        double AngleInRadians;

        double dy = (double)(Target.Y - LocationCurrent.LocationPoint.Y);
        double dx = (double)(Target.X - LocationCurrent.LocationPoint.X);
        AngleInRadians = Math.Atan2(dy, dx);

        int xProgress;
        int yProgress;
        if (dx == 0) xProgress = 0; else xProgress = Convert.ToInt32(dist * Math.Cos(AngleInRadians));
        if (dy == 0) yProgress = 0; else yProgress = Convert.ToInt32(dist * Math.Sin(AngleInRadians));

        int newx = LocationCurrent.LocationPoint.X + xProgress,
        newy = LocationCurrent.LocationPoint.Y + yProgress,
        newz = Target.Z;

        SLocationPoint lopo = new SLocationPoint();
        lopo.MandatoryInit(newx, newy, newz);
        DirectionAngleInRadians = (float)AngleInRadians;

        return lopo;
    }



    public void MandatoryInit(int simulationTime, bool isMobile, float _Accelaration, Terrain terrain, SLocationPoint _CurrentLocation)
    {
        LocationHistory = new List<SLocation>();
        CoUtils cu = new CoUtils();
        float Angle = 0;
        _Accelaration = 0;
        canMove = isMobile;
        this.SpeedMax = terrain.SpeedMaxAllowed;
        this.SpeedMin = terrain.SpeedMinAllowed;


        LocationCurrent = new SLocation();
        LocationCurrent.MandatoryInit(simulationTime, _CurrentLocation, Angle, _Accelaration, Target); ;
    }

    /* public SLocationProfile(int simulationTime, bool isMobile, double _Accelaration, int currentSpeed, int SpeedMax, Terrain terrain)
     {
         init(simulationTime, isMobile, _Accelaration, currentSpeed, SpeedMax, terrain.GeoXmin, terrain.GeoXmax, terrain.GeoYmin, terrain.GeoYmax, terrain.GeoZmin, terrain.GeoZmax);
     }
     */

    private void init(int simulationTime, bool isMobile, float _Accelaration, int currentSpeed, int SpeedMax, int GeoXmin, int GeoXmax, int GeoYmin, int GeoYmax, int GeoZmin, int GeoZmax)
    {
        LocationHistory = new List<SLocation>();
        CoUtils cu = new CoUtils();

        float Angle = 0;
        int geox = cu.RandomNumber(GeoXmin, GeoXmax), geoy = cu.RandomNumber(GeoYmin, GeoYmax), geoz = cu.RandomNumber(GeoZmin, GeoZmax);
        SLocationPoint currentLoc = new SLocationPoint();
        currentLoc.MandatoryInit(geox, geoy, geoz);

        _Accelaration = 0;
        canMove = isMobile;


        LocationCurrent = new SLocation();
        LocationCurrent.MandatoryInit(simulationTime, currentLoc, Angle, _Accelaration, Target);
    }

    /*  public SLocationProfile(int simulationTime, bool isMobile, double _Accelaration, int currentSpeed, int SpeedMax, int GeoXmin, int GeoXmax, int GeoYmin, int GeoYmax, int GeoZmin, int GeoZmax)
      {
          init(simulationTime, isMobile, _Accelaration, currentSpeed, SpeedMax, GeoXmin, GeoXmax, GeoYmin, GeoYmax, GeoZmin, GeoZmax);
      }
      */

    public static int getQuartile(int currentValue, int maxValue)
    {
        double v = currentValue / maxValue;
        if (v <= 0.25) return 1;
        if ((v > 0.25) && (v <= 0.5)) return 2;
        if ((v > 0.5) && (v <= 0.75)) return 3;
        if ((v > 0.75) && (v <= 1)) return 4;
        return 0;
    }


    public static SLocationPoint getRandomLocationPoint(Terrain terrain, int quartile)
    {

        CoUtils cu = new CoUtils();

        int x, y, z;
        switch (quartile)
        {
            case 1:
                x = cu.RandomNumber(terrain.GeoXmin, terrain.GeoXmin + (terrain.GeoXmax - terrain.GeoXmin) / 2);
                y = cu.RandomNumber(terrain.GeoYmin, terrain.GeoYmin + (terrain.GeoYmax - terrain.GeoYmin) / 2);
                z = cu.RandomNumber(terrain.GeoZmin, terrain.GeoZmax);
                break;
            case 2:
                x = cu.RandomNumber(terrain.GeoXmin + (terrain.GeoXmax - terrain.GeoXmin) / 2, terrain.GeoXmax);
                y = cu.RandomNumber(terrain.GeoYmin, terrain.GeoYmin + (terrain.GeoYmax - terrain.GeoYmin) / 2);
                z = cu.RandomNumber(terrain.GeoZmin, terrain.GeoZmax);
                break;
            case 3:
                x = cu.RandomNumber(terrain.GeoXmin, terrain.GeoXmin + (terrain.GeoXmax - terrain.GeoXmin) / 2);
                y = cu.RandomNumber(terrain.GeoYmin + (terrain.GeoYmax - terrain.GeoYmin) / 2, terrain.GeoYmax);
                z = cu.RandomNumber(terrain.GeoZmin, terrain.GeoZmax);
                break;
            case 4:
                x = cu.RandomNumber(terrain.GeoXmin + (terrain.GeoXmax - terrain.GeoXmin) / 2, terrain.GeoXmax);
                y = cu.RandomNumber(terrain.GeoYmin + (terrain.GeoYmax - terrain.GeoYmin) / 2, terrain.GeoYmax);
                z = cu.RandomNumber(terrain.GeoZmin, terrain.GeoZmax);
                break;
            default:
                x = cu.RandomNumber(terrain.GeoXmin, terrain.GeoXmax);
                y = cu.RandomNumber(terrain.GeoYmin, terrain.GeoYmax);
                z = cu.RandomNumber(terrain.GeoZmin, terrain.GeoZmax);
                break;
        }
        SLocationPoint l = new SLocationPoint();
        l.MandatoryInit(x, y, z);
        return l;
    }




    public class SLocation
    {
        public SLocationPoint LocationPoint;
        public SLocationPoint TargetPoint;
        public int Time;
        public string Date;
        public float CurrentSpeed;
        public float CurrentDirectionAngleInRadians;
        public float Acceleration;



        public void MandatoryInit(int _Time, SLocationPoint currentLocation, float _CurrentDirectionAngle, float _Accelaration, SLocationPoint _TargetPoint)
        {

            this.Time = _Time;
            this.LocationPoint = currentLocation;

            this.CurrentDirectionAngleInRadians = _CurrentDirectionAngle;
            this.Acceleration = _Accelaration;
            if (_TargetPoint == null)
            { _TargetPoint = currentLocation; }
            this.TargetPoint = _TargetPoint;
        }
    }





    private SLocationPoint getNextPointUpponMovement_old(out float DirectionAngle)
    {
        //0.calc dist=speed
        //1.line equation from start to target
        //2. calc alpha= declination of the line   :: this is the angle
        //3. calc x=dist *cos alpha and y=dist*sin alpha
        //return new point with above x,y;

        float dist = LocationCurrent.CurrentSpeed;

        float declination;

        //Target.Y =20;         LocationCurrent.LocationPoint.Y =40;
        //Target.X =10;        LocationCurrent.LocationPoint.X =60;
        if (Math.Abs(Target.X - LocationCurrent.LocationPoint.X) != 0)
        {
            if ((Math.Abs(Target.Y - LocationCurrent.LocationPoint.Y) != 0))
            {
                declination = (float)Math.Atan((double)(Target.Y - LocationCurrent.LocationPoint.Y) / (Target.X - LocationCurrent.LocationPoint.X));
            }
            else
            {
                if (Target.X > LocationCurrent.LocationPoint.X)
                {
                    declination = 0;
                }
                else
                {
                    declination = -1 * (float)Math.PI;
                }


            }
        }
        else
        {
            int r = -1;
            if (Target.Y > LocationCurrent.LocationPoint.Y) r = 1;
            declination = r * ((float)Math.PI / 2);
        }
        double c = Math.Cos(declination), s = Math.Sin(declination);
        int xProgress = Convert.ToInt32(Math.Floor(dist * c));
        int yProgress = Convert.ToInt32(Math.Floor(dist * s));

        if ((Target.X > LocationCurrent.LocationPoint.X))
        { xProgress = (int)Math.Abs(xProgress); }
        else
        {
            xProgress = -1 * (int)Math.Abs(xProgress);
        }
        if ((Target.Y > LocationCurrent.LocationPoint.Y)) { yProgress = (int)Math.Abs(yProgress); } else { yProgress = -1 * (int)Math.Abs(yProgress); }

        int newx, newy, newz;
        newx = LocationCurrent.LocationPoint.X + xProgress;
        newy = LocationCurrent.LocationPoint.Y + yProgress;
        newz = Target.Z;




        SLocationPoint lopo = new SLocationPoint();
        lopo.MandatoryInit(newx, newy, newz);
        //Speed = Math.Abs(xProgress) + Math.Abs(yProgress);//as time unit is ONE then total movement in x and y is the speed
        DirectionAngle = declination;
        return lopo;
    }

}

public class SLocationPoint
{
    public int X, Y, Z;
    public void MandatoryInit(int x, int y, int z)
    {
        X = x;
        Y = y;
        Z = z;
    }
}



