﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

public class Job
{
    //statistical data------
    public Int64 JobSizeWithoutAccountForParallelism;
    public Int64 MinimumPassThrough_MI_withHighestParallelism;

    public int CountOfEdges, CountOfTasks, MaxParallelExecutableTasks, JobInitSourceTypeID;
    public Int64 MaxEdgeWeight, MinEdgeWeight, MaxTaskSize, MinTaskSize, SumOfEdgeWeight, MaxRamNeededForParallelExecutionOfHighestCpuLoadPartOfTheDag, TotalRamNeeded, MinRamNeeded, MaxRamNeededForParallelExec, TotalStorageNeeded, MinStorageNeeded, MaxStorageNeededForParallelExec;
    public decimal MinTimeForExecuteDagWithMaxParallelismOnCloud, MinTimeForExecuteDagWithMaxParallelismOnFog, MinTimeForExecuteDagWithMaxParallelismOnIoT;
    public decimal MaxTimeForExecuteDagSerialOnCloud, MinTimeForExecuteDagSerialOnFog, MinTimeForExecuteDagSerialOnIoT;
    private CpuAndBandwidthBaseLines cpuAndBandwidthBaseLines;
    public int[] TaskIDsOfHighestsCPULoadPartOfTheDag;
    public List<string> TasksWhichCanRunInParallel = new List<string>();
    //----end of statistical data
    public int JobID;
    public int JobID_inDB;
    public string UserIDOwner = "";
    public int EFT_DAG;
    public string NodeID_CurrentlyOn; // pointer to the node which currently this job is on it (or the node that is currently responsible for executing this job)
    public string NodeSubmitted;


    public int TimeSubmission = 0, TimeDeadlineFinal = 0, TimeDeadLinePrefered = 0;
    public string DateSubmission = "";

    public decimal PriorityNo = 0;

    public List<DagInnerNode> Tasks;
    public List<Edge> Edges;


    private int JobStatus = JobAndTaskStatus.InitializedAndWaiting; //from JobAndTaskStatus
    public string envName = "Velociraptor";






    public int GetJobStatus()
    {
        return JobStatus;
    }
    public void SetJobStatus(SqlConnection SqlConnforLog, string date, int SimulationTime, int JobStatusCode)    //JobStatusCode from JobAndTaskStatus
    {
        int oldStatus = this.JobStatus;
        this.JobStatus = JobStatusCode;
        try
        {
            if ((SqlConnforLog != null))
            {
                if (SqlConnforLog.State != ConnectionState.Open) SqlConnforLog.Open();
                using (SqlCommand cmd = new SqlCommand("SP_JobStateChange", SqlConnforLog))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.Add("@PriorityNo", SqlDbType.Decimal).Value = this.PriorityNo;
                    cmd.Parameters.Add("@NewState", SqlDbType.NVarChar).Value = JobAndTaskStatus.getStatusText(this.JobStatus);
                    cmd.Parameters.Add("@OldState", SqlDbType.NVarChar).Value = JobAndTaskStatus.getStatusText(oldStatus);
                    cmd.Parameters.Add("@JobID_InDB", SqlDbType.Int).Value = this.JobID_inDB;
                    cmd.Parameters.Add("@JobID", SqlDbType.Int).Value = this.JobID;
                    cmd.Parameters.Add("@Time", SqlDbType.Int).Value = SimulationTime;
                    cmd.Parameters.Add("@Date", SqlDbType.NVarChar).Value = date;
                    cmd.Parameters.Add("@NodeIDCurrently ", SqlDbType.NVarChar).Value = NodeID_CurrentlyOn;
                    cmd.ExecuteNonQuery();
                }
            }
        }
        catch (Exception)
        {


        }


    }

    public void SJob_Init(int _JobID, int _TimeSubmission, string _UserIDOwner, ComputerNode _NodeSubmitted)
    {
        JobID = _JobID;
        TimeSubmission = _TimeSubmission;

        UserIDOwner = _UserIDOwner;
        this.NodeSubmitted = _NodeSubmitted.NodeID;
    }

    public void SJob_Init(int _JobID, string _DateSubmitted, int _TimeSubmission, string _UserIDOwner, ComputerNode _NodeSubmitted, List<DagInnerNode> _Tasks, List<Edge> _Edges, SqlConnection _SqlConnectionForLogging)
    {
        JobID = _JobID;
        TimeSubmission = _TimeSubmission;


        UserIDOwner = _UserIDOwner;
        this.NodeSubmitted = _NodeSubmitted.NodeID;
        Tasks = _Tasks;
        Edges = _Edges;
        this.JobStatus = JobAndTaskStatus.InitializedAndWaiting;


        InitJobInDatabase(_SqlConnectionForLogging);


        SetJobStatus(_SqlConnectionForLogging, _DateSubmitted, _TimeSubmission, this.JobStatus);
    }

    private void UpdateTaskAndJobSuppInfo(SqlConnection SqlConnforLog)
    {
        CoUtils cu = new CoUtils();
        foreach (Job.DagInnerNode task in this.Tasks)
        {
            try
            {
                if ((SqlConnforLog != null))
                {
                    if (SqlConnforLog.State != ConnectionState.Open) SqlConnforLog.Open();
                    using (SqlCommand cmd = new SqlCommand("SP_TaskUpdateSuppInfo", SqlConnforLog))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.Add("@TaskID_InDB", SqlDbType.Int).Value = task.TaskID_InDB;

                        cmd.Parameters.Add("@LengthOnScheduledMachine", SqlDbType.Decimal).Value = 0; //no change in this field is desired.
                        cmd.Parameters.Add("@LengthOnFogAndCloudBaseLineCPU", SqlDbType.Decimal).Value = task.LengthInSecondsOnBaseLineCpuCloudFog;
                        cmd.Parameters.Add("@LengthOnBaseLineCloudMachine", SqlDbType.Decimal).Value = task.LengthInSecondsOnBaseLineCPUCloud;
                        cmd.Parameters.Add("@LengthOnBaseLineFogMachine", SqlDbType.Decimal).Value = task.LengthInSecondsOnBaseLineCpuFog;
                        cmd.Parameters.Add("@LengthOnBaseLineIoTMachine", SqlDbType.Decimal).Value = task.LengthInSecondsOnBaseLineCpuIoT;

                        cmd.Parameters.Add("@BaseLineCloudAndFogCpuMIPS", SqlDbType.Int).Value = task.BaselineCPUAndBandwidth.CPUFogCloudBaseLineMips;
                        cmd.Parameters.Add("@BaseLineCpuCloudMIPS", SqlDbType.Int).Value = task.BaselineCPUAndBandwidth.CPUCloudMachineBaseLineMips;
                        cmd.Parameters.Add("@BaseLineCpuFogMIPS", SqlDbType.Int).Value = task.BaselineCPUAndBandwidth.CPUFogMachineBaseLineMips;
                        cmd.Parameters.Add("@BaseLineCpuIoTMIPS", SqlDbType.Int).Value = task.BaselineCPUAndBandwidth.CPUIoTMachineBaseLineMips;

                        cmd.Parameters.Add("@BaseLineBandwidthCloud", SqlDbType.Int).Value = this.cpuAndBandwidthBaseLines.CPUIoTMachineBaseLineMips;
                        cmd.Parameters.Add("@BaseLineBandwidthIoT", SqlDbType.Int).Value = this.cpuAndBandwidthBaseLines.CPUIoTMachineBaseLineMips;
                        cmd.Parameters.Add("@BaseLineBandwidthFog", SqlDbType.Int).Value = this.cpuAndBandwidthBaseLines.CPUIoTMachineBaseLineMips;
                        cmd.Parameters.Add("@BaseLineCloudAndFogBandwidth", SqlDbType.Int).Value = this.cpuAndBandwidthBaseLines.CPUIoTMachineBaseLineMips;

                        cmd.Parameters.Add("@EST", SqlDbType.Int).Value = task.EST;
                        cmd.Parameters.Add("@EFT", SqlDbType.Int).Value = task.EFT;

                        cmd.Parameters.Add("@SuccessorsImediate", SqlDbType.NVarChar).Value = cu.ListToString(task.SuccessorsImmediate);
                        cmd.Parameters.Add("@SuccessorsNotImmediate", SqlDbType.NVarChar).Value = cu.ListToString(task.SuccessorsNotImmediate);
                        cmd.Parameters.Add("@PredecessorsImediate", SqlDbType.NVarChar).Value = cu.ListToString(task.Predecessors);

                        cmd.Parameters.Add("@TimeDeadLinePrefered", SqlDbType.Int).Value = task.TimeDeadLinePrefered;
                        cmd.Parameters.Add("@TimeDeadlineFinal", SqlDbType.Int).Value = task.TimeDeadlineFinal;

                        cmd.ExecuteNonQuery();
                    }
                }
            }
            catch (Exception ee)
            {

            }
        }




        try
        {


            if (SqlConnforLog.State != ConnectionState.Open) SqlConnforLog.Open();
            using (SqlCommand cmd = new SqlCommand("SP_JobUpdateSuppInfo", SqlConnforLog))
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@JobID_InDB", SqlDbType.Int).Value = this.JobID_inDB;

                cmd.Parameters.Add("@JobSizeWithoutAccountForParallelism", SqlDbType.BigInt).Value = this.JobSizeWithoutAccountForParallelism;
                cmd.Parameters.Add("@CountOfEdges", SqlDbType.Int).Value = this.CountOfEdges;
                cmd.Parameters.Add("@CountOfTasks", SqlDbType.Int).Value = this.CountOfTasks;
                cmd.Parameters.Add("@SumOfEdgeWeight", SqlDbType.BigInt).Value = this.SumOfEdgeWeight;
                cmd.Parameters.Add("@MaxEdgeWeight", SqlDbType.BigInt).Value = this.MaxEdgeWeight;
                cmd.Parameters.Add("@MinEdgeWeight", SqlDbType.BigInt).Value = this.MinEdgeWeight;
                cmd.Parameters.Add("@MaxTaskSize", SqlDbType.BigInt).Value = this.MaxTaskSize;
                cmd.Parameters.Add("@MinTaskSize", SqlDbType.BigInt).Value = this.MinTaskSize;
                cmd.Parameters.Add("@MaxParallelExecutableTasks", SqlDbType.Int).Value = this.MaxParallelExecutableTasks;
                cmd.Parameters.Add("@JobInitSource", SqlDbType.Int).Value = this.JobInitSourceTypeID;

                cmd.Parameters.Add("@MaxStorageNeededForParallelExec", SqlDbType.BigInt).Value = this.MaxStorageNeededForParallelExec;
                cmd.Parameters.Add("@MinStorageNeeded", SqlDbType.BigInt).Value = this.MinStorageNeeded;
                cmd.Parameters.Add("@TotalStorageNeeded", SqlDbType.BigInt).Value = this.TotalStorageNeeded;
                cmd.Parameters.Add("@MaxRamNeededForParallelExec", SqlDbType.BigInt).Value = this.MaxRamNeededForParallelExec;
                cmd.Parameters.Add("@MinRamNeeded", SqlDbType.BigInt).Value = this.MinRamNeeded;
                cmd.Parameters.Add("@TotalRamNeeded", SqlDbType.BigInt).Value = this.TotalRamNeeded;
                cmd.Parameters.Add("@TasksWhichCanRunInParallel", SqlDbType.NVarChar).Value = cu.ListToString(this.TasksWhichCanRunInParallel);
                cmd.Parameters.Add("@TaskIDsOfHighestsCPULoadPartOfTheDag", SqlDbType.NVarChar).Value = ArrayToString(this.TaskIDsOfHighestsCPULoadPartOfTheDag);
                cmd.Parameters.Add("@MaxRamNeededForParallelExecutionOfHighestCpuLoadPartOfTheDag", SqlDbType.BigInt).Value = this.MaxRamNeededForParallelExecutionOfHighestCpuLoadPartOfTheDag;
                cmd.Parameters.Add("@MinimumPassThrough_MI_withHighestParallelism", SqlDbType.BigInt).Value = this.MinimumPassThrough_MI_withHighestParallelism;
                cmd.Parameters.Add("@MinTimeForExecuteDagWithMaxParallelismOnCloud", SqlDbType.Decimal).Value = this.MinTimeForExecuteDagWithMaxParallelismOnCloud;
                cmd.Parameters.Add("@MinTimeForExecuteDagWithMaxParallelismOnFog", SqlDbType.Decimal).Value = this.MinTimeForExecuteDagWithMaxParallelismOnFog;
                cmd.Parameters.Add("@MinTimeForExecuteDagWithMaxParallelismOnIoT", SqlDbType.Decimal).Value = this.MinTimeForExecuteDagWithMaxParallelismOnIoT;
                cmd.Parameters.Add("@MaxTimeForExecuteDagSerialOnCloud", SqlDbType.Decimal).Value = this.MaxTimeForExecuteDagSerialOnCloud;
                cmd.Parameters.Add("@MinTimeForExecuteDagSerialOnFog", SqlDbType.Decimal).Value = this.MinTimeForExecuteDagSerialOnFog;
                cmd.Parameters.Add("@MinTimeForExecuteDagSerialOnIoT", SqlDbType.Decimal).Value = this.MinTimeForExecuteDagSerialOnIoT;
                cmd.Parameters.Add("@TimeDeadLinePrefered", SqlDbType.Int).Value = this.TimeDeadLinePrefered;
                cmd.Parameters.Add("@TimeDeadlineFinal", SqlDbType.Int).Value = this.TimeDeadlineFinal;
                cmd.Parameters.Add("@EFT_DAG", SqlDbType.Int).Value = this.EFT_DAG;
                //Bandwidth

                cmd.ExecuteNonQuery();
            }

        }
        catch (Exception ee2)
        {

        }


    }


    

    public void CalculateDagSuppInfo(SimulationNodeStructure nodeStructure, SqlConnection SqlConnforLog) //Length_EST_EFT_Pred_Succ
    {
        this.cpuAndBandwidthBaseLines = nodeStructure.GetBaseLines();
        foreach (Job.DagInnerNode task in this.Tasks)
        {
            decimal x = (decimal)task.CpuNeed_Claimed;
            task.LengthInSecondsOnBaseLineCpuCloudFog = x / cpuAndBandwidthBaseLines.CPUFogCloudBaseLineMips;
            task.LengthInSecondsOnBaseLineCpuFog = x / cpuAndBandwidthBaseLines.CPUFogMachineBaseLineMips;
            task.LengthInSecondsOnBaseLineCPUCloud = x / cpuAndBandwidthBaseLines.CPUCloudMachineBaseLineMips;
            task.LengthInSecondsOnBaseLineCpuIoT = x / cpuAndBandwidthBaseLines.CPUIoTMachineBaseLineMips;
            task.BaselineCPUAndBandwidth = this.cpuAndBandwidthBaseLines;
        }


        MaxEdgeWeight = MinEdgeWeight = MaxTaskSize = MinTaskSize = 0;
        JobSizeWithoutAccountForParallelism = 0;
        CountOfEdges = CountOfTasks = MaxParallelExecutableTasks = JobInitSourceTypeID = 0;
        SumOfEdgeWeight = TotalRamNeeded = MinRamNeeded = MaxRamNeededForParallelExec = TotalStorageNeeded = MinStorageNeeded = MaxStorageNeededForParallelExec = 0;


        this.MinRamNeeded = Tasks[0].MemoryNeedMax_Claimed;
        this.MinTaskSize = Tasks[0].CpuNeed_Claimed;
        this.MinStorageNeeded = Tasks[0].StorageNeed_Claimed;
        if (Edges.Count != 0) this.MinEdgeWeight = Edges[0].Weight_Claimed;
        else this.MinEdgeWeight = 0;

        ComputerNode TheNode = SimulationNodeStructure.GetNodeByID(this.NodeSubmitted,nodeStructure.Nodes);
        JobInitSourceTypeID = TheNode.HardwareProfile.NodeTypeCode;
        foreach (Job.DagInnerNode task in this.Tasks)
        {
            CountOfTasks++;
            this.JobSizeWithoutAccountForParallelism += task.CpuNeed_Claimed;
            this.MaxTaskSize = Math.Max(MaxTaskSize, task.CpuNeed_Claimed);
            this.MinTaskSize = Math.Min(MinTaskSize, task.CpuNeed_Claimed);
            this.TotalRamNeeded += task.MemoryNeedMax_Claimed;
            this.MinRamNeeded = Math.Min(MinRamNeeded, task.MemoryNeedMax_Claimed);
            this.TotalStorageNeeded += task.StorageNeed_Claimed;
            this.MinStorageNeeded = Math.Min(MinStorageNeeded, task.StorageNeed_Claimed);
        }
        foreach (Job.Edge edge in this.Edges)
        {
            CountOfEdges++;
            this.SumOfEdgeWeight += edge.Weight_Claimed;
            this.MaxEdgeWeight = Math.Max(edge.Weight_Claimed, MaxEdgeWeight);
            this.MinEdgeWeight = Math.Min(edge.Weight_Claimed, MinEdgeWeight);
        }


        //zz URGENT MODIFICATUON for dag with one task
        //more? job critical path length and execTime, job MaxSequentialExecTimeBAsedOnCPU
        //zz not now      this.MaxStorageNeededForParallelExec = getMaxStorageNeededForParallelExec();

        this.TasksWhichCanRunInParallel = GenerateListOfTasksWhichCanBeExectutedInParallel();
        this.MaxParallelExecutableTasks = getMaximumNumberOfParallelyExecutableTasks();
        this.TaskIDsOfHighestsCPULoadPartOfTheDag = getTaskIDsOfHighestsCPULoadPartOfTheDag();
        this.MaxRamNeededForParallelExecutionOfHighestCpuLoadPartOfTheDag = getMaxRamNeededForParallelExecutionOfHighestCpuLoadPArtOfTheDag();

        if (Tasks.Count == 1)
        {
            this.MinTimeForExecuteDagWithMaxParallelismOnCloud = (decimal)this.MinimumPassThrough_MI_withHighestParallelism / cpuAndBandwidthBaseLines.CPUCloudMachineBaseLineMips;
            this.MinTimeForExecuteDagWithMaxParallelismOnFog = (decimal)this.MinimumPassThrough_MI_withHighestParallelism / cpuAndBandwidthBaseLines.CPUFogMachineBaseLineMips;
            this.MinTimeForExecuteDagWithMaxParallelismOnIoT = (decimal)this.MinimumPassThrough_MI_withHighestParallelism / cpuAndBandwidthBaseLines.CPUIoTMachineBaseLineMips;
            this.MaxTimeForExecuteDagSerialOnCloud = (decimal)this.JobSizeWithoutAccountForParallelism / cpuAndBandwidthBaseLines.CPUCloudMachineBaseLineMips;
            this.MinTimeForExecuteDagSerialOnFog = (decimal)this.JobSizeWithoutAccountForParallelism / cpuAndBandwidthBaseLines.CPUFogMachineBaseLineMips;
            this.MinTimeForExecuteDagSerialOnIoT = (decimal)this.JobSizeWithoutAccountForParallelism / cpuAndBandwidthBaseLines.CPUIoTMachineBaseLineMips;

        }
        else
        {
            this.MinimumPassThrough_MI_withHighestParallelism = getMinimumPassThrough_MI_withHighestParallelism();
            this.MinTimeForExecuteDagWithMaxParallelismOnCloud = (decimal)this.MinimumPassThrough_MI_withHighestParallelism / cpuAndBandwidthBaseLines.CPUCloudMachineBaseLineMips;
            this.MinTimeForExecuteDagWithMaxParallelismOnFog = (decimal)this.MinimumPassThrough_MI_withHighestParallelism / cpuAndBandwidthBaseLines.CPUFogMachineBaseLineMips;
            this.MinTimeForExecuteDagWithMaxParallelismOnIoT = (decimal)this.MinimumPassThrough_MI_withHighestParallelism / cpuAndBandwidthBaseLines.CPUIoTMachineBaseLineMips;
            this.MaxTimeForExecuteDagSerialOnCloud = (decimal)this.JobSizeWithoutAccountForParallelism / cpuAndBandwidthBaseLines.CPUCloudMachineBaseLineMips;
            this.MinTimeForExecuteDagSerialOnFog = (decimal)this.JobSizeWithoutAccountForParallelism / cpuAndBandwidthBaseLines.CPUFogMachineBaseLineMips;
            this.MinTimeForExecuteDagSerialOnIoT = (decimal)this.JobSizeWithoutAccountForParallelism / cpuAndBandwidthBaseLines.CPUIoTMachineBaseLineMips;
        }
        UpdateTaskAndJobSuppInfo(SqlConnforLog);

    }
    string ArrayToString(int[] arr)
    {
        string s = (new CoUtils()).ListToString(arr);
        return s;

    }
    List<string> GenerateListOfTasksWhichCanBeExectutedInParallel()
    {

        CalculateTasksPredecessorsAndSuccessors();
        CalculateTasks_EST_EFT_Deadline();
        Dictionary<int, int> doneNodes = new Dictionary<int, int>();
        List<string> L = new List<string>();
        if (Tasks.Count == 1)
        {
            doneNodes.Add(0, 0);
            L.Add("0");
            return L;
        }
        L.Add("0");
        doneNodes.Add(0, 0);
        for (int i = 1; i < Tasks.Count; i++)
        {
            DagInnerNode task = Tasks[i];
            List<DagInnerNode> parallelTasks = new List<DagInnerNode>();
            bool x = doneNodes.ContainsKey(task.TaskID);
            if (x) continue;
            parallelTasks.Add(task);
            doneNodes.Add(task.TaskID, 0);

            foreach (var subjectTaskID in task.NotRelevantTasks)
            {
                DagInnerNode subjectTask = Tasks[subjectTaskID];
                if (subjectTask.TaskID < task.TaskID) continue;
                bool isSubjectNodeParallelToThisTask = false;
                if (((task.EST >= subjectTask.EST) && (task.EST <= subjectTask.EFT))) { isSubjectNodeParallelToThisTask = true; }
                if ((!isSubjectNodeParallelToThisTask) && ((task.EST <= subjectTask.EST) && (task.EFT >= subjectTask.EFT))) { isSubjectNodeParallelToThisTask = true; }
                if (isSubjectNodeParallelToThisTask)
                {
                    x = doneNodes.ContainsKey(subjectTask.TaskID);
                    if (!x)
                    {
                        parallelTasks.Add(subjectTask);
                        doneNodes.Add(subjectTask.TaskID, 0);
                    }
                }


            }




            //if a task is not related to this task and its est and eft fit with this task then we add it to paralleltasks of this node



            string parallels = (new CoUtils()).ListToString(parallelTasks);
            parallels = (parallels.Replace("[", "")).Replace("]", "");
            L.Add(parallels);
        }

        /*L.Add("4,5,6");
        L.Add("3,7");
        L.Add("8");
        */
        return L;
    }
    List<string> GenerateListOfTasksWhichCanBeExectutedInParallel_Version_FindAllPossible()
    {
        List<string> L = new List<string>();
        /*

        CalculateTasksPredecessorsAndSuccessors();
        CalculateTasks_EST_EFT_Deadline();
      
        if (Tasks.Count == 1)
        {
            L.Add("0");
            return L;
        }
        L.Add("0");
        for (int i = 1; i < Tasks.Count; i++)
        {
            DagInnerNode task = Tasks[i];
            List<DagInnerNode> parallelTasks = new List<DagInnerNode>();
            parallelTasks.Add(task);

            //if a task is not related to this task and its est and eft fit with this task then we add it to paralleltasks of this node

            foreach (var subjectTaskID in task.NotRelevantTasks)
            {
                DagInnerNode subjectTask = Tasks[subjectTaskID.Key];
                if (subjectTask.TaskID < task.TaskID) continue;
                bool isSubjectNodeParallelToThisTask = false;
                if (((task.EST >= subjectTask.EST) && (task.EST <= subjectTask.EFT))) { isSubjectNodeParallelToThisTask = true; }
                if ((!isSubjectNodeParallelToThisTask) && ((task.EST <= subjectTask.EST) && (task.EFT >= subjectTask.EFT))) { isSubjectNodeParallelToThisTask = true; }
                if (isSubjectNodeParallelToThisTask)
                {
                    parallelTasks.Add(subjectTask);
                }


            }

            string parallels = ListToString(parallelTasks);
            parallels = (parallels.Replace("[", "")).Replace("]", "");
            L.Add(parallels);
        }

        /*L.Add("4,5,6");
        L.Add("3,7");
        L.Add("8");
        */
        return L;

    }


    private void CalculateTasks_EST_EFT_Deadline()
    {//note that before calling this method, make sure:1-tasksizesInSeconds are calculated. 2-pred and succ are calculated
        bool done = false;
        int CountOfCalculatedNodes = 0;
        Tasks[0].EST = Tasks[0].TimeSubmission;
        Tasks[0].EFT = Tasks[0].EST + Convert.ToInt32(Math.Ceiling(Tasks[0].LengthInSecondsOnBaseLineCpuCloudFog));
        int i = 1;
        while (!done)
        {
            DagInnerNode node = Tasks[i];
            bool isEFTforAllPredecessorsCalculated = true;
            for (int j = 1; j < node.Predecessors.Count; j++)//exclude first node.
            {
                int theEft = Tasks[node.Predecessors[j]].EFT;
                if (theEft == -1) { isEFTforAllPredecessorsCalculated = false; break; }
            }
            if (isEFTforAllPredecessorsCalculated)
            {
                int[] ReadyTime = new int[node.Predecessors.Count];
                int LatestReadyTime = -1;
                for (int j = 0; j < node.Predecessors.Count; j++)
                {
                    int ReadyTimeForthisPredNode = Convert.ToInt32(Math.Ceiling(Tasks[node.Predecessors[j]].EFT + ((float)CommunicationCostBetweenTwoNodes(Tasks[node.Predecessors[j]], node) / this.cpuAndBandwidthBaseLines.BandwidthCloudFogBaseLine))); //arrival time= EFT+CC/Bandwidth
                    LatestReadyTime = Math.Max(LatestReadyTime, ReadyTimeForthisPredNode);
                }
                node.EST = LatestReadyTime;
                node.EFT = node.EST + Convert.ToInt32(Math.Ceiling(node.LengthInSecondsOnBaseLineCpuCloudFog));
                CountOfCalculatedNodes++;
            }
            if (CountOfCalculatedNodes == Tasks.Count) done = true;
            i++;
            if (i == Tasks.Count) i = 1;
        }
        float deadlinePreferredPercentOfSize = 0.1f;
        float deadlineFinalPercentOfSize = 0.3f;

        foreach (DagInnerNode task in Tasks)
        {
            task.TimeDeadlineFinal = Convert.ToInt32(task.EFT + (task.EFT - task.EST) * deadlineFinalPercentOfSize);
            task.TimeDeadLinePrefered = Convert.ToInt32(task.EFT + (task.EFT - task.EST) * deadlinePreferredPercentOfSize);
        }

        this.EFT_DAG = Tasks[Tasks.Count - 1].EFT;

        this.TimeDeadlineFinal = Convert.ToInt32(this.EFT_DAG + (this.EFT_DAG - this.TimeSubmission) * deadlineFinalPercentOfSize);
        this.TimeDeadLinePrefered = Convert.ToInt32(this.EFT_DAG + (this.EFT_DAG - this.TimeSubmission) * deadlinePreferredPercentOfSize);



    }


    private void CalculateTasksPredecessorsAndSuccessors()
    {
        //first calculate edges in and out
        for (int i = 0; i < Edges.Count; i++)
        {
            Edge e = Edges[i];
            Tasks[e.EndNodeID].EdgesIn.Add(e);
            Tasks[e.StartNodeID].EdgesOut.Add(e);
        }
        //successors first

        //first immediate successors and predecessors.
        for (int i = 0; i < Tasks.Count - 1; i++)//last node has no successors
        {
            DagInnerNode t = Tasks[i];
            for (int j = 0; j < t.EdgesOut.Count; j++)
            {
                t.SuccessorsImmediate.Add(t.EdgesOut[j].EndNodeID);
                Tasks[t.EdgesOut[j].EndNodeID].Predecessors.Add(t.TaskID);
                //t.PathWeightToOtherNodes.Add(new Tuple<int, int>(t.EdgesOut[j].EndNode.TaskID, t.EdgesOut[j].Weight_Claimed));// tuple
            }
        }
        //next: 
        for (int i = 0; i < Tasks.Count - 1; i++) //last node has no successors
        {
            DagInnerNode t = Tasks[i];
            for (int j = i + 1; j < Tasks.Count; j++)
            {
                DagInnerNode subjectNode = Tasks[j];
                bool x = isImmediateSuccessor(t, Tasks[j]);
                if (x) continue;
                int w = CommunicationCostBetweenTwoNodes(t, subjectNode);
                if (w != -1)
                {
                    t.SuccessorsNotImmediate.Add(subjectNode.TaskID);
                    //    t.PathWeightToOtherNodes.Add(new Tuple<int, int>(subjectNode.TaskID, w)); ///tuple
                }
            }
        }

        for (int i = 0; i < Tasks.Count; i++)
        {
            DagInnerNode node = Tasks[i];
            Dictionary<int, int> notRelevantTasks = new Dictionary<int, int>();
            foreach (DagInnerNode t in Tasks) notRelevantTasks.Add(t.TaskID, 1);
            notRelevantTasks.Remove(node.TaskID);//remove self from the dictionary
            foreach (int t in node.SuccessorsImmediate) notRelevantTasks.Remove(t);
            foreach (int t in node.SuccessorsNotImmediate) notRelevantTasks.Remove(t);
            node.NotRelevantTasks.Clear();
            foreach (var item in notRelevantTasks)
            {
                node.NotRelevantTasks.Add(item.Key);
            }
        }

    }

    bool isImmediateSuccessor(DagInnerNode thisNode, DagInnerNode subjectNode)
    {
        foreach (int succ in thisNode.SuccessorsImmediate)
        {
            if (Tasks[succ].TaskID == subjectNode.TaskID) return true;
        }
        return false;
    }


    public int CommunicationCostBetweenTwoNodes(DagInnerNode startNode, DagInnerNode endNode) //returns -1 if there is no path
    {
        int w = 0;
        w = Mid_CheckPath(endNode, startNode, 0);
        if (w < 0) return -1; else return w;

    }


    int Mid_CheckPath(DagInnerNode TargetNode, DagInnerNode ThisNode, int CommunicationCostTillThisNode)
    {
        if (ThisNode.TaskID == TargetNode.TaskID)
        { return CommunicationCostTillThisNode; }
        if (ThisNode.SuccessorsImmediate.Count == 0) return -1;
        for (int i = 0; i < ThisNode.SuccessorsImmediate.Count; i++)
        {
            DagInnerNode nextNode = Tasks[ThisNode.SuccessorsImmediate[i]];

            Edge e = GetDirectEdgeBetweenTwoNodes(ThisNode, nextNode);

            if (nextNode.TaskID == TargetNode.TaskID) return e.Weight_Claimed;

            int WeightFromRecursiveExecFrom_nextNode_to_TargetNode = Mid_CheckPath(TargetNode, nextNode, e.Weight_Claimed);
            if (WeightFromRecursiveExecFrom_nextNode_to_TargetNode < 0)
            {
                return -1;
            }
            else
            { return CommunicationCostTillThisNode + WeightFromRecursiveExecFrom_nextNode_to_TargetNode; }

        }
        return -100;

    }

    Edge GetDirectEdgeBetweenTwoNodes(DagInnerNode NodeStart, DagInnerNode NodeEnd)
    {
        for (int i = 0; i < NodeStart.EdgesOut.Count; i++)
        {
            Edge e = NodeStart.EdgesOut[i];
            if (e.EndNodeID == NodeEnd.TaskID) return e;

        }
        return null;
    }



    private int getMaxRamNeededForParallelExecutionOfHighestCpuLoadPArtOfTheDag()
    {
        int s = 0;
        for (int i = 0; i < this.TaskIDsOfHighestsCPULoadPartOfTheDag.Length; i++)
        {
            int thetaskID = this.TaskIDsOfHighestsCPULoadPartOfTheDag[i];
            s += Tasks[thetaskID].MemoryNeedMax_Claimed;
        }
        return s;
    }
    private Int64 getMinimumPassThrough_MI_withHighestParallelism()
    {
        Int64 c = 0;
        foreach (string taskGroup in this.TasksWhichCanRunInParallel)
        {
            string[] listofTasks = taskGroup.Split(',');
            Int64 s = 0;
            for (int i = 0; i < listofTasks.Length; i++)
            {
                s = Math.Max(s, Tasks[Convert.ToInt32(listofTasks[i])].CpuNeed_Claimed); //find the longest task in the parallely executable group
            }
            c = c + s;//add it to total cycles   
        }
        return c;
    }

    private int getMaximumNumberOfParallelyExecutableTasks()
    {
        int c = 0;
        foreach (string taskGroup in this.TasksWhichCanRunInParallel)
        {
            string[] listofTasks = taskGroup.Split(',');
            if (c < listofTasks.Length)
            {
                c = listofTasks.Length;
            }

        }
        return c;
    }

    private int[] getTaskIDsOfHighestsCPULoadPartOfTheDag()
    {
        Int64 c = 0;
        string ptasks = "";
        foreach (string taskGroup in this.TasksWhichCanRunInParallel)
        {
            Int64 sumParallelyExecutableTasksLength = CalculateSumTaskLength(taskGroup);
            if (c < sumParallelyExecutableTasksLength)
            {
                c = sumParallelyExecutableTasksLength;
                ptasks = taskGroup;
            }

        }
        string[] s = ptasks.Split(',');
        int[] r = new int[s.Length];
        for (int i = 0; i < r.Length; i++)
            r[i] = Convert.ToInt32(s[i]);
        return r;

    }

    Int64 CalculateSumTaskLength(string CommaSeparatedTaskIDs)
    {
        string[] tids = CommaSeparatedTaskIDs.Split(',');
        Int64 s = 0;
        for (int i = 0; i < tids.Length; i++)
        {
            int taskID = Convert.ToInt32(tids[i]);
            s += Tasks[taskID].CpuNeed_Claimed;
        }
        return s;
    }
    private int getMaxStorageNeededForParallelExec()
    {
        return 0;
    }
    private int getMaxRamNeededForParallelExec()
    {
        return 0;
    }
    string GetTaskIDsAsString()
    {
        string s = "";
        for (int i = 0; i < this.Tasks.Count; i++)
        {
            s = s + this.Tasks[i].TaskID.ToString() + ",";

        }
        s = s.Substring(0, s.Length - 1);
        return s;
    }
    void InitJobInDatabase(SqlConnection SqlConnforLog)
    {
        int _jobid_inDB;
        if (SqlConnforLog.State != ConnectionState.Open) SqlConnforLog.Open();
        using (SqlCommand cmd = new SqlCommand("SP_JobInit", SqlConnforLog))
        {
            cmd.CommandType = CommandType.StoredProcedure;

            cmd.Parameters.Add("@Date", SqlDbType.NVarChar).Value = this.DateSubmission;
            cmd.Parameters.Add("@OwnerUserID", SqlDbType.NVarChar).Value = this.UserIDOwner;
            cmd.Parameters.Add("@NodeID_SubmittedOn", SqlDbType.NVarChar).Value = this.NodeSubmitted
                ;
            cmd.Parameters.Add("@ListOfTasks", SqlDbType.NVarChar).Value = GetTaskIDsAsString();
            cmd.Parameters.Add("@JobID", SqlDbType.Int).Value = this.JobID;
            cmd.Parameters.Add("@TimeSubmission", SqlDbType.Int).Value = this.TimeSubmission;

            cmd.Parameters.Add("@PriorityNo", SqlDbType.Float).Value = this.PriorityNo;



            var jiidb = cmd.Parameters.Add("@ReturnVal", SqlDbType.Int);
            jiidb.Direction = ParameterDirection.ReturnValue;
            cmd.ExecuteNonQuery();
            _jobid_inDB = Convert.ToInt32(jiidb.Value);
        }
        this.JobID_inDB = _jobid_inDB;


    }
   
    public static class JobAndTaskStatus
    {
        public static int InitializedAndWaiting = 0, FullyScheduled = 1,
            InSchedulingProcess = 2, Completed = 3, Rejected = 4,
            FailedExecutionDueToDeadline = 5, FailedExecutionDueToMachineFailure = 6;
        public static string getStatusText(int StatusCode)
        {
            switch (StatusCode)
            {
                case 0: return "InitializedAndWaiting";
                case 1: return "FullyScheduled";
                case 2: return "InSchedulingProcess";
                case 3: return "Completed";
                case 4: return "Rejected";
                case 5: return "FailedExecutionDueToDeadline";
                case 6: return "FailedExecutionDueToMachineFailure";

            }
            return "?";
        }
    }

    public static Job GenerateRandomDAG(int jobID, int countOfNodes, RequirementProfileForTasks trp, RequirementProfileForEdges erp, int timeSubmission, string ownerUserID, ComputerNode nodeSubmittdFrom, string _DateSubmission, SqlConnection _SqlConnectionForLogging)
    {
        CoUtils cu = new CoUtils();
        List<DagInnerNode> T = new List<DagInnerNode>();
        List<Edge> E = new List<Edge>();
        Job job = new Job();
        job.NodeSubmitted = nodeSubmittdFrom.NodeID
            ;
        job.JobID = jobID;
        for (int i = 0; i < countOfNodes; i++)
        {
            int cpuNeed = cu.RandomNumber(trp.TasksCPUNeedMin, trp.TasksCPUNeedMax);
            int memNeed = cu.RandomNumber(trp.TasksMemNeedMin, trp.TasksMemNeedMax);
            int storageNeed = cu.RandomNumber(trp.TasksStorageNeedMin, trp.TasksStorageNeedMax);
            int _TimeDeadlineFinal = 0, _TimeDeadLinePrefered = 0;//zz Deadline
            int countOfResources = cu.RandomNumber(1, trp.MaxCountOfResourcesEachTaskMayNeed);
            List<int> _NeededResourceTypes = cu.GetRandomElementsOfArray(trp.NeededResourceTypes, countOfResources);
            DagInnerNode t = new DagInnerNode();
            t.Task_Init(job, i, cpuNeed, memNeed, storageNeed, timeSubmission, _TimeDeadlineFinal, _TimeDeadLinePrefered, _NeededResourceTypes, _DateSubmission, _SqlConnectionForLogging);
            T.Add(t);
        }
        // add edges

        for (int i = 0; i < countOfNodes; i++)
        {
            int j = countOfNodes - i;
            int countOfOutEdges = Convert.ToInt32(erp.Connectivity * j);
            int startNode = i;
            int[] targetNodes = new int[countOfOutEdges];
            for (int k = 0; k < countOfOutEdges; k++)
            {
                int nextTargetNode = countOfNodes - 1;
                bool y = false;
                int loopOut = 0;
                while ((y == false) && (loopOut < 10))
                {
                    int[,] adjMat = SGraphAlgorithms.GraphGetAdjacencyMatrix(T, E);

                    nextTargetNode = cu.RandomNumber(i, countOfNodes);
                    while ((nextTargetNode == i) || (nextTargetNode == countOfNodes))
                    {
                        nextTargetNode = cu.RandomNumber(i, countOfNodes);
                    }

                    y = SGraphAlgorithms.AddNewEdgeIsOK(adjMat, i, nextTargetNode);
                    loopOut++;
                }
                Edge e = new Edge();
                e.Edge_Init(T[startNode], T[nextTargetNode], cu.RandomNumber(erp.EdgeWeightMin, erp.EdgeWeightMax));
                E.Add(e);

            }

        }


        int[,] adjacencyMatrix = SGraphAlgorithms.GraphGetAdjacencyMatrix(T, E);
        E = SGraphAlgorithms.FixNotConnectedDAG(T, E, adjacencyMatrix, erp);
        adjacencyMatrix = SGraphAlgorithms.GraphGetAdjacencyMatrix(T, E);
        bool x = SGraphAlgorithms.GraphIsProperDAG(adjacencyMatrix);
        if (x)
        {

            job.SJob_Init(jobID, _DateSubmission, timeSubmission, ownerUserID, nodeSubmittdFrom, T, E, _SqlConnectionForLogging);
            return job;
        }
        else
        {
            return null;// zz or fix the problem!
        }

    }

    public class RequirementProfileForEdges
    {
        public double Connectivity; // 0<connectivity <1
        public int EdgeWeightMin, EdgeWeightMax;

        public void RequirementProfileForEdges_Init(double _Connectivity, int _EdgeWeightMin, int _EdgeWeightMax)
        {
            if (_Connectivity > 1) _Connectivity = 1;
            if (_Connectivity <= 0) _Connectivity = 0.1;
            Connectivity = _Connectivity;
            EdgeWeightMin = _EdgeWeightMin;
            EdgeWeightMax = _EdgeWeightMax;
        }

    }


    public class RequirementProfileForTasks
    {

        public void RequirementProfileForTasks_Init(int _TasksCPUNeedMin, int _TasksCPUNeedMax, int _TasksMemNeedMin, int _TasksMemNeedMax, int _TasksStorageNeedMin, int _TasksStorageNeedMax, int[] _NeededResourceTypes, int _MaxCountOfResourcesEachTaskMayNeed, double _TimeDeadlineFinalPercentageFromTaskSize, double _TimeDeadLinePreferedPercentageFromTaskSize)
        {
            TasksCPUNeedMin = _TasksCPUNeedMin;
            TasksCPUNeedMax = _TasksCPUNeedMax;
            TasksMemNeedMin = _TasksMemNeedMin;
            TasksMemNeedMax = _TasksMemNeedMax;
            TasksStorageNeedMin = _TasksStorageNeedMin;
            TasksStorageNeedMax = _TasksStorageNeedMax;
            NeededResourceTypes = _NeededResourceTypes;
            MaxCountOfResourcesEachTaskMayNeed = _MaxCountOfResourcesEachTaskMayNeed;
            TimeDeadlineFinalPercentageFromTaskSize = _TimeDeadlineFinalPercentageFromTaskSize;
            TimeDeadLinePreferedPercentageFromTaskSize = _TimeDeadLinePreferedPercentageFromTaskSize;
        }

        public int TasksCPUNeedMin, TasksCPUNeedMax;
        public int TasksMemNeedMin, TasksMemNeedMax;
        public int TasksStorageNeedMin, TasksStorageNeedMax;
        public int[] NeededResourceTypes; // an array which holds all resource types tasks may request for
        public int MaxCountOfResourcesEachTaskMayNeed; //1 or more 
        public double TimeDeadlineFinalPercentageFromTaskSize, TimeDeadLinePreferedPercentageFromTaskSize;// for example if TimeDeadlineFinalPercentageFromTaskSize=0.1 the deadlineFinal forthe task will be time requiremed to run 10% of its task lenftg+EST
    }


    public class Edge
    {
        public int StartNodeID, EndNodeID;
        public int Weight_Claimed, Weight_Predicted, Weight_Real;
        public void Edge_Init(DagInnerNode startNode, DagInnerNode endNode, int weightClaimed)
        {
            StartNodeID = startNode.TaskID;
            EndNodeID = endNode.TaskID;
            Weight_Claimed = weightClaimed;
        }
    }

    public class DagInnerNode
    {
        public decimal LengthInSecondsOnScheduledMachince = 0, LengthInSecondsOnBaseLineCpuCloudFog = 0, LengthInSecondsOnBaseLineCPUCloud = 0, LengthInSecondsOnBaseLineCpuFog = 0, LengthInSecondsOnBaseLineCpuIoT = 0;
        public CpuAndBandwidthBaseLines BaselineCPUAndBandwidth;
        //public List<Tuple<int, int>> PathWeightToOtherNodes = new List<Tuple<int, int>>(); //

        public string NodeID_CurrentlyOn; // pointer to the node which currently this task is on it.
        public int TaskID_InDB;
        public int OwnerJobID;
        public int EST = -1;
        public int EFT = -1;
        private int TaskStatus = JobAndTaskStatus.InitializedAndWaiting; //from JobAndTaskStatus
        public int TaskID;
        public float PriorityNo = 0;
        public Int64 CpuNeed_Claimed, CpuNeed_Predicted, CpuNeed_Real; // in Million Insructions
        public int MemoryNeedMax_Claimed, MemoryNeed_Real, MemoryNeed_Predicted;//in MB
        public int StorageNeed_Claimed, StorageNeed_Real, StorageNeed_Predicted;//in MB
        public int TimeSubmission, TimeDeadlineFinal, TimeDeadLinePrefered;
        public string DateSubmission = "";
        public List<int> NeededResourceTypes;

        public List<int> Predecessors = new List<int>(), SuccessorsImmediate = new List<int>(), SuccessorsNotImmediate = new List<int>();
        public List<int> NotRelevantTasks;// = new Dictionary<int, int>();
        public List<Edge> EdgesIn;// = new List<Edge>();
        public List<Edge> EdgesOut;// = new List<Edge>();




        public void Task_Init(Job _OwnerJob, int _TaskID, int _CpuNeed_Claimed, int _MemoryNeedMax_Claimed, int _StorageNeed_Claimed, int _TimeSubmission, int _TimeDeadlineFinal
            , int _TimeDeadLinePrefered, List<int> _NeededResourceTypes, string _DateSubmission, SqlConnection SqlConnectionForLogging)
        {
            NotRelevantTasks = new List<int>();
            EdgesIn = new List<Edge>();
            EdgesOut = new List<Edge>();

            this.DateSubmission = _DateSubmission;

            NeededResourceTypes = _NeededResourceTypes;
            TaskID = _TaskID;
            CpuNeed_Claimed = _CpuNeed_Claimed;
            MemoryNeedMax_Claimed = _MemoryNeedMax_Claimed;
            StorageNeed_Claimed = _StorageNeed_Claimed;
            TimeSubmission = _TimeSubmission;
            TimeDeadlineFinal = _TimeDeadlineFinal;
            TimeDeadLinePrefered = _TimeDeadLinePrefered;
            this.TaskStatus = JobAndTaskStatus.InitializedAndWaiting;
            this.NodeID_CurrentlyOn = _OwnerJob.NodeSubmitted;
            InitTaskInDatabase(SqlConnectionForLogging, _OwnerJob);
            SetTaskStatus(SqlConnectionForLogging, _OwnerJob, this.DateSubmission, TimeSubmission, this.TaskStatus);
        }
        void InitTaskInDatabase(SqlConnection SqlConnforLog, Job OwnerJob)
        {
            int _taskid_inDB;

            if (SqlConnforLog.State != ConnectionState.Open) SqlConnforLog.Open();
            using (SqlCommand cmd = new SqlCommand("SP_TaskInit", SqlConnforLog))
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@Date", SqlDbType.NVarChar).Value = this.DateSubmission;
                cmd.Parameters.Add("@PriorityNo", SqlDbType.Float).Value = this.PriorityNo;
                cmd.Parameters.Add("@ListOfResourceNeeds", SqlDbType.NVarChar).Value = GetResourcesNeedAsString();
                cmd.Parameters.Add("@NodeID_SubmittedOn", SqlDbType.NVarChar).Value = OwnerJob.NodeSubmitted;
                cmd.Parameters.Add("@TaskID", SqlDbType.Int).Value = this.TaskID;
                cmd.Parameters.Add("@OwnerJobID", SqlDbType.Int).Value = this.OwnerJobID;

                cmd.Parameters.Add("@CPUNeed_Claimed", SqlDbType.BigInt).Value = this.CpuNeed_Claimed;
                cmd.Parameters.Add("@RAMNeed_Claimed", SqlDbType.Int).Value = this.MemoryNeedMax_Claimed;
                cmd.Parameters.Add("@StorageNeed_Claimed", SqlDbType.Int).Value = this.StorageNeed_Claimed;

                cmd.Parameters.Add("@CPUNeed_Predicted", SqlDbType.BigInt).Value = this.CpuNeed_Predicted;
                cmd.Parameters.Add("@RAMNeed_Predicted", SqlDbType.Int).Value = this.MemoryNeed_Predicted;
                cmd.Parameters.Add("@StorageNeed_Predicted", SqlDbType.Int).Value = this.StorageNeed_Predicted;

                cmd.Parameters.Add("@CPUNeed_Real", SqlDbType.BigInt).Value = this.CpuNeed_Real;
                cmd.Parameters.Add("@RAMNeed_Real", SqlDbType.Int).Value = this.MemoryNeed_Real;
                cmd.Parameters.Add("@StorageNeed_Real", SqlDbType.Int).Value = this.StorageNeed_Real;

                cmd.Parameters.Add("@TimeSubmission", SqlDbType.Int).Value = this.TimeSubmission;


                var tiidb = cmd.Parameters.Add("@ReturnVal", SqlDbType.Int);
                tiidb.Direction = ParameterDirection.ReturnValue;
                cmd.ExecuteNonQuery();
                _taskid_inDB = Convert.ToInt32(tiidb.Value);
            }
            this.TaskID_InDB = _taskid_inDB;


        }
        string GetResourcesNeedAsString()
        {
            string s = "";
            for (int i = 0; i < this.NeededResourceTypes.Count; i++)
            {
                s = s + this.NeededResourceTypes[i].ToString() + ",";

            }
            s = s.Substring(0, s.Length - 1);
            return s;
        }
        public static class OperatingSystemTypes
        {
            public static int Windows = 1, Macos = 2, Linux = 3, Solaris = 4, Android = 5;



        }

        public int GetTaskStatus()
        {
            return this.TaskStatus;
        }
        public void SetTaskStatus(SqlConnection SqlConnforLog, Job OwnerJob, string date, int SimulationTime, int TaskStatusCode)    //JobStatusCode from JobAndTaskStatus
        {
            int oldStatus = this.TaskStatus;
            this.TaskStatus = TaskStatusCode;
            try
            {
                if ((SqlConnforLog != null))
                {
                    if (SqlConnforLog.State != ConnectionState.Open) SqlConnforLog.Open();
                    using (SqlCommand cmd = new SqlCommand("SP_TaskStateChange", SqlConnforLog))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.Add("@PriorityNo", SqlDbType.Float).Value = this.PriorityNo;
                        cmd.Parameters.Add("@NodeIDCurrently", SqlDbType.NVarChar).Value = this.NodeID_CurrentlyOn;
                        cmd.Parameters.Add("@NewState", SqlDbType.NVarChar).Value = JobAndTaskStatus.getStatusText(this.TaskStatus);
                        cmd.Parameters.Add("@OldState", SqlDbType.NVarChar).Value = JobAndTaskStatus.getStatusText(oldStatus);
                        cmd.Parameters.Add("@TaskID_InDB", SqlDbType.Int).Value = this.TaskID_InDB;
                        cmd.Parameters.Add("@TaskID", SqlDbType.Int).Value = this.TaskID;
                        cmd.Parameters.Add("@Time", SqlDbType.Int).Value = SimulationTime;
                        cmd.Parameters.Add("@Date", SqlDbType.NVarChar).Value = date;
                        cmd.Parameters.Add("@OwnerJobID", SqlDbType.Int).Value = OwnerJob.JobID;


                        cmd.ExecuteNonQuery();
                    }
                }
            }
            catch (Exception ee)
            {


            }


        }



    }

}