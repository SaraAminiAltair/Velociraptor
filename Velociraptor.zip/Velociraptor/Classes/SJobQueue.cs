﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

public class SJobQueue
{
    public Queue<Job> JobsInQueue;
    public Queue<Job> JobsOutQueue;
    public Queue<Job> JobsExecutedByNode;
    public Queue<Job> JobsGeneratedByNodeWaitQueue;
    public SJobQueue()
    {
        JobsInQueue = new Queue<Job>();//jobs to be processes: scheduled on this node or be put into JobOutQueue for forwarding to other nodes
        JobsOutQueue = new Queue<Job>(); //jobs to be sent to other nodes for execution.
        JobsExecutedByNode = new Queue<Job>(); //finished Jobs
        JobsGeneratedByNodeWaitQueue = new Queue<Job>();// jobs created by this node but have not put to JobsInQueue or JobsOutQueue

    }


}
