﻿
using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Web;
 
using System.Net;


public class zRaponSecurity
{
    public string RSCN, uaid, uNameFamily, uType;

   
    public string MakeInjectionSafeString(string s)
    {
        s = s.ToLower();
        s = s.Replace("'", "''");
        s = s.Replace(" or ", "");
        s = s.Replace(" and ", "");
        s = s.Replace(" select ", "");
        s = s.Replace(" = ", "");
        s = s.Replace("drop", "");
        s = s.Replace("update", "");
        s = s.Replace("delete", "");
        s = s.Replace("Tbl", "");
        return s;
    }

  
}
