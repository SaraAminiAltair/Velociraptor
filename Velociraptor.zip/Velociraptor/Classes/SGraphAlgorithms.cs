﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for SGraphAlgorithms
/// </summary>
public class SGraphAlgorithms
{


    public static int[,] GraphGetAdjacencyMatrix(List<Job.DagInnerNode> nodes, List<Job.Edge> edges)
    {
        int len = nodes.Count;
        int[,] am = new int[len, len];
        for (int i = 0; i < len; i++)
        {
            int nodeStart = i;
            for (int j = 0; j < len; j++)
            {
                am[i, j] = 0;
                int nodeEnd = j;
                foreach (Job.Edge e in edges)
                {
                    if ((e.StartNodeID== nodeStart) && (e.EndNodeID== nodeEnd)) am[nodeStart, nodeEnd] = e.Weight_Claimed;
                }
            }
        }
        return am;

    }
    public static bool AddNewEdgeIsOK(int[,] adjacencyMatrix, int startNodeID, int endNodeID)
    {
        int x = adjacencyMatrix[startNodeID, endNodeID];
        if (x > 0) return false; //already has an edge
        x = adjacencyMatrix[endNodeID, startNodeID];
        if (x == 0) return true;
        else return false;
    }

    public static int[] GetNoOutNodes(int[,] adjacencyMatrix)
    {
        string r = "";
        for (int i = 0; i < adjacencyMatrix.GetLength(0)-1; i++) //Last node has no output edge
        {
            bool hasOutputEdge = false;
            for (int j = 0; j < adjacencyMatrix.GetLength(1); j++)
            {
                if (adjacencyMatrix[i, j] > 0) { hasOutputEdge = true; break; }
            }
            if (hasOutputEdge == false)
            {
                r = r + "," + i.ToString();
            }
        }
        string[] rr = r.Split(',');
        int[] res = new int[rr.Length-1];
        for (int i = 1; i <= res.Length; i++)
        {
            res[i-1] = Convert.ToInt32(rr[i]);
        }
        return res;

    }



    public static int[] GetNoInNodes(int[,] adjacencyMatrix)
    {
        string r = "";
        for (int i = 1; i < adjacencyMatrix.GetLength(0); i++) //First node has no entry edge
        {
            bool hasInputEdge = false;
            for (int j = 0; j < adjacencyMatrix.GetLength(1); j++)
            {
                if (adjacencyMatrix[j, i] > 0) { hasInputEdge = true; break; }
            }
            if (hasInputEdge == false)
            {
                r = r + "," + i.ToString();
            }
        }
        string[] rr = r.Split(',');
        int[] res = new int[rr.Length-1];
        for (int i = 1; i <= res.Length; i++)
        {
            res[i-1] = Convert.ToInt32(rr[i]);
        }
        return res;

    }

    public static bool GraphAllNodesHasInandOut(int[,] adjacencyMatrix)
    {
        bool x = GraphAllNodesHasInEdge(adjacencyMatrix);
        if (x)
        {
            x = GraphAllNodesHasOutEdge(adjacencyMatrix);
            if (x) return true; else return false;
        }
        else return false;
            
    }

    public static bool GraphAllNodesHasInEdge(int[,] adjacencyMatrix)
    {
        int[] li = GetNoInNodes(adjacencyMatrix);
        if (li.Length == 0) return true; else return false;
    }

    public static bool GraphAllNodesHasOutEdge(int[,] adjacencyMatrix)
    {
        int[] li = GetNoOutNodes(adjacencyMatrix);
        if (li.Length == 0) return true; else return false;
    }
    public static bool GraphIsProperDAG(int[,] adjacencyMatrix)
    {
        bool x;

        x = GraphAcyclic(adjacencyMatrix);
        if (x)
        {
            x = GraphHasPathFromFirstNodeToFinalNode(adjacencyMatrix);
            if (x)
            {

                x = GraphAllNodesHasInandOut(adjacencyMatrix);
                if (x) return true; else return false;
            }
            else return false;
        }
        else
        {
            return false;
        }
    }

    public static bool GraphAcyclic(int[,] adjacencyMatrix)
    {
        return true;
    }
    public static bool GraphHasPathFromFirstNodeToFinalNode(int[,] adjacencyMatrix)
    {
        return true;
    }

    public static List<Job.Edge> FixNotConnectedDAG(List<Job.DagInnerNode> T, List<Job.Edge> E, int[,] adjMat, Job.RequirementProfileForEdges erp)
    {
        CoUtils cu = new CoUtils();
        int[] iNodes = GetNoInNodes(adjMat);
        for (int i = 0; i < iNodes.GetLength(0); i++)
        {
            Job.Edge e = new Job.Edge();
            e.Edge_Init(T[0], T[iNodes[i]], cu.RandomNumber(erp.EdgeWeightMin, erp.EdgeWeightMax));
            E.Add(e);
        }
        adjMat = GraphGetAdjacencyMatrix(T, E);
        int[] oNodes = GetNoOutNodes(adjMat);
        for (int i = 0; i < oNodes.GetLength(0); i++)
        {
            Job.Edge e = new Job.Edge();
            e.Edge_Init(T[oNodes[i]], T[T.Count - 1], cu.RandomNumber(erp.EdgeWeightMin, erp.EdgeWeightMax));
            E.Add(e);
        }


        return E;
    }


}