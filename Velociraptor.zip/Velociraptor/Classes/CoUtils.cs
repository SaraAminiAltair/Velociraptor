﻿using System;
using System.Data;
using System.Configuration;
using System.Web;
 
using System.Text;

using System.Collections.Generic;
using System.Net;
using System.Net.Mail;
using System.Data.SqlClient;
 
using System.Collections;
 


using System.Media;
using System.Globalization;
using System.Diagnostics;
using System.Drawing;
using System.Security.Cryptography;
using System.IO;
using System.Text.RegularExpressions;
using System.Xml.Serialization;

/// <summary>
/// Summary description for iBCCUtility
/// </summary>
public   class CoUtils
{
   

    zRaponSecurity sc;

  public   string ListToString(List<int> _list)
    {
        string s = "[";
        foreach (int n in _list)
        {
            if (s != "[") s += ",";
            s += n.ToString();
        }
        s += "]";
        return s;
    }

    public List<string>  ListCopy(List<string> theList)
    {
        List<string> l = new List<string>();
        foreach (string item in theList)
        {
            l.Add(item);

        }
        return l;
    }

  public  string ListToString(List<Job.DagInnerNode> _list)
    {
        string s = "[";
        foreach (Job.DagInnerNode n in _list)
        {
            if (s != "[") s += ",";
            s += n.TaskID.ToString();
        }
        s += "]";
        return s;
    }
   public  string ListToString(List<string> _list)
    {
        //input list with strings and out put will be like this: [[1],[2,5,6],[3,4],[7]]
        string s = "[";
        foreach (string l in _list)
        {
            if (s != "[") s += ",";
            s += "[" + l + "]";
        }
        s += "]";
        return s;
    }
  public  string ListToString(int[] arr)
    {
        //input array of {1,2,3} with strings and out put will be like this: [1,2,3]
        string s = "[";
        for (int i = 0; i < arr.Length; i++)
        {
            string l = arr[i].ToString();
            if (s != "[") s += ",";
            s += l;
        }
        s += "]";
        return s;
    }



    public int getTimeDifferenceInMinute(string TimeEarlier, string TimeLater) // return TimeLater-TimeEarlier in minutes
    {
        int LaterHour = Convert.ToInt32(TimeLater.Substring(0, 2))
        , LaterMin = Convert.ToInt32(TimeLater.Substring(3, 2))
            , EarlierHour = Convert.ToInt32(TimeEarlier.Substring(0, 2))
            , EarlierMin = Convert.ToInt32(TimeEarlier.Substring(3, 2));
        int HourGap = LaterHour - EarlierHour;
        int MinuteGap = LaterMin - EarlierMin;
        if ((HourGap < 0) || ((HourGap == 0) && (MinuteGap < 0)))
        {
            return -1;
        }

        if (HourGap == 0)
        {
            return MinuteGap;
        }
        else // HourGap is definitely bigger than zero
        {

            int hoursMinute = (HourGap - 1) * 60;
            int minAdd = 60 - EarlierMin;
            return (hoursMinute + minAdd + LaterMin);

        }


    }

    public List<int> GetRandomElementsOfArray(int[] arr, int countOfElemetsToPick)
    {
        List<int> r = new List<int>();
        for (int i = 0; i < countOfElemetsToPick; i++)
        {

            int index = RandomNumber(0, arr.Length - 1);
            while (r.IndexOf(arr[index]) >= 0)
            {
                index = RandomNumber(0, arr.Length - 1);
            }
            r.Add(arr[index]);

        }
        return r;

    }

    public string Dictionary_convertToStr(Dictionary<string, string> data)
    {
        // Build up the string data.
        StringBuilder builder = new StringBuilder();
        foreach (var pair in data)
        {
            builder.Append(pair.Key).Append(":").Append(pair.Value).Append(',');
        }
        string result = builder.ToString();
        // Remove the end comma.
        result = result.TrimEnd(',');
        return result;
    }

    public Dictionary<string, string> Dictionary_fromStr(string theStr)
    {
        var result = new Dictionary<string, string>();
         
        // Split the string.
        string[] tokens = theStr.Split(new char[] { ':', ',' },
            StringSplitOptions.RemoveEmptyEntries);
        // Build up our dictionary from the string.
        for (int i = 0; i < tokens.Length; i += 2)
        {
            string name = tokens[i];
            string value = tokens[i + 1];

            result.Add(name, value);

        }
        return result;
    }




    public static Int32 DBSafeReadInt32(DataTable dt, string fieldname, int rowIndex, int ifNullValue)
    {
        string r = DBSafeReadString(dt, fieldname, rowIndex);
        if (r == "") return ifNullValue;
        try
        {
            return Convert.ToInt32(r);

        }
        catch (Exception)
        {

            return ifNullValue;
        }
    }
    public static Int64 DBSafeReadInt64(DataTable dt, string fieldname, int rowIndex, int ifNullValue)
    {
        string r = DBSafeReadString(dt, fieldname, rowIndex);
        if (r == "") return ifNullValue;
        try
        {
            return Convert.ToInt64(r);

        }
        catch (Exception)
        {

            return ifNullValue;
        }
    }

    public static string DBSafeReadString(DataTable dt, string fieldname, int rowIndex)
    {
        try
        {
            return dt.Rows[rowIndex][fieldname].ToString();
        }
        catch (Exception)
        {
            return "";
        }


    }

    public string ComposeErrorMessages(String[] Errors)
    {
        String err = "";
        string nl;
        for (int i = 0; i < Errors.Length; i++)
        {
            if (err != "") nl = "<br>"; else nl = "";
            if (Errors[i] != "") err += nl + Errors[i];
        }
        return err;
    }

   
    public string MergeArray(Int64[] array, char mergedelimiter)
    {
        string x = "";
        for (int i = 0; i < array.Length; i++)
        {
            string t = array[0].ToString();
            x += t;
            if ((i + 1) < array.Length) x += ",";
        }
        return x;
    }
    public String ReadWebPage(String PageURL)
    {
        string html = String.Empty; ;
        try
        {
            WebRequest request = WebRequest.Create(PageURL);// "http://www.google.com");
            WebResponse response = request.GetResponse();
            Stream data = response.GetResponseStream();

            using (StreamReader sr = new StreamReader(data))
            {
                html = sr.ReadToEnd();
            }
        }
        catch (Exception e)
        {
        }
        return html;
    }
    


    public DataTable LoadDataTableFromStoredProcedure(zRaponDB DAL, String SP_Name, String[] SP_KeyName, String[] SP_KeyValue, Type[] SP_KeyType)
    {
        try
        {
            String TableName = "data";
            DataTable dt = new DataTable();
            SqlConnection conn = DAL.getConnectionObject();
            if (conn.State != ConnectionState.Open) conn.Open();
            using (SqlCommand cmd = new SqlCommand(SP_Name, conn))
            {
                cmd.CommandType = CommandType.StoredProcedure;

                for (int i = 00; i < SP_KeyValue.Length; i++)
                {
                    if (SP_KeyType[i] == typeof(Int64))
                    {
                        cmd.Parameters.Add(SP_KeyName[i], SqlDbType.BigInt).Value = Convert.ToInt64(SP_KeyValue[i]);
                    }
                    else if (SP_KeyType[i] == typeof(Int32))
                    {
                        cmd.Parameters.Add(SP_KeyName[i], SqlDbType.Int).Value = Convert.ToInt32(SP_KeyValue[i]);
                    }
                    else if (SP_KeyType[i] == typeof(String))
                    {
                        cmd.Parameters.Add(SP_KeyName[i], SqlDbType.NVarChar).Value = SP_KeyValue[i];
                    }
                }


                SqlDataReader sdr = cmd.ExecuteReader();
                Boolean b = sdr.HasRows;
                dt.Load(sdr);
                dt.TableName = TableName;
                sdr.Close();
            }
            return dt;
        }
        catch (Exception e)
        {

            return null;
        }
    }

   
    
   
    public String BreakStringIntoMultiLines_BR_Separated(String text, int inRowCharacterCount)
    {
        string result = string.Empty;
        for (int i = 0; i < text.Length; i++)
            result += (i % inRowCharacterCount == 0 && i != 0) ? (text[i].ToString() + "\n") : text[i].ToString();
        return result;


    }


    public DataTable BreakDataTableFieldToMultiLineText(DataTable dt, String ColumnName, String ColumnNameToBeAdded, int MaxCharacterInRow)
    {
        DataTable dt_A;
        dt_A = dt.Copy();
        dt_A.Columns.Add(ColumnNameToBeAdded, typeof(System.String));
        for (int i = 0; i < dt.Rows.Count; i++)
        {
            dt_A.Rows[i][ColumnNameToBeAdded] = BreakStringIntoMultiLines_BR_Separated(dt_A.Rows[i][ColumnName].ToString(), MaxCharacterInRow);
        }

        return dt_A;

    }

   
    

    public int min(int a, int b)
    {
        if (a > b) return b; else return a;
    }

    
 

    public void AddDummyRow(out DataView dv, DataTable dt, string colTitleName, string colNumberName, string dummytext, int dummyvalue, string SortFieldName)
    {
        DataRow dr = dt.NewRow();
        dr[colTitleName] = dummytext;
        dr[colNumberName] = dummyvalue;
        dt.Rows.Add(dr);
        dv = dt.DefaultView;
        dv.Sort = SortFieldName;
    }

    

    public string ListOfUsersThatThisUserHasPriviledges(zRaponDB _DAL, string PriviledgeFieldName, string UserAutoId)
    {

        string list = "";
        string Q = "select " + PriviledgeFieldName + " from ViewEmployee where SiteUserAutoId=" + UserAutoId;
        DataSet ds = _DAL.GetDataSet(Q);
        try
        {
            if ((ds.Tables[0].Rows.Count > 0) && (ds.Tables[0].Rows[0][PriviledgeFieldName] != null))
            {
                list = ds.Tables[0].Rows[0][PriviledgeFieldName].ToString();
            }
        }
        catch { }
        return list;
    }



    public string Make_OR_AND_sqlString(string[] list, string FieldName, bool isStringValue, string AND_or_OR)
    {
        string c = "";
        if (isStringValue) c = "'";

        string V = "";
        string _V = AND_or_OR;

        string s = "(";
        for (int i = 0; i < list.Length; i++)
        {
            s += " " + V + " ( " + FieldName + " = " + c + list[i] + c + " )";
            V = _V;
        }
        s += ")";
        return s;
    }
    

    static Random random = new Random();
    int seed = Convert.ToInt32(random.NextDouble());

    public string AddMonthToDate(string PersianDate, int countOfMonthToBeAdded)
    {
        int y, m, d;
        PersianDateExtract(PersianDate, out y, out m, out d);

        int c = countOfMonthToBeAdded / 12;
        y = y + c;

        string newdate = y + "/" + m + "/" + d;
        return newdate;
    }

    public static void LogExceptionToFile( Exception e)
    {
        try
        {
         //   string logtext = "\n" + "PageName=" + thisPage.PageName + ",\n\tDate=" + thisPage.AccessDate + ",\n\tTime=" + thisPage.AccessTime + ",\n\tDescription=" + e.Message.ToString() + ",\n\tUserIP=" + thisVisitor.UserIP + ",\n\tUserId=" + thisVisitor.UserId;
       // zz    string logfilepath = Server.MapPath(ConfigurationManager.AppSettings["ExceptionLogFilePath"].ToString());
       //     zRaponUtils.writeToLogfile(logfilepath, logtext);
        }
        catch (Exception ee)
        {
            // LogException(e);
        }

    }

    public void FileDelete(string filename)
    {
        try { File.Delete(filename); } catch (Exception) { }

    }

    public static void writeToLogfile(string logfilename, string LogText)
    {
        try
        {
            if (logfilename == "")
            {
                //      logfilename = Request.PhysicalApplicationPath.Replace("\\www\\", "") + "logs\\errorlog.txt";
            }
            //  if (! System.IO.File.Exists(logfilename))  { System.IO.File.Create(logfilename); }
            System.IO.StreamWriter sw = new System.IO.StreamWriter(logfilename, true);
            sw.Write(LogText + "\n\r");
            sw.Close();


        }
        catch (Exception x) { }

    }

    public string ExtractHourFromTime(String Time)
    {
        //input should be in 23:12 format
        return (Time.Substring(0, 2));
    }

    public string ExtractMinuteFromTime(String Time)
    {
        //input should be in 23:12 format
        return ((Time.Substring(3, 2)));
    }


    public int GetCurrentTimeHour()
    {
        string t = getCurrentTime_24Format();
        t = t.Substring(0, 2);
        return (Convert.ToInt32(t));
    }

    public int GetCurrentTimeMinute()
    {
        string t = getCurrentTime_24Format();
        t = t.Substring(3, 2);
        return (Convert.ToInt32(t));
    }

    public string persianTimeFormat(string _t)
    {
        try
        {
            string a = _t;
            a = a.Substring(5, 2) + " :" + a.Substring(0, 2);
            return a;
        }
        catch
        { return _t; }
    }

    public string NNDate(string d)
    {
        d = NN(d);
        return (PersianDateFormat(d));
    }

    public string PersianDateFormat(string _d)
    {
        try
        {
            string a = _d;
            a = a.Substring(8, 2) + " /" + a.Substring(5, 2) + " /" + a.Substring(0, 4);
            return a;
        }
        catch
        { return _d; }

    }
    public string CreatePersianDate(int year, int month, int day)
    {
        string y, m, d;
        if (year < 200) y = "13" + year.ToString(); else y = year.ToString();
        if (month < 10) m = "0" + month.ToString(); else m = month.ToString();
        if (day < 10) d = "0" + day.ToString(); else d = day.ToString();

        return y + "/" + m + "/" + d;
    }
    public void PersianDateExtract(string _persiandate, out int year, out int month, out int day)
    {
        string yy = _persiandate;
        year = Int32.Parse(yy.Substring(0, 4));
        month = Int32.Parse(yy.Substring(5, 2));
        day = Int32.Parse(yy.Substring(8, 2));
    }

    public int GetCurrentPersianYear()
    {
        int y, m, d;
        PersianDateExtract(getCurrentPersianDateFull(), out y, out m, out d);
        return y;
    }

    public int GetCurrentPersianMonth()
    {
        int y, m, d;
        PersianDateExtract(getCurrentPersianDateFull(), out y, out m, out d);
        return y;
    }

    public int GetCurrentPersianDay()
    {
        int y, m, d;
        PersianDateExtract(getCurrentPersianDateFull(), out y, out m, out d);
        return y;
    }

    public void PersianDateExtract(string _persiandate, out string year, out string month, out string day)
    {
        string yy = _persiandate;
        year = yy.Substring(0, 4);
        month = yy.Substring(5, 2);
        day = yy.Substring(8, 2);
    }

     

     
    public string RandomString(int size, bool lowerCase)
    {
        StringBuilder builder = new StringBuilder();
        // Random random = new Random(getRandomSeed());
        char ch;
        for (int i = 0; i < size; i++)
        {
            ch = Convert.ToChar(Convert.ToInt32(Math.Floor(26 * random.NextDouble() + 65)));
            builder.Append(ch);
        }
        if (lowerCase)
            return builder.ToString().ToLower();
        return builder.ToString();
    }


    public bool SendEmail(string Body, string Subject, string To, string MailServer, string MailAccount, string Password)
    {
        try
        {
            var fromAddress = new MailAddress(MailAccount);
            var toAddress = new MailAddress(To);
            string fromPassword = Password;
            string subject = Subject;
            string body = Body;

            var smtp = new SmtpClient
            {
                Host = MailServer,
                Port = 587,
                EnableSsl = true,
                DeliveryMethod = SmtpDeliveryMethod.Network,
                Credentials = new NetworkCredential(fromAddress.Address, fromPassword),
                Timeout = 20000
            };
            using (var message = new MailMessage(fromAddress, toAddress)
            {
                Subject = subject,
                Body = body,
                IsBodyHtml = true,
                BodyEncoding = Encoding.UTF8
            })
            {
                smtp.Send(message);
            }
            return true;
        }
        catch (Exception ee)
        {
            throw ee;
            return false;
        }
    }
    public bool SendEmail2(string Body, string Subject, string To, string MailServer, string MailAccount, string Password)
    {
        try
        {
            SmtpClient client = new SmtpClient(MailServer);
            client.Port = 587;
            client.EnableSsl = true;
            client.UseDefaultCredentials = false;
            NetworkCredential loginInfo = new NetworkCredential(MailAccount, Password);

            MailMessage msg = new MailMessage();
            msg.From = new MailAddress(MailAccount);
            msg.To.Add(new MailAddress(To));
            msg.Subject = Subject;
            msg.Body = Body;
            msg.IsBodyHtml = true;
            msg.BodyEncoding = Encoding.UTF8;
            System.Net.Mail.SmtpClient sc = new System.Net.Mail.SmtpClient();

            MailServer = MailServer.ToLower();
            MailServer = MailServer.TrimStart(' ');
            MailServer = MailServer.TrimEnd(' ');


            client.Credentials = loginInfo;
            client.Send(msg);
            return true;
        }
        catch (Exception ee)
        {
            return false;
        }
    }
   

    public string GetPageNameFromString(string _PageFullCurrentAddress)
    {
        string[] f = _PageFullCurrentAddress.Split(new char[] { '/' });
        string pagename = f[f.Length - 1];
        return pagename;
    }


    public void ExtractStyleFromString(string InLineCssStyleString, out string[] CssStyleKeys, out string[] CssStyleValues)
    {
        string[] sty = InLineCssStyleString.Split(';');
        string[] t;
        int c = 0;
        for (int i = 0; i < sty.Length; i++)
        {
            if (sty[i] != "") c++;

        }
        string[] StyleKeys = new string[c];
        string[] StyleValues = new string[c];
        int index = -1;
        for (int i = 0; i < sty.Length; i++)
        {
            if (sty[i] != "")
            {
                index++;
                t = sty[i].Split(':');
                try
                {
                    StyleKeys[index] = t[0];
                    StyleValues[index] = t[1];
                    t = null;
                }
                catch (Exception eee) { StyleKeys[index] = ""; StyleValues[index] = ""; }
            }
        }
        CssStyleKeys = StyleKeys;
        CssStyleValues = StyleValues;
    }




    public DateTime? ConverToGergorianDate(string _PersianDate)
    {
        if (_PersianDate == "") return null;
        try
        {
            PersianCalendar PersianDate = new PersianCalendar();
            int Month, Day, Year;
            Year = Convert.ToInt32(_PersianDate.Substring(0, 4));
            Month = Convert.ToInt32(_PersianDate.Substring(5, 2));
            Day = Convert.ToInt32(_PersianDate.Substring(8, 2));
            return (PersianDate.ToDateTime(Year, Month, Day, 0, 0, 0, 0));
        }
        catch (Exception e)
        {
            return null;
        }

    }



    private int getRandomSeed()
    {
        DateTime x = DateTime.Now;
        float mins = x.Minute;
        float secs = x.Second;
        float hour = x.Hour;
        seed++;
        return (seed + Convert.ToInt32(Math.Ceiling((decimal)Convert.ToInt32((secs * mins) + hour))));

    }


    public int SC(string a, string b)
    {
        return string.Compare(a, b, true);
    }


    public DateTime r(string _value)
    {
        return (Convert.ToDateTime(_value));
    }

    public string ConverToPerianDate(string _date)
    {
        if (_date == "") return "";
        try
        {
            DateTime x = r(_date);
            return (ConverToPerianDate(x));
        }
        catch (Exception e)
        { return ""; }
    }

    public string ConverToPerianDate(DateTime _date)
    {
        try
        {
            PersianCalendar PersianDate = new PersianCalendar();
            int t;
            string strMonth, strDay, CompletePersianDate;
            t = PersianDate.GetMonth(_date);
            if (t < 10) { strMonth = "0" + t.ToString(); } else { strMonth = t.ToString(); }
            t = PersianDate.GetDayOfMonth(_date);
            if (t < 10) { strDay = "0" + t.ToString(); } else { strDay = t.ToString(); }
            CompletePersianDate = PersianDate.GetYear(_date) + "/" + strMonth + "/" + strDay;
            return CompletePersianDate;
        }
        catch (Exception e)
        { return ""; }

    }


    public string getCurrentPersianDateFull()
    {
        return ConverToPerianDate(DateTime.Now);
    }

    int DaysInMonth(int monthNumber)
    {
        int daysinmonth = 31;
        if (monthNumber >= 7) daysinmonth = 30;
        if (monthNumber == 12) daysinmonth = 29;
        return daysinmonth;
    }


    public string GetDateDaysBack(string BaseDate, int daysToGoBack)
    {
        int y, m, d;
        PersianDateExtract(BaseDate, out y, out m, out d);
        int residu;
        if (d <= daysToGoBack)
        {
            residu = daysToGoBack - d;

            int monthToDecrease = (residu / 31) + 1;
            if (m <= monthToDecrease)
            {//year should be decreased...
                residu = residu - 31 * (m - 1);

                int yearsToMinus = (residu / 365) + 1;
                y = y - yearsToMinus;
                int monthToMinus = (residu / 31);
                int monthToMinusInLocalYear = monthToMinus - (yearsToMinus - 1) * 12;
                int newMonth = 12 - monthToMinusInLocalYear;
                residu = residu - monthToMinus * 31;
                if (residu == 0) residu++;
                int newDay = residu;
                d = newDay;
                m = newMonth;
            }
            else
            {
                m = m - monthToDecrease;
                residu = residu - (monthToDecrease - 1) * 31;
                int newDay = 31 - residu;
                d = newDay;
            }
        }
        else
        {
            d = d - daysToGoBack;
        }


        if (m <= 0) m = 1;
        if (d <= 0) d = 1;
        if (y <= 0) y = 1396;
        if ((m > 6) && (d == 31)) d = 30;  //nimeye dovom sal
        if ((m == 12) && (d == 30)) d = 29; //esfand
        string day = d.ToString();
        if (d < 10) day = "0" + day;
        string month = m.ToString();
        if (m < 10) month = "0" + month;
        string newdate = y + "/" + month + "/" + day;
        return newdate;
    }

    public  double[] RandomNumber(double min, double max, int count)
    {
        double[] r = new double[count];

        for (int i = 0; i < count; i++)
        {
            r[i] = RandomNumber(min, max);
        }

        return r;

    }

    public string RandomNumber(int Digits)
    {
        StringBuilder builder = new StringBuilder();
        char ch;
        ch = Convert.ToChar(Convert.ToInt32(Math.Floor(8 * random.NextDouble() + 49)));
        builder.Append(ch);

        for (int i = 1; i < Digits; i++)
        {
            ch = Convert.ToChar(Convert.ToInt32(Math.Floor(10 * random.NextDouble() + 48)));
            builder.Append(ch);
        }
        return builder.ToString();
    }
    public  double RandomNumber(double min,double max)
    {
        double r= random.NextDouble();
        double d = max - min;
        r = r * d;
        r = r + min;
        return r;
    }
    public int RandomNumber(int min, int max)
    {
        int  r = Convert.ToInt32( RandomNumber(Convert.ToDouble( min), Convert.ToDouble(max)));
        return r;
    }
    public string ToFormattedNumber(string number)
    {
        return String.Format("{0:0,0}", number);
    }


    public string Qstr(string _str)
    {
        return ("'" + sc.MakeInjectionSafeString(_str) + "'");

    }

    public string NND(string s)  // Not Null, if s=="" then return "-"
    {
        if (NN(s) == "") { return ("-"); } else { return s; }
    }
    public string NN(string s)  // Not Null
    {

        if (s == null) { return (""); } else { return s; }
    }
    public string NNN(string s)  // this method returns a numberable string
    {
        string x = NN(s);
        try { Int64 h = Convert.ToInt64(x); return x; }
        catch (Exception e) { return "0"; }
    }

    public Int32 ToI(string _Value)
    {
        return Convert.ToInt32(NNN(_Value));

    }
    public Int64 ToI64(string _Value)
    {
        return Convert.ToInt64(NNN(_Value));

    }


    public string getCurrentTime_24Format()
    {
        string h = DateTime.Now.Hour.ToString();
        if (h.Length == 1) h = "0" + h;

        string m = DateTime.Now.Minute.ToString();
        if (m.Length == 1) m = "0" + m;

        return h + ":" + m;
    }

    public string getCurrentTime_24Format_WithSeconds()
    {

        string s = DateTime.Now.Second.ToString();
        if (s.Length == 1) s = "0" + s;
        return getCurrentTime_24Format() + ":" + s;
    }



    public string GetMD5Hash(string data)
    {
        //create new instance of md5
        MD5 md5 = MD5.Create();

        //convert the input text to array of bytes
        byte[] hashData = md5.ComputeHash(Encoding.Default.GetBytes(data));

        //create new instance of StringBuilder to save hashed data
        StringBuilder returnValue = new StringBuilder();

        //loop for each byte and add it to StringBuilder
        for (int i = 0; i < hashData.Length; i++)
        {
            returnValue.Append(hashData[i].ToString());
        }

        // return hexadecimal string
        return returnValue.ToString();

    }

    /// <summary>
    /// encrypt input text using MD5 and compare it with
    /// the stored encrypted text
    /// </summary>
    /// <param name="inputData">input text you will enterd to encrypt it</param>
    /// <param name="storedHashData">the encrypted text
    ///         stored on file or database ... etc</param>
    /// <returns>true or false depending on input validation</returns>
    public bool ValidateMD5Hash(string inputData, string storedHashData)
    {
        //hash input text and save it string variable
        string getHashInputData = GetMD5Hash(inputData);

        if (string.Compare(getHashInputData, storedHashData) == 0)
        {
            return true;
        }
        else
        {
            return false;
        }
    }

    public static String GetNumberWith1000Separator(Int32 number)
    {
        String r = string.Format("{0:n0}", number);
        //r=r.Replace(",","/");
        //r=r.Replace(".","/");
        return r;
    }
    public static String GetNumberWith1000Separator(Int64 number)
    {
        String r = string.Format("{0:n0}", number);
        //r=r.Replace(",","/");
        //r=r.Replace(".","/");
        return r;
    }



}
