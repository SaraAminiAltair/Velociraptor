﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SimuPro.Classes
{
    class tmp
    {
        /*
         
          DataTable dt = new DataTable();
        SqlConnection conn = DAL.getConnectionObject();
        if (conn.State != ConnectionState.Open) conn.Open();
        using (SqlCommand cmd = new SqlCommand("SP_GetDownloadItem", conn))
        {
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.Add("@DownloadId", SqlDbType.BigInt).Value = DownloadId;

            SqlDataReader sdr = cmd.ExecuteReader();
            Boolean b = sdr.HasRows;
            dt.Load(sdr);
            dt.TableName = "t";
            sdr.Close();
        }
         
         */




        /*
          SqlConnection conn = DAL.getConnectionObject();
        if (conn.State != ConnectionState.Open) conn.Open();

        int retval;
        using (SqlCommand cmd = new SqlCommand("SP_UserOrgLevelInProjAndFixed", conn))
        {
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.Add("@UserId", SqlDbType.BigInt).Value = thisVisitor.UserId;
            cmd.Parameters.Add("@ProjId", SqlDbType.Int).Value = ProjectId;

            var returnParameter = cmd.Parameters.Add("@ReturnVal", SqlDbType.BigInt);
    returnParameter.Direction = ParameterDirection.ReturnValue;
            cmd.ExecuteNonQuery();
            retval = Convert.ToInt32(returnParameter.Value);
        }
         
         */
    }
}
