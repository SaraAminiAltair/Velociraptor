﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for SimuHelper
/// </summary>
public class SimuHelper
{
    static CoUtils cu = new CoUtils();

    
   


    

    public static void WriteNodesDetailedInfo(List<ComputerNode> nodes, string filename)
    {

        try
        {
            cu.FileDelete(filename);
            System.IO.StreamWriter sw = new System.IO.StreamWriter(filename, true);
            string t = "Nodes Configuration Report";
            for (int i = 0; i < nodes.Count; i++)
            {
                ComputerNode n = nodes[i];

                t = "Node ID.:" + n.NodeID + "\t" + n.HardwareProfile.NodeDeviceName + Environment.NewLine;
                t = t + "--------------------------------------------" + Environment.NewLine;
                sw.Write(t + "\n\r");
            }
            sw.Close();
        }

        catch (Exception x) { }


    }

}