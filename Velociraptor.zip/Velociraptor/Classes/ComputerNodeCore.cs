﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Windows.Forms;

public partial class ComputerNode
{
    public string ActionForMovement = "", ActionForPackets = "", ActionForScheduling = "", ActionForManagement = "";
    public string Date = "";
    public bool isNodeAlive = true;
    public SimulationNodeStructure.Cluster OwnerCluster; //if this node is a member of a cluster
    public int NodeID_OnDatabase = -1;
    public string NodeID;
    public NodeHardwareProfile HardwareProfile;
    public SLocationProfile LocationProfile;
    public List<NodeStepLog> NodeStepLogs = new List<NodeStepLog>();
    public SNodeRolesProfile RoleProfile;
    public int TimeOfDeath;
    public string CauseOfDead;
    public ClusteringRelatedInfo ClusterInfo_Wifi = new ClusteringRelatedInfo();
    public ClusteringRelatedInfo ClusterInfo_Bluetooth = new ClusteringRelatedInfo();


    //public SJobQueue JobQueues= new SJobQueue();
    public DataPacketsQueues DataPacketQueues_Wifi = new DataPacketsQueues();
    public DataPacketsQueues DataPacketQueues_Bluetooth = new DataPacketsQueues();
    public DataPacketsQueues DataPacketQueues_Cellular3G = new DataPacketsQueues();
    public DataPacketsQueues.SingleDataPacketQueue DataPacketQueueGenerated = new DataPacketsQueues.SingleDataPacketQueue();
    public int CountOfReceivedRequests = 0;
    public int CountOfSuccessfullyTransferedRequests = 0;
    public void JobQue_AddtoJobsInQueue(Job job)
    {

    }

    public void JobQue_AddtoWaitQueue(Job job)

    {
        //JobQueues.JobsGeneratedByNodeWaitQueue.Enqueue(job);
    }








    public void ComputerNode_MandatoryInit(SqlConnection SqlConnectionForLoggingDatabase, string _NodeId, NodeHardwareProfile _HardwareProfile, SLocationProfile _LocationProfile, SNodeRolesProfile _RoleProfile, SimulationConfiguration simuConfig)
    {
        HardwareProfile = _HardwareProfile;
        LocationProfile = _LocationProfile;
        RoleProfile = _RoleProfile;
        NodeID = _NodeId;
        Cl_UpdateClusteringInfoToShareWithOtherNodes(simuConfig);
        Log_NodeInit(SqlConnectionForLoggingDatabase);
    }

    int CurrentSimulationTime = 0;

    public void DoOneStepOfMainLoop(SimulationNodeStructure nodeStructure, int currentSimulationTime, SqlConnection sqlConn)
    {
        CurrentSimulationTime = currentSimulationTime;

        CheckForRemaingEnergy(nodeStructure, sqlConn);
        if (this.isNodeAlive)
        {
            MoveNode(nodeStructure.terrain);
            if (currentSimulationTime< nodeStructure.SimuConfig.simulationMaxStep-10)    GenerateDataPackets(nodeStructure, sqlConn);        //don't generate packets for the last ten steps to let the system to finalize in-travel packets.
            
            ProcessDataQueues(nodeStructure, sqlConn);
            ProcessTaskQueues();
            DoRoleActs(nodeStructure);

            DoLogs();
        }
    }

    void ProcessDataQueues(SimulationNodeStructure simustruct, SqlConnection sqlConn)
    {
         if (simustruct.SimuConfig.TransmitAlgorithm ==SimulationConfiguration.TransmitAlgorithms.Cell)
            ProcessDataQueues_AlgorithmCell(simustruct, sqlConn);
        if (simustruct.SimuConfig.TransmitAlgorithm == SimulationConfiguration.TransmitAlgorithms.esf)
            ProcessDataQueues_Algorithmesf(simustruct, sqlConn);



    }


    private void CheckForRemaingEnergy(SimulationNodeStructure nodeStructure, SqlConnection sqlConn)
    {
        if (this.HardwareProfile.PowerSupplyProfile.PowerType == NodeHardwareProfile.HardwarePowerSupply.PowerSupplyType.Grid)
        { this.isNodeAlive = true; return; }
        if (this.HardwareProfile.PowerSupplyProfile.EnergyCurrent == 0)
        {
            this.TimeOfDeath = this.CurrentSimulationTime;
            this.CauseOfDead = "EnergyFinished";
            this.isNodeAlive = false;
            DropPacketsFromAllNodeQueues(nodeStructure.DroppedPackets, sqlConn, 1); //1 means drop is because of energy is depleted
            LogNodeDeath(nodeStructure, sqlConn);
        }
    }

    public void LogNodeDeath(SimulationNodeStructure nodeStructure, SqlConnection sql)
    {

        try
        {
            nodeStructure.DeadNodes.Add(this);

            if ((sql == null)) return;
            if (sql.State != ConnectionState.Open) sql.Open();
            using (SqlCommand cmd = new SqlCommand("SP_NodeLogDeath", sql))
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@NodeIDKey", SqlDbType.Int).Value = this.NodeID_OnDatabase;
                cmd.Parameters.Add("@Time", SqlDbType.Int).Value = this.CurrentSimulationTime;
                cmd.Parameters.Add("@CauseOfDeath", SqlDbType.NVarChar).Value = this.CauseOfDead;

                cmd.ExecuteNonQuery();

            }
        }
        catch (Exception e)
        {
            System.Threading.Thread.Sleep(4000);

            //  MessageBox.Show("Error in Logging Node Death" + Environment.NewLine + Environment.NewLine + e.ToString());
        }

    }














    private void ProcessTaskQueues()
    {

    }
    public string _thisStepActionForManagement = "", _thisStepActionForMovement = "", _thisStepActionForPackets = "", _thisStepActionForScheduling = "";

    void DoLogs()
    {
        NodeStepLog log = new NodeStepLog();
        log.SimulationTime = this.CurrentSimulationTime;
        log.Date = this.Date;
        log.ActionForManagement = _thisStepActionForManagement;
        log.ActionForMovement = _thisStepActionForMovement;
        log.ActionForPackets = _thisStepActionForPackets;
        log.ActionForScheduling = _thisStepActionForScheduling; ;
        log.EnergyCurrent = this.HardwareProfile.PowerSupplyProfile.EnergyCurrent;
        log.isCPUIdle = this.HardwareProfile.ComputerHardwareProfile.CPUProfile.isIdle;
        log.RamFree = this.HardwareProfile.ComputerHardwareProfile.Ram_free;
        log.StorageFree = this.HardwareProfile.ComputerHardwareProfile.StorageProfile.HDDFree;
        log.DistanceFromTarget = LocationProfile.DistanceFromTarget;
        //clustering related
        log.clusterRelatedInfo_WiFi = this.ClusterInfo_Wifi.GetCopy();
        log.clusterRelatedInfo_Bluetooth = this.ClusterInfo_Bluetooth.GetCopy();
        //---

        NodeStepLogs.Add(log);

        _thisStepActionForManagement = _thisStepActionForMovement = _thisStepActionForPackets = _thisStepActionForScheduling = "";

    }


    private void Log_NodeInit(SqlConnection SqlConnectionForLoggingDatabase)
    {
        try
        {


            string clusterID = "";
            if (OwnerCluster != null) clusterID = OwnerCluster.ClusterID;
            //NodeID_OnDatabase should be set.
            if ((SqlConnectionForLoggingDatabase == null)) return;
            if (SqlConnectionForLoggingDatabase.State != ConnectionState.Open) SqlConnectionForLoggingDatabase.Open();
            using (SqlCommand cmd = new SqlCommand("SP_NodesInit", SqlConnectionForLoggingDatabase))
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@PowerSupplyType", SqlDbType.NVarChar).Value = NodeHardwareProfile.HardwarePowerSupply.PowerSupplyType.getPowerSupplyTypeAsText(HardwareProfile.PowerSupplyProfile.PowerType);
                cmd.Parameters.Add("@EnergyStart", SqlDbType.Int).Value = Convert.ToInt32(HardwareProfile.PowerSupplyProfile.EnergyStart);
                cmd.Parameters.Add("@NodeDeviceName", SqlDbType.NVarChar).Value = HardwareProfile.NodeDeviceName;
                cmd.Parameters.Add("@NodeID", SqlDbType.NVarChar).Value = NodeID;
                cmd.Parameters.Add("@NodeTypeCode", SqlDbType.NVarChar).Value = NodeHardwareProfile.NodeTypes.getNodeTypeAsText(this.HardwareProfile.NodeTypeCode);
                cmd.Parameters.Add("@OwnerClusterID", SqlDbType.NVarChar).Value = clusterID;
                cmd.Parameters.Add("@Storage", SqlDbType.NVarChar).Value = HardwareProfile.ComputerHardwareProfile.StorageProfile.getStorageHardwareAsText();
                cmd.Parameters.Add("@RAM", SqlDbType.Int).Value = HardwareProfile.ComputerHardwareProfile.Ram_free;
                cmd.Parameters.Add("@CPU", SqlDbType.Int).Value = HardwareProfile.ComputerHardwareProfile.CPUProfile.CPUCurrentMIPS_hardware;
                cmd.Parameters.Add("@NetworkInterfaceMalfunctionProbablity", SqlDbType.Float).Value = HardwareProfile.NodePacketLossProbablityDueToMalfuntionInHWorSW;


                var NodeID_InDB = cmd.Parameters.Add("@ReturnVal", SqlDbType.Int);
                NodeID_InDB.Direction = ParameterDirection.ReturnValue;
                cmd.ExecuteNonQuery();
                NodeID_OnDatabase = Convert.ToInt32(NodeID_InDB.Value);
            }
        }
        catch (Exception ee)
        {

            //   MessageBox.Show("Error in Logging Node Initialization" + Environment.NewLine + Environment.NewLine + ee.ToString());
            System.Threading.Thread.Sleep(4000);

        }
    }

    public void Log_NodeSteps(SqlConnection SqlConnectionForLoggingDatabase)
    {



        CoUtils cu = new CoUtils();
        if ((SqlConnectionForLoggingDatabase == null)) return;
        if (SqlConnectionForLoggingDatabase.State != ConnectionState.Open) SqlConnectionForLoggingDatabase.Open();
        for (int i = 0; i < NodeStepLogs.Count; i++)
        {
            try
            {
                using (SqlCommand cmd = new SqlCommand("SP_NodeLogStepVer2", SqlConnectionForLoggingDatabase))
                {
                    cmd.CommandType = CommandType.StoredProcedure;

                    cmd.Parameters.Add("@ActionForPackets", SqlDbType.NVarChar).Value = NodeStepLogs[i].ActionForPackets;
                    cmd.Parameters.Add("@ActionForScheduling", SqlDbType.NVarChar).Value = NodeStepLogs[i].ActionForScheduling;
                    cmd.Parameters.Add("@ActionForManagement", SqlDbType.NVarChar).Value = NodeStepLogs[i].ActionForManagement;
                    cmd.Parameters.Add("@NodeIDKey", SqlDbType.Int).Value = NodeID_OnDatabase;
                    cmd.Parameters.Add("@Date", SqlDbType.NVarChar).Value = NodeStepLogs[i].Date;
                    cmd.Parameters.Add("@Time", SqlDbType.NVarChar).Value = NodeStepLogs[i].SimulationTime;
                    cmd.Parameters.Add("@x", SqlDbType.Int).Value = LocationProfile.LocationHistory[i].LocationPoint.X;
                    cmd.Parameters.Add("@Y", SqlDbType.Int).Value = LocationProfile.LocationHistory[i].LocationPoint.Y;
                    cmd.Parameters.Add("@Z", SqlDbType.Int).Value = LocationProfile.LocationHistory[i].LocationPoint.Z;
                    cmd.Parameters.Add("@Target_X", SqlDbType.Int).Value = LocationProfile.LocationHistory[i].TargetPoint.X;
                    cmd.Parameters.Add("@Target_Y", SqlDbType.Int).Value = LocationProfile.LocationHistory[i].TargetPoint.Y;
                    cmd.Parameters.Add("@Target_Z", SqlDbType.Int).Value = LocationProfile.LocationHistory[i].TargetPoint.Z;
                    cmd.Parameters.Add("@RamFree", SqlDbType.Int).Value = this.HardwareProfile.ComputerHardwareProfile.Ram_free;
                    cmd.Parameters.Add("@StorageFree", SqlDbType.Int).Value = this.HardwareProfile.ComputerHardwareProfile.StorageProfile.HDDFree;
                    cmd.Parameters.Add("@isCPUIdle", SqlDbType.Int).Value = booltoint(NodeStepLogs[i].isCPUIdle);
                    cmd.Parameters.Add("@EnergyCurrent", SqlDbType.Decimal).Value = NodeStepLogs[i].EnergyCurrent;
                    cmd.Parameters.Add("@SpeedCurrent", SqlDbType.Int).Value = LocationProfile.LocationHistory[i].CurrentSpeed;
                    cmd.Parameters.Add("@Acceleration", SqlDbType.Float).Value = (float)LocationProfile.LocationHistory[i].Acceleration;
                    cmd.Parameters.Add("@ActionForMovement", SqlDbType.NVarChar).Value = NodeStepLogs[i].ActionForMovement;
                    cmd.Parameters.Add("@DistanceFromTarget", SqlDbType.Int).Value = NodeStepLogs[i].DistanceFromTarget;

                    //clustering related
                    cmd.Parameters.Add("@Cl_NeighborsTable", SqlDbType.NVarChar).Value = NodeStepLogs[i].clusterRelatedInfo_WiFi.NeighborsTable.GetNeighborsTableAsString();
                    cmd.Parameters.Add("@Cl_OneHopNeighborsNodeIDs", SqlDbType.NVarChar).Value = NodeStepLogs[i].clusterRelatedInfo_WiFi.NeighborsTable.GetListOfNeighborsNodeID();
                    cmd.Parameters.Add("@Cl_CurrentListOfCH", SqlDbType.NVarChar).Value = cu.ListToString(NodeStepLogs[i].clusterRelatedInfo_WiFi.MyInfoToShareWithOhers.ListofMyClusterHeads);
                    cmd.Parameters.Add("@Cl_AvailableListOfCH", SqlDbType.NVarChar).Value = cu.ListToString(NodeStepLogs[i].clusterRelatedInfo_WiFi.MyAvailableClusterHeadNodeIDs);
                    cmd.Parameters.Add("@Cl_SelfScore", SqlDbType.Decimal).Value = this.ClusterInfo_Wifi.MyInfoToShareWithOhers.Score;

                    cmd.Parameters.Add("@Cl_ListOfMemberNodes", SqlDbType.NVarChar).Value = cu.ListToString(NodeStepLogs[i].clusterRelatedInfo_WiFi.MyInfoToShareWithOhers.ListOfMemberNodes);
                    List<NeighborInfo> nchn = NodeStepLogs[i].clusterRelatedInfo_WiFi.NeighborsTable.GetListOfNeighborsWhichAreClusterHead();

                    cmd.Parameters.Add("@Cl_ListOfNeighborClusterHeadNodes", SqlDbType.NVarChar).Value = ListNeighborsToString(nchn);
                    cmd.Parameters.Add("@Cl_CountOfNeighborsWhichAreCH", SqlDbType.Int).Value = nchn.Count;
                    cmd.Parameters.Add("@Cl_CountOfMembers", SqlDbType.Int).Value = NodeStepLogs[i].clusterRelatedInfo_WiFi.MyInfoToShareWithOhers.ListOfMemberNodes.Count;
                    cmd.Parameters.Add("@Cl_CurrentDurationOfBeingCH", SqlDbType.Int).Value = NodeStepLogs[i].clusterRelatedInfo_WiFi.MyInfoToShareWithOhers.CurrrentDurationOfBeingCH;
                    cmd.Parameters.Add("@Cl_TotalDurationOfBeingCH", SqlDbType.Int).Value = NodeStepLogs[i].clusterRelatedInfo_WiFi.MyInfoToShareWithOhers.TotalDurationOfBeingCH;

                    cmd.Parameters.Add("@Cl_Availability", SqlDbType.Decimal).Value = NodeStepLogs[i].clusterRelatedInfo_WiFi.MyInfoToShareWithOhers.Availability;
                    cmd.Parameters.Add("@Cl_Reputation", SqlDbType.Decimal).Value = NodeStepLogs[i].clusterRelatedInfo_WiFi.MyInfoToShareWithOhers.Reputationesf;
                    cmd.Parameters.Add("@Cl_TransferedData", SqlDbType.Int).Value = NodeStepLogs[i].clusterRelatedInfo_WiFi.MyInfoToShareWithOhers.DataTransfered_inKB;
                    cmd.Parameters.Add("@Cl_CountOfReceivedRequests", SqlDbType.Int).Value = NodeStepLogs[i].clusterRelatedInfo_WiFi.MyInfoToShareWithOhers.CountOfReceivedRequests;
                    cmd.Parameters.Add("@Cl_CountOfSuccessfullyTransmittedRequests", SqlDbType.Int).Value = NodeStepLogs[i].clusterRelatedInfo_WiFi.MyInfoToShareWithOhers.CountOfSuccessfullyTransferedRequests;


                    cmd.ExecuteNonQuery();



                }
            }
            catch (Exception exception)
            {
                //     MessageBox.Show("Error in Logging Node Step " + i.ToString() + Environment.NewLine + Environment.NewLine + exception.ToString());
                System.Threading.Thread.Sleep(4000);


            }
        }


    }

    string ListNeighborsToString(List<NeighborInfo> theList)
    {
        string s = "[";
        foreach (NeighborInfo nifo in theList)
        {
            if (s != "[") s += ",";
            s += nifo.NodeInfo.NodeID;
        }
        s += "]";
        return s;

    }

    public class NodeStepLog
    {
        public int SimulationTime, RamFree;
        public decimal EnergyCurrent;
        public string Date = "", ActionForPackets = "", ActionForScheduling = "", ActionForManagement = "", ActionForMovement = "";

        public float StorageFree;
        public bool isCPUIdle;

        public ClusteringRelatedInfo clusterRelatedInfo_WiFi = new ClusteringRelatedInfo();
        public ClusteringRelatedInfo clusterRelatedInfo_Bluetooth = new ClusteringRelatedInfo();
        public int DistanceFromTarget;


    }





    private object booltoint(bool boolvalue)
    {
        if (boolvalue) return 1; else return 0;
    }

    private void MoveNode(Terrain terrain)
    {
        _thisStepActionForMovement = LocationProfile.MoveOneStep(terrain, CurrentSimulationTime);

    }



    private void DoRoleActs(SimulationNodeStructure nodeStructure)
    {
        RoleAct_DoRegularNodeActs(nodeStructure);
        foreach (int RoleCode in RoleProfile.CurrentActiveRoles)
        {

            switch (RoleCode)
            {
                case SNodeRolesProfile.NodeRoleCodes.RelayData:
                //Currenly Nothing, beacause this role related actions is considered in RoleAct_SendPAckets() method and nothing furthur is required.
                case SNodeRolesProfile.NodeRoleCodes.OfferResourcesForScheduling:
                    //Currenly Nothing
                    break;
                case SNodeRolesProfile.NodeRoleCodes.PerformSchedulingOnSelftAndOtherNodes:
                    RoleAct_PerformSchedulingOnSelftAndOtherNodes(); break;

                case SNodeRolesProfile.NodeRoleCodes.ClusterHead:
                    RoleAct_ClusterHead(); break;

            }




        }


    }




    private void RoleAct_DoRegularNodeActs(SimulationNodeStructure nodeStructure)
    {
        List<ComputerNode> SubjectNodesList = nodeStructure.IoTNodes; //may be we use fog nodes in our clustering and in this case we should add them here
        CL_PerformCommonClusteringCycle(SubjectNodesList, nodeStructure);


    }

    private void RoleAct_SendPackets() //
    {

        //read QueueReceivedPacketsForMe and send them
        //read QueueReceivedPacketsForRelay and send them

        //* sending should be done according to   bluetooth,wifi,ethernet cellular profiles 
        //*by sending we mean call ReceivePacket method of target nodes



    }

    /* public void ReceivePacket(SDataPacket packet, int CommunicationMediumCode) // CommunicationMediumCode should be picked from SHardwareComm.CommunicationMediumCodes class
     {
         // if packet targetnodeid is equal to me then put packet to QueueReceivedPacketsForMe;
         // else if I have Clusterhead or relay roles the put packet to QueueReceivedPacketsForRelay
         // consider many things!!

     }
     */



    private void RoleAct_PerformSchedulingOnSelftAndOtherNodes()
    {


    }
    private void RoleAct_ClusterHead()
    {


    }








}

